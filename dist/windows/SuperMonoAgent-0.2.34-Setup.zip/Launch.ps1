param([string]$InstallRoot = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

function Read-SmaLaunchJson([string]$Path) {
    if ((Get-Item -LiteralPath $Path).Length -gt 32768) { throw 'Installed configuration is too large.' }
    try { return ([IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop) }
    catch { throw 'Installed configuration is invalid.' }
}
function Get-SmaLaunchChild([string]$Root, [string]$Relative) {
    if (!$Relative -or [IO.Path]::IsPathRooted($Relative) -or $Relative.Contains('\') -or $Relative.Contains(':')) { throw 'Invalid installed entry point.' }
    foreach ($part in $Relative.Split('/')) { if (!$part -or $part -in @('.', '..') -or $part.EndsWith('.') -or $part.EndsWith(' ')) { throw 'Invalid installed entry point.' } }
    $base = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $target = [IO.Path]::GetFullPath((Join-Path $base $Relative.Replace('/', '\')))
    if (!$target.StartsWith($base + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Installed entry escapes the version directory.' }
    $current = $target
    while ($current -and $current.Length -ge $base.Length) {
        if ((Test-Path -LiteralPath $current) -and ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Installed application contains a link.' }
        $current = [IO.Path]::GetDirectoryName($current)
    }
    return $target
}
function Test-SmaMainWindow {
    foreach ($process in @(Get-Process -Name SuperMonoAgent -ErrorAction SilentlyContinue)) {
        try {
            if ($process.MainWindowHandle -ne 0 -and $process.MainWindowTitle -match '^SuperMono(?:Agent)?\b' -and $process.MainWindowTitle -notmatch '(?i:logs|\u65e5\u5fd7)') { return $true }
        } catch { }
    }
    return $false
}
function Test-SmaDesktopRuntime {
    $release = 0
    try { $release = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -Name Release -ErrorAction Stop).Release } catch { }
    if ($release -lt 394802) { return $false }
    # Microsoft Learn: microsoft-edge/webview2/concepts/distribution.
    $client = 'Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    foreach ($key in @(('HKCU:\SOFTWARE\' + $client), ('HKLM:\SOFTWARE\WOW6432Node\' + $client), ('HKLM:\SOFTWARE\' + $client))) {
        try {
            $value = (Get-ItemProperty $key -Name pv -ErrorAction Stop).pv
            if ($value -and [version]$value -gt [version]'0.0.0.0') { return $true }
        } catch { }
    }
    return $false
}
function ConvertTo-SmaArgument([string]$Value) {
    $result = New-Object Text.StringBuilder
    [void]$result.Append('"');$slashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') { $slashes++;continue }
        if ($character -eq '"') { [void]$result.Append(('\' * ($slashes * 2 + 1)));[void]$result.Append('"') }
        else { [void]$result.Append(('\' * $slashes));[void]$result.Append($character) }
        $slashes = 0
    }
    [void]$result.Append(('\' * ($slashes * 2)));[void]$result.Append('"')
    return $result.ToString()
}
function Get-SmaLaunchPlan([string]$Root) {
    $rootPath = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $pointer = Read-SmaLaunchJson (Join-Path $rootPath 'current.json')
    $configuration = Read-SmaLaunchJson (Join-Path $rootPath 'config.json')
    if ($pointer.schema -ne 1 -or $pointer.version -cnotmatch '^\d{1,6}\.\d{1,6}\.\d{1,6}$' -or $configuration.schema -ne 1) { throw 'Unsupported installed configuration.' }
    $versionPath = Get-SmaLaunchChild $rootPath ('versions/' + $pointer.version)
    $executable = Get-SmaLaunchChild $versionPath $pointer.entry
    if (!(Test-Path -LiteralPath $executable -PathType Leaf) -or !$executable.EndsWith('.exe', [StringComparison]::OrdinalIgnoreCase)) { throw 'Installed executable is unavailable.' }
    $uri = $null
    if (![Uri]::TryCreate($configuration.relay, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'wss' -or $uri.UserInfo -or $uri.Query -or $uri.Fragment) { throw 'Installed relay configuration is invalid.' }
    $state = [IO.Path]::GetFullPath($configuration.state_dir)
    $tokenFile = [IO.Path]::GetFullPath($configuration.token_file)
    if (!(Test-Path -LiteralPath $tokenFile -PathType Leaf)) { throw 'The existing private Token file is unavailable; it was not replaced.' }
    $desktop = Test-SmaDesktopRuntime
    $arguments = @('workspace')
    if (!$desktop) { $arguments = @('browser', '--workspace') }
    $arguments += @('--relay', $configuration.relay, '--token-file', $tokenFile, '--state-dir', $state)
    return @{ Executable = $executable; Arguments = $arguments; WorkingDirectory = $versionPath; StateDir = $state; Mode = $(if ($desktop) { 'workspace' } else { 'browser' }) }
}
function Invoke-SmaLaunch([string]$Root) {
    if (Test-SmaMainWindow) { return @{ started = $false; reason = 'existing-main-window' } }
    $name = 'Local\SuperMonoAgent.InstalledMainLaunch.' + [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $mutex = New-Object Threading.Mutex($false, $name)
    $owned = $false
    try {
        try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
        if (!$owned) { return @{ started = $false; reason = 'main-window-starting' } }
        if (Test-SmaMainWindow) { return @{ started = $false; reason = 'existing-main-window' } }
        $plan = Get-SmaLaunchPlan $Root
        $oldState = [Environment]::GetEnvironmentVariable('SUPERMONO_STATE_DIR', 'Process')
        try {
            [Environment]::SetEnvironmentVariable('SUPERMONO_STATE_DIR', $plan.StateDir, 'Process')
            $arguments = ($plan.Arguments | ForEach-Object { ConvertTo-SmaArgument $_ }) -join ' '
            $process = Start-Process -FilePath $plan.Executable -ArgumentList $arguments -WorkingDirectory $plan.WorkingDirectory -WindowStyle Hidden -PassThru
        } finally { [Environment]::SetEnvironmentVariable('SUPERMONO_STATE_DIR', $oldState, 'Process') }
        if ($plan.Mode -eq 'workspace') {
            $deadline = [DateTime]::UtcNow.AddSeconds(20)
            while (!$process.HasExited -and !(Test-SmaMainWindow) -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 100 }
        }
        if ($process.HasExited -and $process.ExitCode -ne 0) { throw 'The installed application exited unsuccessfully; existing background terminals were not stopped.' }
        $starting = $plan.Mode -eq 'workspace' -and !$process.HasExited -and !(Test-SmaMainWindow)
        return @{ started = (!$starting); starting = $starting; mode = $plan.Mode }
    } finally {
        if ($owned) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
if ($MyInvocation.InvocationName -ne '.') {
    try { Invoke-SmaLaunch $InstallRoot | ConvertTo-Json -Compress }
    catch { Write-Error ('SuperMonoAgent launch failed: ' + $_.Exception.Message); exit 1 }
}
