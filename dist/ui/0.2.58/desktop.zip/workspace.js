/* Concurrent host directories and byte-preserving, owner-bound xterm views. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const C = window.TerminalClient;
  const encoder = new TextEncoder(), decoder = new TextDecoder();
  const params = new URLSearchParams(location.search);
  const agentAssetBase=new URL('agent-modes/',document.currentScript.src),agentAssetQuery=new URL(document.currentScript.src).search;
  const launch = new URLSearchParams(location.hash.slice(1));
  const explicitToken=launch.has('token')||params.has('token');
  const read = (storage, key) => { try { return storage.getItem(key) || ''; } catch { return ''; } };
  const save = (storage, key, value) => { try { value ? storage.setItem(key, value) : storage.removeItem(key); } catch {} };
  let highlightEnabled=read(localStorage,'sma.workspace.highlight')!=='off';
  let config = {relay: params.get('direct')==='1'?'':params.get('relay') || read(localStorage, 'sma.workspace.relay'),
    code: params.get('direct')==='1'?'':params.get('code') || read(localStorage, 'sma.workspace.code'),
    token: launch.get('token') || params.get('token') || read(sessionStorage, 'sma.workspace.token') || read(localStorage, 'sma.workspace.token'),
    authMode:explicitToken||params.get('direct')==='1'?'manual':read(localStorage,'sma.workspace.auth-mode')||'manual'};
  let renderer = C.rendererName(params.get('renderer') || read(localStorage, 'sma.workspace.renderer'));
  let catalog = [], panes = new Map(), openTabs = [], active = '', layout = null;
  let userConnectedOnce = false, maximized = false, ctrl = false;
  let renameWindow = null, terminateSession = null, connectionOwner = null;
  let homeConfig={...config}, savedHosts=loadHosts(), selectedHost='local', editingHost='', homeRelays=[];
  let relayProfiles=loadRelayProfiles(),profileLegacy='connection',roomMenu=null;
  let runtimeDefaultToken='',prefilledTokenTarget='',defaultTokenEdited=false;
  let relayProbe=null;
  const daemonMonitor={hostID:'',timer:null,pending:null,sequence:0,denied:null};
  const hosts=new Map(), directories=new Map(), relayAccounts=new Map();
  let restoredUI=null;
  try{const raw=read(sessionStorage,'sma.workspace.ui-state');if(raw.length<=65536){const value=JSON.parse(raw||'null');if(value&&Array.isArray(value.tabs))restoredUI=value;}}catch{}
  const restoringKeys=new Set(restoredUI?.tabs.filter(value=>{try{const pair=JSON.parse(value);return pair.length===2&&pair.every(item=>typeof item==='string');}catch{return false;}})||[]);
  function restorePaneViews(host){
    if(!restoredUI)return;
    const ids=catalog.filter(win=>win.host===host).flatMap(win=>win.sessions.map(session=>session.id));
    for(const id of ids)if(restoringKeys.has(id)){openView(id,false);restoringKeys.delete(id);}
    if(restoredUI.active&&panes.has(restoredUI.active))openView(restoredUI.active,false);
    if(!restoringKeys.size){
      const tree=(value,depth=0)=>{if(depth>16)return null;if(typeof value==='string')return panes.has(value)?value:null;
        if(!value||!['horizontal','vertical'].includes(value.direction))return null;const a=tree(value.a,depth+1),b=tree(value.b,depth+1);
        return a&&b?{direction:value.direction,ratio:Math.max(15,Math.min(85,Number(value.ratio)||50)),a,b}:a||b;};
      layout=tree(restoredUI.layout)||layout;restoredUI=null;save(sessionStorage,'sma.workspace.ui-state','');renderLayout();subscribe();
    }
  }
  let accountLogin=null,accountLoginGeneration=0,workspaceAuthorization=null,connectionAuthorization=null;
  const mobile = () => matchMedia('(max-width:600px)').matches;
  const metrics = {socketsOpened:0, receivedBytes:0, transmittedBytes:0, outputFrames:0, snapshots:0, historyResumes:0, historyRecoveries:0,
    renderMilliseconds:0, parsedBytes:0, reconnects:0, rendererFallbacks:0, lastPongMs:null};
  const key=(host,id)=>JSON.stringify([host.id,id]);
  const currentHost=()=>hosts.get(selectedHost);
  const owner=host=>({host,generation:host.generation});
  const validOwner=context=>!!context&&hosts.get(context.host.id)===context.host&&context.generation===context.host.generation;
  const livePane=pane=>!!pane&&panes.get(pane.sid)===pane&&validOwner(pane);
  function scheduleFit(pane){if(!pane)return;const context=owner(pane.host);requestAnimationFrame(()=>{if(validOwner(context)&&livePane(pane))fitPane(pane);});}
  function scheduleVisibleFit(){for(const id of visibleIDs())scheduleFit(panes.get(id));}
  class HostConnection {
    constructor(id,name,settings){
      Object.assign(this,{id,name,config:{...settings},ws:null,generation:0,retry:0,retryTimer:0,pingTimer:0,
        connected:false,supported:false,helloSent:false,catalog:[],groups:[],controls:{},capabilities:{},identity:{},activity:new Map(),agents:new Map(),
        selectedGroup:'',collapsed:read(sessionStorage,'sma.workspace.collapsed.'+id)==='true',initialCatalog:true,nextSplit:'',sessionsBeforeOpen:new Set(),subscriptionSignature:'',
        phase:'offline',error:'',pingSentAt:null,daemonInfo:null,meter:new C.ConnectionMeter(performance.now()),rates:{tx:0,rx:0}});
    }
  }
  function aggregateCatalog(){
    catalog=[...hosts.values()].flatMap(host=>host.catalog.map(win=>({...win,host,raw:win.id,id:key(host,win.id),
      group:key(host,win.group||'default'),sessions:(win.sessions||[]).map(session=>({...session,raw:session.id,id:key(host,session.id)}))})));
  }
  const presets = [ ['powershell','PowerShell'], ['pwsh','PowerShell 7'], ['cmd','CMD'], ['claude','Claude'], ['codex','Codex'] ];
  const node = (tag, className, text) => { const el = document.createElement(tag); if(className)el.className=className;if(text!==undefined)el.textContent=text;return el; };
  const button = (text, title, action) => { const b=node('button','',text);b.type='button';b.title=title;b.setAttribute('aria-label',title);b.onclick=action;return b; };
  const sessionInfo = sid => { for(const win of catalog){const session=(win.sessions||[]).find(s=>s.id===sid);if(session)return {win,session};}return null; };
  const visibleIDs = () => { if(!layout)return [];if(mobile()||maximized)return active?[active]:[];const ids=[];const walk=n=>{if(typeof n==='string')ids.push(n);else if(n){walk(n.a);walk(n.b);}};walk(layout);return [...new Set(ids)]; };
  const notice = message => { $('notice').textContent=message;$('notice').hidden=!message; };
  function status(text) { $('status').textContent=text; }
  function socketSend(host,message){
    if(!host?.ws||host.ws.readyState!==WebSocket.OPEN)return false;
    host.ws.send(message);metrics.transmittedBytes+=host.meter.sent(message);return true;
  }
  function send(context,op,value){
    if(!validOwner(context))return false;
    const host=context.host;if(!host.connected||!host.supported)return false;
    return socketSend(host,C.pack(op,value instanceof Uint8Array?value:encoder.encode(JSON.stringify(value))));
  }
  function connectionName(host){
    if(host.config.code)return '中继';
    const target=new URL(host.config.relay||location.origin,location.origin);
    return ['localhost','127.0.0.1','[::1]','::1'].includes(target.hostname)?'本机':'远端直连';
  }
  function updateConnection(){
    const host=currentHost();if(!host)return;
    const quality=host.meter.quality(performance.now(),host.phase);
    $('connection-label').textContent=host.phase==='connected'?connectionName(host)+'已连接':{connecting:'正在连接',reconnecting:'离线 · 重连中','auth-failed':'验证失败',unsupported:'协议不兼容',invalid:'连接配置无效',offline:'离线'}[host.phase]||'离线';
    $('connection-dot').classList.toggle('online',host.connected);
    $('connection-tx').textContent='↑ '+C.formatRate(host.rates.tx);$('connection-rx').textContent='↓ '+C.formatRate(host.rates.rx);
    const bars=$('connection-quality');bars.dataset.bars=String(quality.bars);bars.setAttribute('aria-label','连接质量：'+quality.label);
    $('connect-button').title=host.name+' · '+quality.label+(host.meter.rtt===null?'':' · '+Math.round(host.meter.rtt)+' ms')+'；当前电脑应用消息字节数';
    metrics.lastPongMs=host.meter.rtt===null?null:Math.round(host.meter.rtt);
    notice(host.error);
  }
  function ping(host){host.pingSentAt=performance.now();send(owner(host),10,encoder.encode(String(host.pingSentAt)));}
  function tokenlessLocal(settings){
    if(settings.code)return false;
    try{return new URL(C.socketURL(settings.relay,location.origin)).hostname==='127.0.0.1';}catch{return false;}
  }
  function handshake(host){
    if(host.helloSent||host.ws?.readyState!==WebSocket.OPEN)return;
    host.helloSent=true;socketSend(host,C.pack(1,encoder.encode(JSON.stringify({...(tokenlessLocal(host.config)||host.config.authMode==='account'?{}:{token:host.config.token}),multiplex:true,reliable:true,history_context:1,history_resume:1,
      channel:host.id==='local'?params.get('channel')||undefined:undefined}))));
  }
  function stopHost(host){
    host.daemonInfo=null;
    invalidateDaemonMonitorHost(host);
    if(host.id==='local'){runtimeDefaultToken='';if(prefilledTokenTarget){$('relay-profile-token').value='';prefilledTokenTarget='';}}
    host.generation++;clearTimeout(host.retryTimer);clearInterval(host.pingTimer);
    if(host.ws){host.ws.onclose=null;host.ws.close();host.ws=null;}host.connected=false;host.supported=false;host.activity.clear();updateSessionDots();
    for(const pane of panes.values())if(pane.host===host){pane.ready=false;pane.term.options.disableStdin=true;clearTimeout(pane.redrawTimer);clearTimeout(pane.resizeRequest?.timer);pane.resizeRequest=null;cancelAnimationFrame(pane.followFrame);pane.followFrame=0;cancelAnimationFrame(pane.scrollIntentFrame);pane.scrollIntentFrame=0;}
  }
  let updateHint='',updateCheckPending=false;
  function receiveUpdateHint(message){
    const revision=C.updateHintRevision(message);
    if(!revision||revision===updateHint||updateCheckPending)return;
    updateHint=revision;
    if(!window.NativeUpdates?.check)return;
    updateCheckPending=true;Promise.resolve(window.NativeUpdates.check()).catch(()=>{}).finally(()=>{updateCheckPending=false;});
  }
  function connect(host){
    stopHost(host);const context=owner(host);
    host.helloSent=false;host.subscriptionSignature='';host.phase='connecting';host.error='';host.meter.reset(performance.now(),host.retry);host.rates={tx:0,rx:0};host.pingSentAt=null;
    for(const pane of panes.values())if(pane.host===host){
      pane.resumeControl=pane.resumeControl||host.controls[pane.raw]?.owner===true;
      pane.generation=host.generation;pane.bindHeader();pane.bindInput();pane.bindObserver();pane.writing=false;pane.lastSize='';pane.lastAttempt='';pane.limitedSize=null;pane.resizePaused=false;pane.frames=[];pane.replayPending=0;pane.recoveryPending=false;
    }
    let url;try{url=C.socketURL(host.config.relay,location.origin);const safe=new URL(url);safe.searchParams.delete('token');url=safe.toString();}
    catch(error){host.error=error.message;host.phase='invalid';updateConnection();renderHosts();return;}
    const local=tokenlessLocal(host.config),account=!local&&host.config.authMode==='account'?accountFor(url):null;
    if(!local&&host.config.authMode==='account'&&(!host.config.code||!account)){host.phase='auth-failed';host.error='请登录此中继账号并重新选择已授权电脑。';updateConnection();renderHosts();return;}
    host.ws=new WebSocket(url);host.ws.binaryType='arraybuffer';metrics.socketsOpened++;renderHosts();updateConnection();
    host.ws.onopen=()=>{if(!validOwner(context))return;if(host.config.code){
      if(host.config.authMode==='account'){if(!accountFor(url)||accountFor(url)!==account){stopAccountHost(host,'账号会话已过期，请重新登录。');return;}socketSend(host,JSON.stringify({op:'phone',code:host.config.code,session:account.session,reliable:true}));}
      else socketSend(host,JSON.stringify({op:'phone',code:host.config.code,token:host.config.token,reliable:true}));
    }else handshake(host);};
    host.ws.onmessage=event=>{
      if(!validOwner(context))return;
      try{
        metrics.receivedBytes+=host.meter.received(event.data);
        if(typeof event.data==='string'){
          const message=JSON.parse(event.data);if(message.op==='ready')handshake(host);else if(message.op==='ui_update')receiveUpdateHint(message);else if(message.error){host.error=String(message.error);updateConnection();}return;
        }
        const {op,payload}=C.unpack(new Uint8Array(event.data));
        if(op===2||op===7)sync(host,JSON.parse(decoder.decode(payload)),op===2);
        else if(op===20)receiveDaemonLogs(host,JSON.parse(decoder.decode(payload)));
        else if(op===3||op===8||op===23){
          if((op===8||op===23)&&payload.length===0)return;
          if(op===23&&host.capabilities.history_context!==1)throw new Error('Unnegotiated history context');
          const data=op===23?C.historyPayload(payload):C.sessionPayload(payload),pane=panes.get(key(host,data.session));
          const replay=op===8||op===23&&['snapshot','resume'].includes(data.context.kind);
          if(!replay&&data.bytes.length)host.activity.set(data.session,performance.now());
          if(livePane(pane)){
            const size=data.context||host.controls[data.session];
            pane.frames.push({op,bytes:data.bytes,context:data.context||null,grid:size?{cols:size.cols,rows:size.rows}:null});
            if(replay){pane.replayPending++;if(data.context?.kind==='resume')metrics.historyResumes++;else metrics.snapshots++;}metrics.outputFrames++;drainPane(pane);
          }
        }else if(op===11){
          const reply=decoder.decode(payload),barrier=/^resize:(\d+):(.+)$/.exec(reply);
          if(barrier){const pane=panes.get(key(host,barrier[2]));if(livePane(pane)&&pane.resizeRequest?.id===Number(barrier[1])){pane.resizeRequest.barrier=true;acceptResize(pane,{},false);drainPane(pane);scheduleFit(pane);}}
          else if(Number(reply)===host.pingSentAt){host.meter.pong(performance.now()-host.pingSentAt,performance.now());updateConnection();updateFooter();}
        }
      }catch(error){host.error='终端协议错误：'+error.message;updateConnection();}
    };
    host.ws.onerror=()=>{if(validOwner(context)){host.error='连接失败，正在等待重试';updateConnection();}};
    host.ws.onclose=event=>{
      if(!validOwner(context))return;
      host.daemonInfo=null;invalidateDaemonMonitorHost(host);
      host.connected=false;host.supported=false;clearInterval(host.pingTimer);
      for(const pane of panes.values())if(pane.host===host){pane.ready=false;pane.term.options.disableStdin=true;}
      host.phase=event.code===4001?'auth-failed':'reconnecting';host.meter.reset(performance.now());host.rates={tx:0,rx:0};
      host.error=event.code===4001?(host.config.authMode==='account'?'账号未获此电脑授权，或主机尚未绑定此账号；请联系管理员。':'访问验证失败，请编辑此电脑的房间码和 Token。'):event.code===4004?'对应电脑尚未上线，正在等待。':event.reason||'连接已断开；此电脑输入已暂停';
      updateConnection();renderHosts();updateFooter();updateSessionDots();
      if(host.config.authMode==='account'&&!accountFor(url)){stopAccountHost(host,'账号会话已过期，请重新登录。');return;}
      if(event.code!==4001){metrics.reconnects++;host.retryTimer=setTimeout(()=>{if(validOwner(context))connect(host);},C.retryDelay(host.retry++));}
    };
  }
  function sync(host,info,greeting){
    if(greeting&&!host.connected){
      if(!info.capabilities?.multiplex){host.error='此电脑后台尚不支持多终端工作区，请更新后台。';host.phase='unsupported';host.ws.onclose=null;host.ws.close();updateConnection();renderHosts();return;}
      host.supported=true;host.connected=true;host.retry=0;host.initialCatalog=true;host.phase='connected';host.error='';userConnectedOnce=true;
      clearInterval(host.pingTimer);ping(host);host.pingTimer=setInterval(()=>ping(host),15000);
    }
    if(!host.supported)return;
    if(host.id==='local'){
      if(Array.isArray(info.service?.relays))homeRelays=info.service.relays;
      if(homeRelayAccess()&&info.service?.default_relay_token_source==='token.txt'){
        runtimeDefaultToken=typeof info.service.default_relay_token==='string'?info.service.default_relay_token:'';
        prefillRuntimeToken();
      }
    }
    if(info.error)host.error=String(info.error);
    if(info.capabilities)host.capabilities=info.capabilities;
    if(info.service&&typeof info.service==='object')updateDaemonInfo(host,info.service);
    for(const field of ['machine','project'])if(typeof info[field]==='string')host.identity[field]=info[field].slice(0,40);
    if(info.controls){host.controls=info.controls;for(const pane of panes.values())if(pane.host===host){acceptResize(pane,info,greeting);if(pane.resumeControl&&host.controls[pane.raw]){pane.resumeControl=false;pane.redrawAfterReplay=true;pane.wantControl=host.controls[pane.raw].owner===true||host.controls[pane.raw].busy===false;}}}
    if(info.windows){host.catalog=info.windows;const sessions=new Set(host.catalog.flatMap(win=>(win.sessions||[]).map(session=>{session.learnedAgent=host.agents.get(session.id)||'';return session.id;})));for(const cache of [host.activity,host.agents])for(const id of cache.keys())if(!sessions.has(id))cache.delete(id);}if(info.groups)host.groups=info.groups;
    if(host.autoDirectory&&isLocalRelayCopy(host)){
      const directory=directories.get(host.autoDirectory);if(directory){directory.selfRooms??=new Set();directory.selfRooms.add(host.config.code);}
      detachHost(host);renderTree();renderTabs();renderLayout();return;
    }
    aggregateCatalog();
    restorePaneViews(host);
    const valid=new Set(host.catalog.flatMap(win=>(win.sessions||[]).map(session=>key(host,session.id))));
    let layoutChanged=false;
    for(const [id,pane] of panes)if(pane.host===host&&!valid.has(id)){removeView(id,false);layoutChanged=true;}
    if(host.initialCatalog){host.initialCatalog=false;const existing=host.catalog.flatMap(win=>win.sessions||[]);
      if(existing.length&&!openTabs.some(id=>panes.get(id)?.host===host)){
        // Restore all initial tabs for the selected computer; other catalogs remain directory-only.
        if(host.id===selectedHost){for(const session of existing)openView(key(host,session.id),false);openView(key(host,(existing.find(session=>session.id===info.session)||existing[0]).id),false);}
      }
    }
    if(host.nextSplit==='new'){const created=host.catalog.flatMap(win=>win.sessions||[]).find(session=>!host.sessionsBeforeOpen.has(session.id));if(created){host.nextSplit='';openView(key(host,created.id));}}
    for(const pane of panes.values())if(pane.host===host){pane.ready=true;pane.term.options.disableStdin=false;const data=sessionInfo(pane.sid);if(data){pane.title.textContent=data.win.title+'（'+agentType(data.session,data.win.title)+'）';TabThemes.apply(pane.title.parentElement,data.win.tab_theme);updateAgentMode(pane);}drainPane(pane);}
    renderTree();renderTabs();renderHosts();renderDaemonMonitor();if(layoutChanged)renderLayout();subscribe();updateConnection();updateFooter();if(greeting||host.id==='local')refreshDirectories();
    scheduleVisibleFit();
  }
  function recoverPane(pane){
    if(!livePane(pane))return;
    pane.historyCursor=null;pane.historyInitialized=false;
    if(pane.replayPending||pane.recoveryPending)return;
    pane.recoveryPending=true;pane.recoveryGeneration=pane.host.generation;
    const sessions=openTabs.map(id=>panes.get(id)).filter(item=>item?.host===pane.host&&sessionInfo(item.sid)).map(item=>item.raw);
    if(send(pane,16,{sessions,refresh:true}))metrics.historyRecoveries++;
    else pane.recoveryPending=false;
  }
  function drainPane(pane){
    if(!livePane(pane)||pane.writing||pane.resizeRequest||!pane.host.controls[pane.raw]||!pane.frames.length)return;
    // Catalog updates can arrive while an earlier write is parsing. Keep each
    // frame on the grid confirmed when it arrived, including queued erase/cursor sequences.
    const frame=pane.frames.shift(),replay=frame.op===8||['snapshot','resume'].includes(frame.context?.kind),size=frame.grid||pane.host.controls[pane.raw],buffer=pane.term.buffer.active;
    const readingDistance=!pane.followOutput&&buffer.type==='normal'&&Number.isFinite(buffer.viewportY)?Math.max(0,buffer.baseY-buffer.viewportY):null;
    const tracked=frame.context?C.historyFrameBytes(frame.context,frame.bytes,pane.historyCursor):{bytes:frame.bytes,position:null,reset:replay};
    if(!tracked){
      if(replay)pane.replayPending=Math.max(0,pane.replayPending-1);
      recoverPane(pane);drainPane(pane);return;
    }
    if(tracked.reset&&readingDistance!==null&&buffer.baseY>0){
      if(replay)pane.replayPending=Math.max(0,pane.replayPending-1);
      pane.recoveryPending=false;pane.historyInitialized=true;
      if(frame.context?.v===2&&tracked.position!==null)pane.historyCursor={position:tracked.position,epoch:frame.context.epoch,stream_id:frame.context.stream_id};
      pane.pendingRefreshOnFollow=true;pane.history.textContent='正在阅读历史，返回底部后同步当前画面';pane.history.hidden=false;
      drainPane(pane);return;
    }
    frame.bytes=tracked.bytes;
    applyGrid(pane,size);
    pane.writing=true;
    pane.questions?.beforeOutput({replay});
    if(tracked.reset){
      resizeGrid(pane,size);pane.term.reset();pane.history.hidden=false;pane.historyCursor=null;pane.historyInitialized=false;
      if(frame.op===8)frame.bytes=C.snapshotBytes(frame.bytes,pane.raw,pane.host.capabilities.snapshot_sgr===true);
    }
    const before=performance.now();
    const writeGeneration=pane.generation;
    pane.term.write(frame.bytes,()=>{
      if(!livePane(pane)||pane.generation!==writeGeneration)return;
      pane.writing=false;if(replay){pane.replayPending=Math.max(0,pane.replayPending-1);pane.historyInitialized=true;if(!pane.replayPending)pane.recoveryPending=false;}
      if(frame.context?.v===2&&tracked.position!==null)pane.historyCursor={position:tracked.position,epoch:frame.context.epoch,stream_id:frame.context.stream_id};
      if(readingDistance!==null&&pane.term.buffer.active.type==='normal'){
        pane.followingProgrammatically=true;pane.term.scrollToLine(Math.max(0,pane.term.buffer.active.baseY-readingDistance));pane.followingProgrammatically=false;
      }
      metrics.renderMilliseconds+=performance.now()-before;metrics.parsedBytes+=frame.bytes.length;
      if(pane.followFrame)keepFollowing(pane);
      drainPane(pane);
      if(!pane.frames.length){fitPane(pane);maybeRedrawPane(pane);}
    });
  }
  function createPane(sid) {
    const data=sessionInfo(sid);if(!data)return null;
    const el=node('article','pane');el.dataset.session=sid;
    const header=node('div','pane-header'),title=node('span','pane-title',data.win.title+'（'+agentType(data.session,data.win.title)+'）');
    const own=node('span','pane-control','');header.append(title,own);
    TabThemes.apply(header,data.win.tab_theme);
    const screen=node('div','terminal-screen');const history=node('div','history-note','已恢复有限输出历史 · 全屏程序画面可能需要刷新');history.hidden=true;
    history.title=history.textContent;el.append(header,screen);$('stage').append(el);
    const term=new Terminal({allowProposedApi:true,convertEol:false,disableStdin:!data.win.host.connected,cursorBlink:true,
      fontFamily:'"Cascadia Mono", "Cascadia Code", Consolas, monospace',fontSize:mobile()?13:14,scrollback:5000,minimumContrastRatio:4.5,
      theme:{background:'#121212',foreground:'#dedede',cursor:'#ddd',selectionBackground:'#55555588'},rendererType:'dom'});
    const fit=new FitAddon.FitAddon();term.loadAddon(fit);
    if(window.Unicode11Addon?.Unicode11Addon){try{term.loadAddon(new Unicode11Addon.Unicode11Addon());term.unicode.activeVersion='11';}catch{}}
    term.open(screen);
    // Native clipboard accelerators must not also send SYN/interrupt bytes.
    // Without a selection, Ctrl+C remains the CLI's ordinary interrupt key.
    term.attachCustomKeyEventHandler(event=>{
      if(event.type!=='keydown'||!/Win/i.test(navigator.platform)||!event.ctrlKey||event.altKey||event.metaKey||event.shiftKey)return true;
      const key=event.key.toLowerCase();
      return key!=='v'&&!(key==='c'&&term.hasSelection());
    });
    // Preserve readable history when a full-screen tool clears saved lines.
    term.parser.registerCsiHandler({final:'J'},params=>params[0]===3);
    const pane={sid,host:data.win.host,raw:data.session.raw,generation:data.win.host.generation,el,screen,term,fit,history,title,own,ready:data.win.host.connected,replayPending:0,lastSize:'',renderer:'dom',webgl:null,observer:null,frames:[],writing:false,wantControl:false,redrawAfterReplay:false,redrawTimer:0,resizeRequest:null,lastAttempt:'',lastInputAt:0,repaintAt:0,composing:false,historyCursor:null,historyInitialized:false,recoveryGeneration:-1};
    term.parser.registerOscHandler(7501,data=>{
      if(!livePane(pane))return false;
      const session=pane.host.catalog.flatMap(win=>win.sessions||[]).find(item=>item.id===pane.raw);if(!session||session.agent)return false;
      const app=/(?:^|[;:])app=([a-zA-Z0-9_-]{1,40})(?:[;:]|$)/.exec(data)?.[1];
      const clear=/(?:^|[;:])state=clear(?:[;:]|$)/.test(data);
      if(!clear&&!/^(codex|claude(?:[-_]code)?|kimi|gemini|opencode|copilot|aider)$/i.test(app||''))return false;
      const next=clear?'':app.toLowerCase().replace('_','-');if((pane.host.agents.get(pane.raw)||'')===next)return false;
      if(next)pane.host.agents.set(pane.raw,next);else pane.host.agents.delete(pane.raw);
      session.learnedAgent=next;aggregateCatalog();const info=sessionInfo(pane.sid);if(info)pane.title.textContent=info.win.title+'（'+agentType(info.session,info.win.title)+'）';renderTree();return false;
    });
    pane.highlighter=C.createHighlighter(term,{enabled:highlightEnabled});
    pane.questions=window.TerminalQuestions?.create(pane,{enabled:highlightEnabled,isCurrent:livePane});
    panes.set(sid,pane);setRenderer(pane);updateAgentMode(pane);
    pane.followOutput=true;pane.followFrame=0;pane.followGeometry=viewportGeometry(pane);pane.userScrollUntil=0;
    const scrollIntent=event=>{
      const buffer=term.buffer.active;if(event.type==='wheel'&&event.deltaY>=0&&buffer.viewportY===buffer.baseY)return;
      pane.userScrollGeometry=viewportGeometry(pane);pane.userScrollUntil=performance.now()+500;cancelAnimationFrame(pane.followFrame);pane.followFrame=0;
      cancelAnimationFrame(pane.scrollIntentFrame);const context=owner(pane.host);
      pane.scrollIntentFrame=requestAnimationFrame(()=>{
        pane.scrollIntentFrame=0;if(!validOwner(context)||!livePane(pane))return;
        const buffer=term.buffer.active;pane.followOutput=buffer.viewportY===buffer.baseY;
        // A tap or downward wheel at the bottom is not a history view.
        if(pane.followOutput)keepFollowing(pane);
      });
    };
    screen.addEventListener('wheel',scrollIntent,{capture:true,passive:true});
    screen.addEventListener('touchmove',scrollIntent,{capture:true,passive:true});
    screen.addEventListener('pointerdown',event=>{if(event.target.classList?.contains('xterm-viewport'))scrollIntent(event);},true);
    screen.addEventListener('keydown',event=>{if(['PageUp','PageDown','Home','End'].includes(event.key)&&event.shiftKey)scrollIntent(event);},true);
    term.onScroll(()=>{
      if(!livePane(pane)||pane.followingProgrammatically)return;
      const explicit=performance.now()<pane.userScrollUntil&&pane.userScrollGeometry===viewportGeometry(pane);
      // Zoom can generate a native DOM scroll before fit/resize sees the new geometry.
      // A stable, idle programmatic history scroll is also an intentional view change.
      if(explicit||(!pane.writing&&!pane.resizeRequest&&!pane.followFrame&&pane.followGeometry===viewportGeometry(pane)))
        pane.followOutput=term.buffer.active.viewportY===term.buffer.active.baseY;
    });
    const scrollBar=node('div','pane-scroll');
    const scrollAction=fn=>{
      return()=>{
        // The pane survives reconnects and receives the current generation.
        if(!livePane(pane))return;
        pane.userScrollGeometry=viewportGeometry(pane);pane.userScrollUntil=performance.now()+500;
        cancelAnimationFrame(pane.followFrame);pane.followFrame=0;
        fn();
      };
    };
    scrollBar.append(
      history,
      button('▲ 上翻屏','向上翻动一页历史',scrollAction(()=>pageHistory(pane,'up'))),
      button('▼ 下翻屏','向下翻动一页历史',scrollAction(()=>pageHistory(pane,'down'))),
      button('⤒ 到开头','翻到最早的历史输出',scrollAction(()=>pageHistory(pane,'start'))),
      button('⤓ 到末尾','翻到最新输出并恢复自动跟随',scrollAction(()=>pageHistory(pane,'end')))
    );
    el.append(scrollBar);
    pane.bindHeader=()=>{
      const context=owner(pane.host),guard=action=>(...args)=>{if(validOwner(context)&&livePane(pane))action(...args);};
      header.replaceChildren(title,own);
      header.oncontextmenu=guard(event=>tabMenu(event,data.win,context));
      header.append(button('接管','接管此终端尺寸',guard(()=>takeControl(sid))),button('刷新','强制后台终端全量重绘',guard(()=>redrawPane(pane))),button('改名','重命名窗口',guard(()=>rename(data.win.id,context))),button('结束','结束后台会话',guard(()=>terminate(sid))),button('×','关闭视图（保留后台进程）',guard(()=>removeView(sid))));
    };
    pane.bindHeader();
    pane.bindInput=()=>{
      pane.inputSubscription?.dispose();const context=owner(pane.host);
      pane.questions?.reset();
      pane.inputSubscription=term.onData(text=>{if(!validOwner(context)||!livePane(pane))return;text=C.terminalInput(text,pane.replayPending>0);if(!text)return;if(ctrl&&text.length===1){text=String.fromCharCode(text.toUpperCase().charCodeAt(0)&31);setCtrl(false);}input(sid,text);});
    };
    pane.bindInput();
    term.textarea.addEventListener('compositionstart',()=>{pane.composing=true;});term.textarea.addEventListener('compositionend',()=>{pane.composing=false;pane.lastInputAt=performance.now();});
    el.addEventListener('pointerdown',()=>{if(livePane(pane))activate(sid,false);});
    screen.addEventListener('pointerdown',event=>{if(event.target===screen&&livePane(pane)){event.preventDefault();activate(sid,false);term.focus();}});
    pane.bindObserver=()=>{
      pane.observer?.disconnect();const context=owner(pane.host);
      pane.observer=new ResizeObserver(()=>{if(validOwner(context)&&livePane(pane)){keepFollowing(pane);scheduleFit(pane);}});pane.observer.observe(screen);
    };
    pane.bindObserver();
    return pane;
  }
  function setRenderer(pane) {
    if(pane.webgl){pane.webgl.dispose();pane.webgl=null;}
    pane.renderer='dom';
    if(renderer!=='dom'&&window.WebglAddon?.WebglAddon){
      try{
        const gl=new WebglAddon.WebglAddon();pane.term.loadAddon(gl);pane.webgl=gl;pane.renderer='webgl';
        gl.onContextLoss(()=>{if(pane.webgl!==gl)return;pane.webgl=null;gl.dispose();pane.renderer='dom';metrics.rendererFallbacks++;notice('WebGL 上下文已丢失，已切换为 DOM 渲染。');updateFooter();});
      }catch(error){pane.renderer='dom';metrics.rendererFallbacks++;if(renderer==='webgl')notice('WebGL 不可用，已使用 DOM 渲染：'+error.message);}
    }else if(renderer==='webgl'){metrics.rendererFallbacks++;notice('此浏览器不支持 WebGL 附加组件，已使用 DOM 渲染。');}
  }
  const agentModeKey=pane=>'sma.workspace.agent-mode.'+JSON.stringify([endpoint(pane.host.config),pane.raw]);
  function updateAgentMode(pane){
    const info=sessionInfo(pane.sid);if(!info)return;
    const saved=read(localStorage,agentModeKey(pane)),mode=C.agentProfiles.some(profile=>profile.id===saved)?saved:'auto';
    const detected=mode==='auto'?C.agentModeFromSession(info.session,info.win.title):mode;
    pane.agentMode=mode;if(pane.agentRequested===detected)return;
    pane.agentRequested=detected;const generation=pane.agentGeneration=(pane.agentGeneration||0)+1;
    const apply=profile=>{
      if(!livePane(pane)||pane.agentGeneration!==generation)return;
      pane.term.options.theme={background:'#121212',foreground:'#dedede',cursor:'#ddd',selectionBackground:'#55555588',...profile.theme};
      pane.highlighter.setProfile(profile);pane.agentProfile=profile.id;
      if(active===pane.sid)updateFooter();
    };
    if(detected==='auto'){apply(C.commonAgentProfile);return;}
    const url=new URL(detected+'.json',agentAssetBase);url.search=agentAssetQuery;
    C.loadAgentProfile(url.href,detected).then(apply).catch(()=>{
      if(!livePane(pane)||pane.agentGeneration!==generation)return;apply(C.commonAgentProfile);
      if(active===pane.sid)notice('该模式暂时无法加载，已使用默认配色。');
    });
  }
  function viewportGeometry(pane){
    const rect=pane.screen.getBoundingClientRect();return [rect.width,rect.height,devicePixelRatio].join(':');
  }
  function pageHistory(pane,direction){
    const buffer=pane.term.buffer.active;
    if(buffer.type==='alternate'||buffer.baseY===0){
      const session=sessionInfo(pane.sid)?.session||{},declared=session.agent||session.learnedAgent;
      const executable=value=>String(Array.isArray(value)?value[0]||'':value||'').trim().replace(/^"|"$/g,'').split(/[\\/]/).pop();
      const codex=declared?/^codex$/i.test(declared):[session.shell,session.command,session.argv].some(value=>/^codex(?:\.(?:exe|cmd|js))?$/i.test(executable(value)));
      const canPage=codex&&pane.ready&&pane.host.connected&&!pane.replayPending;
      const message=codex?(canPage?'正在翻阅 Codex 历史。':'请等待连接和历史恢复后再翻屏。'):buffer.type==='alternate'?'此全屏程序没有本地滚动历史，请使用程序自身的历史查看功能。':'当前会话尚无可翻阅的本地历史。';
      pane.history.textContent=message;pane.history.title=message;pane.history.hidden=false;
      if(canPage){
        if(direction==='up'||direction==='start')pane.followOutput=false;
        else if(direction==='end')pane.followOutput=true;
        const keys={up:'\x1b[5~',down:'\x1b[6~',start:'\x1b[1;5H',end:'\x1b[1;5F'};
        input(pane.sid,keys[direction]);
      }
      return;
    }
    if(direction==='up'){pane.followOutput=false;pane.term.scrollPages(-1);}
    else if(direction==='start'){pane.followOutput=false;pane.term.scrollToTop();}
    else if(direction==='end'){pane.followOutput=true;keepFollowing(pane);}
    else{pane.term.scrollPages(1);pane.followOutput=buffer.viewportY===buffer.baseY;if(pane.followOutput)keepFollowing(pane);}
  }
  function keepFollowing(pane){
    if(!livePane(pane)||!pane.followOutput)return;
    if(pane.pendingRefreshOnFollow){pane.pendingRefreshOnFollow=false;recoverPane(pane);}
    if(pane.followFrame)return;
    const context=owner(pane.host);let settled=0;
    const follow=()=>{
      pane.followFrame=0;if(!validOwner(context)||!livePane(pane)||!pane.followOutput)return;
      pane.followingProgrammatically=true;pane.term.scrollToBottom();pane.followingProgrammatically=false;
      // Native viewport/scrollbar synchronization may finish after resize and write callbacks.
      settled=pane.writing||pane.resizeRequest||pane.frames.length||pane.replayPending?0:settled+1;
      pane.followGeometry=viewportGeometry(pane);
      if(settled<2)pane.followFrame=requestAnimationFrame(follow);
    };
    pane.followFrame=requestAnimationFrame(follow);
  }
  function resizeGrid(pane,size){
    const term=pane.term,buffer=term.buffer.active,distance=!pane.followOutput&&buffer.type==='normal'&&Number.isFinite(buffer.viewportY)?Math.max(0,buffer.baseY-buffer.viewportY):null;
    if(term.cols!==size.cols||term.rows!==size.rows){
      pane.followingProgrammatically=true;term.resize(size.cols,size.rows);
      if(distance!==null&&term.buffer.active.type==='normal')term.scrollToLine(Math.max(0,term.buffer.active.baseY-distance));
      pane.followingProgrammatically=false;keepFollowing(pane);
    }else if(pane.followGeometry!==viewportGeometry(pane))keepFollowing(pane);
  }
  function applyGrid(pane,grid=null){
    const size=grid||pane.host.controls[pane.raw];if(!size||pane.writing||(!grid&&pane.frames.length))return;
    resizeGrid(pane,size);
    pane.lastSize=size.cols+'x'+size.rows;
    if(!visibleIDs().includes(pane.sid))return;
    const cell=pane.term._core?._renderService?.dimensions?.css?.cell;if(!cell?.width||!cell?.height)return;
    const style=getComputedStyle(pane.term.element),bar=pane.term._core.viewport?.scrollBarWidth||0;
    const width=size.cols*cell.width+parseFloat(style.paddingLeft)+parseFloat(style.paddingRight)+bar;
    const height=size.rows*cell.height+parseFloat(style.paddingTop)+parseFloat(style.paddingBottom);
    const scale=Math.min(1,pane.screen.clientWidth/width,pane.screen.clientHeight/height);
    Object.assign(pane.term.element.style,{width:width+'px',height:height+'px',transformOrigin:'top left',transform:scale<.999?'scale('+scale+')':''});
  }
  let resizeSequence=0;
  function requestResize(pane,size,takeover=false,stage='fit',attempt=0){
    if(!livePane(pane)||pane.resizeRequest||!pane.ready)return false;
    keepFollowing(pane);
    const request={...size,id:++resizeSequence,stage,attempt};pane.resizeRequest=request;
    if(!send(pane,5,{session:pane.raw,cols:size.cols,rows:size.rows,request:request.id,...(takeover?{take_control:true}:{})})){pane.resizeRequest=null;return false;}
    if(!pane.host.capabilities.resize_ack)send(pane,10,encoder.encode('resize:'+request.id+':'+pane.raw));
    request.timer=setTimeout(()=>{
      if(!livePane(pane)||pane.resizeRequest!==request)return;
      pane.resizeRequest=null;pane.lastAttempt='';
      const restore=pane.redrawRestore;pane.redrawRestore=null;
      if(pane.host.controls[pane.raw]?.owner&&((request.stage==='redraw-out'&&restore)||(request.stage==='redraw-back'&&request.attempt<1))){
        requestResize(pane,restore||{cols:request.cols,rows:request.rows},false,'redraw-back',1);
      }else{
        pane.resizePaused=true;pane.timedOutRequest=request.id;pane.redrawAfterReplay=false;applyGrid(pane);drainPane(pane);
        notice('尺寸确认超时；已暂停此终端的自动调整，可点击刷新重试。');
      }
    },3000);
    return true;
  }
  function acceptResize(pane,info,greeting){
    const request=pane.resizeRequest,ack=info.resize_ack;if(!request){if(ack?.session===pane.raw&&ack?.request===pane.timedOutRequest){pane.resizePaused=false;pane.timedOutRequest=null;}return;}
    if(pane.host.capabilities.resize_ack?ack?.session!==pane.raw||ack?.request!==request.id:!request.barrier)return;
    clearTimeout(request.timer);pane.resizeRequest=null;pane.lastAttempt='';
    const size=pane.host.controls[pane.raw];if(!size)return;
    pane.lastSize=size.cols+'x'+size.rows;
    if(request.stage==='fit')pane.limitedSize=size.owner&&(size.cols!==request.cols||size.rows!==request.rows)?{wanted:{cols:request.cols,rows:request.rows},actual:{cols:size.cols,rows:size.rows}}:null;
    if(request.stage==='redraw-out'){
      const restore=pane.redrawRestore;pane.redrawRestore=null;
      if(restore&&size.owner)requestResize(pane,restore,false,'redraw-back');
    }else if(request.stage==='redraw-back')pane.history.textContent='终端画面已同步';
  }
  function fitPane(pane, takeover=false) {
    if(!pane||!livePane(pane)||pane.writing||pane.replayPending||!pane.host.controls[pane.raw]||!visibleIDs().includes(pane.sid)||pane.screen.clientWidth<20||pane.screen.clientHeight<20)return;
    if(pane.frames.length){drainPane(pane);return;}
    applyGrid(pane);if(pane.resizeRequest||pane.resizePaused)return;
    let proposed;try{proposed=pane.fit.proposeDimensions();}catch{return;}if(!proposed)return;
    const desired=C.terminalSize(proposed.cols,proposed.rows),lease=pane.host.controls[pane.raw];
    takeover=takeover||pane.wantControl;
    const unchanged=desired.cols===lease.cols&&desired.rows===lease.rows;
    const limited=pane.limitedSize;
    if(limited&&limited.wanted.cols===desired.cols&&limited.wanted.rows===desired.rows&&limited.actual.cols===lease.cols&&limited.actual.rows===lease.rows&&(lease.owner||!takeover)){pane.wantControl=false;maybeRedrawPane(pane);return;}
    const key=desired.cols+'x'+desired.rows+'@'+lease.cols+'x'+lease.rows+':'+lease.owner+':'+takeover;
    if((lease.owner||lease.busy===false||takeover)&&(!unchanged||(takeover&&!lease.owner))&&pane.lastAttempt!==key){
      if(requestResize(pane,desired,takeover)){pane.lastAttempt=key;pane.wantControl=false;}
    }else if(unchanged)pane.wantControl=false;
    updateFooter();maybeRedrawPane(pane);
  }
  function redrawPane(pane) {
    if(!livePane(pane)||!pane.ready||!visibleIDs().includes(pane.sid))return;
    pane.redrawAfterReplay=true;pane.wantControl=true;pane.lastAttempt='';pane.resizePaused=false;fitPane(pane,true);
  }
  function maybeRedrawPane(pane) {
    if(!livePane(pane)||!pane.ready||!pane.redrawAfterReplay||pane.resizeRequest||pane.writing||pane.replayPending||pane.frames.length||pane.sid!==active||!pane.host.controls[pane.raw]?.owner)return;
    const now=performance.now(),delay=Math.max(0,700-(now-(pane.lastInputAt||-10000)),2000-(now-(pane.repaintAt||-10000)));
    if(pane.composing||delay>0){clearTimeout(pane.redrawTimer);pane.redrawTimer=setTimeout((context=>()=>{if(!validOwner(context)||!livePane(pane))return;pane.redrawTimer=0;maybeRedrawPane(pane);})(owner(pane.host)),Math.max(100,delay));return;}
    pane.redrawAfterReplay=false;pane.repaintAt=now;
    const size=pane.host.controls[pane.raw],[temporary,restore]=C.redrawSizes(size.cols,size.rows,pane.host.capabilities.resize_ack?2:20);
    pane.redrawRestore=restore;requestResize(pane,temporary,false,'redraw-out');
  }
  function input(sid,text) {
    const pane=panes.get(sid);
    if(!livePane(pane)||!pane.ready||!pane.host.connected||!pane.host.supported||!openTabs.includes(sid))return;
    pane.lastInputAt=performance.now();const frame=C.targetFrame(17,pane.raw,text);
    if(socketSend(pane.host,frame))pane.questions?.observeAcceptedInput(text);
  }
  function takeControl(sid=active){const pane=panes.get(sid);if(pane){pane.wantControl=true;pane.lastAttempt='';pane.redrawAfterReplay=true;pane.resizePaused=false;fitPane(pane,true);}}
  function openView(sid, takeover=false) {
    if(!sessionInfo(sid))return;
    const changed=active!==sid||!panes.has(sid);
    if(!panes.has(sid))createPane(sid);
    if(!openTabs.includes(sid))openTabs.push(sid);
    if(!layout)layout=sid;
    else if(!visibleIDs().includes(sid)){layout=replaceLeaf(layout,active,sid);}
    active=sid;selectedHost=panes.get(sid).host.id;panes.get(sid).host.selectedGroup=sessionInfo(sid).win.group;updateConnection();renderHosts();
    if(takeover&&(changed||!panes.get(sid).host.controls[panes.get(sid).raw]?.owner)){const pane=panes.get(sid);pane.wantControl=true;pane.lastAttempt='';pane.redrawAfterReplay=true;}
    renderTree();renderTabs();renderLayout();subscribe();panes.get(sid).term.focus();
    $('app').classList.remove('mobile-sidebar');
  }
  function replaceLeaf(tree,find,replacement){if(typeof tree==='string')return tree===find?replacement:tree;if(!tree)return replacement;return {...tree,a:replaceLeaf(tree.a,find,replacement),b:replaceLeaf(tree.b,find,replacement)};}
  function prune(tree,sid){if(typeof tree==='string')return tree===sid?null:tree;if(!tree)return null;const a=prune(tree.a,sid),b=prune(tree.b,sid);return a&&b?{...tree,a,b}:a||b;}
  function removeView(sid, redraw=true){
    openTabs=openTabs.filter(id=>id!==sid);layout=prune(layout,sid);
    if(active===sid){const first=tree=>typeof tree==='string'?tree:tree?first(tree.a):'';active=first(layout)||openTabs[openTabs.length-1]||'';}
    if(!layout&&active)layout=active;
    // Closed views unsubscribe and release GPU/parser resources. Reopen requests bounded history.
    cancelAnimationFrame(panes.get(sid)?.followFrame);cancelAnimationFrame(panes.get(sid)?.scrollIntentFrame);C.disposePane(panes,sid);
    if(active&&panes.has(active)){selectedHost=panes.get(active).host.id;updateConnection();renderHosts();}
    if(redraw){renderTree();renderTabs();renderLayout();subscribe();}
  }
  function activate(sid,focus=true){if(active===sid)return;active=sid;selectedHost=panes.get(sid).host.id;updateConnection();renderHosts();renderTree();renderTabs();if(mobile()||maximized)renderLayout();else for(const p of panes.values())p.el.classList.toggle('active',p.sid===active);updateFooter();if(focus)panes.get(sid)?.term.focus();}
  function split(direction){
    const candidate=openTabs.find(id=>id!==active&&!visibleIDs().includes(id))||catalog.flatMap(w=>w.sessions||[]).find(s=>s.id!==active&&!visibleIDs().includes(s.id))?.id;
    if(!active||!candidate){notice('先新建另一个终端，再使用分屏。');return;}
    if(!panes.has(candidate))createPane(candidate);if(!openTabs.includes(candidate))openTabs.push(candidate);
    layout=replaceLeaf(layout,active,{direction,ratio:50,a:active,b:candidate});maximized=false;active=candidate;selectedHost=panes.get(candidate).host.id;updateConnection();renderHosts();
    renderTabs();renderTree();renderLayout();subscribe();
  }
  function renderLayout(){
    for(const p of panes.values()){p.el.hidden=true;p.el.classList.toggle('active',p.sid===active);}
    for(const el of [...$('stage').children])if(el.classList.contains('split'))el.remove();
    $('empty').hidden=!!layout;
    if(!layout){updateFooter();return;}
    const draw=(tree,parent)=>{
      if(typeof tree==='string'){const p=panes.get(tree);if(p){parent.append(p.el);p.el.hidden=false;}return;}
      const box=node('div','split '+(tree.direction==='vertical'?'vertical':''));const a=node('div','split-child'),b=node('div','split-child'),divider=node('div','divider');
      a.style.flex='0 0 calc('+tree.ratio+'% - 2.5px)';b.style.flex='1';box.append(a,divider,b);parent.append(box);draw(tree.a,a);draw(tree.b,b);
      divider.setAttribute('role','separator');divider.setAttribute('aria-orientation',tree.direction==='vertical'?'horizontal':'vertical');divider.tabIndex=0;
      const apply=ratio=>{tree.ratio=Math.max(15,Math.min(85,ratio));a.style.flexBasis='calc('+tree.ratio+'% - 2.5px)';};
      divider.onkeydown=e=>{if(['ArrowLeft','ArrowUp','ArrowRight','ArrowDown'].includes(e.key)){e.preventDefault();apply(tree.ratio+(['ArrowLeft','ArrowUp'].includes(e.key)?-3:3));}};
      divider.onpointerdown=e=>{e.preventDefault();divider.setPointerCapture(e.pointerId);divider.classList.add('dragging');divider.onpointermove=event=>{const rect=box.getBoundingClientRect();apply(tree.direction==='vertical'?(event.clientY-rect.top)/rect.height*100:(event.clientX-rect.left)/rect.width*100);};divider.onpointerup=()=>{divider.onpointermove=null;divider.classList.remove('dragging');};};
    };
    draw(mobile()||maximized?active:layout,$('stage'));
    scheduleVisibleFit();updateFooter();
  }
  function subscribe(){
    for(const host of hosts.values()){
      const panesForHost=openTabs.map(id=>panes.get(id)).filter(pane=>pane?.host===host&&sessionInfo(pane.sid)),sessions=panesForHost.map(pane=>pane.raw);
      const signature=JSON.stringify(sessions),body={sessions};
      if(host.capabilities.history_resume===1){
        const historyAfter={};
        for(const pane of panesForHost)if(pane.historyInitialized&&pane.historyCursor)historyAfter[pane.raw]={...pane.historyCursor};
        if(Object.keys(historyAfter).length)body.history_after=historyAfter;
      }
      if(signature!==host.subscriptionSignature&&send(owner(host),16,body))host.subscriptionSignature=signature;
    }
  }
  function renderTabs(){
    $('tabs').replaceChildren();
    for(const id of openTabs){const info=sessionInfo(id);if(!info)continue;const context=owner(info.win.host),guard=action=>()=>{if(validOwner(context))action();};const tab=node('div','tab');tab.dataset.current=String(id===active);tab.setAttribute('role','presentation');
      const pick=button(info.win.title||info.session.shell,'切换到 '+(info.win.title||info.session.shell),guard(()=>openView(id)));pick.setAttribute('role','tab');pick.setAttribute('aria-selected',String(id===active));
      TabThemes.apply(tab,info.win.tab_theme);
      tab.oncontextmenu=event=>tabMenu(event,info.win,context);
      tab.append(pick,button('×','关闭视图（保留后台进程）',guard(()=>removeView(id))));$('tabs').append(tab);
    }
    renderTabPicker();
    const current=$('tabs').querySelector('[aria-selected="true"]')?.parentElement;
    if(current){const tabs=$('tabs'),a=tabs.getBoundingClientRect(),b=current.getBoundingClientRect();if(b.left<a.left)tabs.scrollLeft+=b.left-a.left;else if(b.right>a.right)tabs.scrollLeft+=b.right-a.right;}
    updateTabNavigation();
  }
  function updateTabNavigation(){const tabs=$('tabs');if(!$('tabs-scroll-left'))return;$('tabs-scroll-left').disabled=tabs.scrollLeft<=1;$('tabs-scroll-right').disabled=tabs.scrollLeft+tabs.clientWidth>=tabs.scrollWidth-1;positionTabPicker();}
  function positionTabPicker(){const menu=$('tabs-overflow-menu');if(!menu||menu.hidden)return;const anchor=$('tabs-overflow-toggle').getBoundingClientRect(),size=menu.getBoundingClientRect();menu.style.position='fixed';menu.style.right='auto';menu.style.left=Math.max(8,Math.min(anchor.right-size.width,innerWidth-size.width-8))+'px';menu.style.top=Math.max(8,Math.min(anchor.bottom+6,innerHeight-size.height-8))+'px';}
  function closeTabPicker(focus=false){const menu=$('tabs-overflow-menu');if(!menu)return;menu.hidden=true;$('tabs-overflow-toggle').setAttribute('aria-expanded','false');if(focus)$('tabs-overflow-toggle').focus();}
  function renderTabPicker(){
    const menu=$('tabs-overflow-menu');if(!menu)return;menu.replaceChildren();
    const groups=new Map();for(const id of openTabs){const info=sessionInfo(id);if(!info)continue;const host=info.win.host;if(!groups.has(host))groups.set(host,[]);groups.get(host).push({id,info});}
    $('tabs-overflow-toggle').textContent='全部窗口 ('+[...groups.values()].reduce((n,items)=>n+items.length,0)+') ▾';
    for(const [host,items] of groups){
      menu.append(node('div','tab-picker-heading',(host.identity.machine||host.name)+(host.config.code?' · '+host.config.code:'')));
      for(const {id,info} of items){
        const context=owner(host),row=button('','切换到 '+(info.win.title||info.session.shell),()=>{closeTabPicker();if(validOwner(context)&&sessionInfo(id))openView(id);});
        row.className='tab-picker-row';row.setAttribute('role','menuitemradio');row.setAttribute('aria-checked',String(id===active));row.dataset.host=host.id;row.dataset.session=info.session.raw;
        row.append(node('span','session-dot'),node('span','tab-picker-title',info.win.title||info.session.shell),node('span','',id===active?'✓':''));menu.append(row);
      }
    }
    if(!groups.size)menu.append(node('p','muted','尚未打开窗口'));
    updateSessionDots();positionTabPicker();
  }
  function tabMenu(event,win,context){
    if(context&&!validOwner(context))return;
    win=catalog.find(item=>item.id===win.id);if(!win)return;
    context=context||owner(win.host);
    TabThemes.open(event,{theme:win.tab_theme,rename:()=>rename(win.id,context),
      select:theme=>send(context,15,{action:'tab-theme',window:win.raw,theme})});
  }
  function updateSessionDots(){
    const now=performance.now(),labels={disconnected:'已断开',waiting:'等待输入（暂未收到新输出）',refreshing:'正在刷新'};
    for(const row of document.querySelectorAll('#tree .session-row,#tabs-overflow-menu .tab-picker-row')){
      const host=hosts.get(row.dataset.host),last=host?.activity.get(row.dataset.session);
      const state=!host?.connected?'disconnected':last!==undefined&&now-last<1800?'refreshing':'waiting';
      if(row.dataset.state===state)continue;
      row.dataset.state=state;const dot=row.querySelector('.session-dot');
      dot.title=labels[state];dot.setAttribute('aria-label','状态：'+labels[state]);
    }
  }
  function agentType(session,windowTitle=''){
    for(const [pattern,label] of [[/\bgemini\b/i,'Gemini'],[/\bopen[ -]?code\b/i,'OpenCode'],[/\bcopilot\b/i,'Copilot'],[/\baider\b/i,'Aider']])if(pattern.test(String(session.agent||'')))return label;
    const profile=C.agentProfiles.find(profile=>profile.id===C.agentModeFromSession(session,windowTitle));if(profile)return profile.label;
    const values=[session.agent,session.learnedAgent,session.command,session.argv,session.title,windowTitle,session.shell];
    for(const value of values){
      const text=Array.isArray(value)?value.join(' '):String(value||'');
      for(const [pattern,label] of [[/\bcodex\b/i,'Codex'],[/\bclaude(?:[ _-]code)?\b/i,'Claude Code'],[/\bkimi\b/i,'Kimi'],[/\bgemini\b/i,'Gemini'],[/\bopen[ -]?code\b/i,'OpenCode'],[/\bcopilot\b/i,'Copilot'],[/\baider\b/i,'Aider']])if(pattern.test(text))return label;
    }
    return '其他';
  }
  function renderTree(){
    const tree=$('tree');tree.replaceChildren();let count=0;
    for(const host of hosts.values()){
      const computer=node('section','computer-tree');computer.dataset.host=host.id;
      computer.append(hostRow(host));
      const windows=node('div','computer-windows');windows.id='host-windows-'+encodeURIComponent(host.id);windows.hidden=host.collapsed;computer.append(windows);
      const entries=catalog.filter(win=>win.host===host).flatMap(win=>win.sessions.map(session=>({win,session})));
      const context=owner(host);
      for(const {win,session} of entries){count++;const row=node('div','session-row');row.dataset.current=String(session.id===active);row.dataset.host=host.id;row.dataset.session=session.raw;
        const type=agentType(session,win.title),open=button('','打开 '+win.title+'（'+type+'）',()=>{if(validOwner(context))openView(session.id);});open.className='session-open';const text=node('span','session-label',win.title),agent=node('span','session-shell','（'+type+'）');agent.title=type;const dot=node('i','session-dot');dot.setAttribute('role','img');open.append(dot,text,agent);
        row.append(open,button('···','重命名窗口',()=>rename(win.id,context)));TabThemes.apply(row,win.tab_theme);row.oncontextmenu=event=>tabMenu(event,win,context);windows.append(row);
      }
      tree.append(computer);
    }
    if(!catalog.length)tree.append(node('p','muted small','暂无会话。新建终端开始工作。'));
    $('session-count').textContent=count+' 个终端';
    updateSessionDots();
  }
  function updateFooter(){
    const pane=panes.get(active),info=sessionInfo(active),host=currentHost();
    $('dimensions').textContent=pane?pane.term.cols+' × '+pane.term.rows:'—';$('effective-renderer').textContent=pane?pane.renderer.toUpperCase():'—';
    if(host?.connected)status((info?.session.cwd||'工作区已连接')+(host.meter.rtt===null?'':' · '+Math.round(host.meter.rtt)+' ms'));
    for(const pane of panes.values()){const lease=pane.host.controls[pane.raw];pane.own.textContent=lease?(lease.owner?'尺寸主控':'共享观看'):'';}
    $('take-control').disabled=!pane||!pane.host.connected;
    $('agent-mode').value=pane?.agentMode||'auto';$('agent-mode').disabled=!pane;
    for(const id of ['new-session','empty-new'])$(id).disabled=!host?.connected;
  }
  function newSession(){newSessionFor(currentHost());}
  function newSessionFor(host){
    if(!host?.connected)return;
    host.sessionsBeforeOpen=new Set(host.catalog.flatMap(win=>win.sessions||[]).map(session=>session.id));host.nextSplit='new';
    const group=host.groups.find(group=>key(host,group.id)===host.selectedGroup)?.id||host.groups[0]?.id||'default';
    send(owner(host),6,{shell:$('preset').value,group});
  }
  function rename(id,context){
    const win=catalog.find(win=>win.id===id);if(!win)return;context=context||owner(win.host);if(!validOwner(context))return;
    renameWindow={...context,id:win.raw};$('rename-value').value=win.title;$('rename-dialog').showModal();$('rename-value').focus();$('rename-value').select();
  }
  function terminate(sid){const pane=panes.get(sid);if(!livePane(pane))return;terminateSession={...owner(pane.host),id:pane.raw};$('terminate-dialog').querySelector('p').textContent='这将终止当前终端中的进程。其他客户端也会断开此会话。';$('terminate-dialog').showModal();}
  function setCtrl(value){ctrl=value;$('ctrl-key').setAttribute('aria-pressed',String(value));}
  function endpoint(settings){
    const url=new URL(C.socketURL(settings.relay,location.origin));url.searchParams.delete('token');url.hash='';
    return JSON.stringify([url.toString(),settings.code.trim()]);
  }
  function showConnection(){
    cancelAccountLogin();
    const host=currentHost();if(!host)return;connectionOwner={...owner(host),target:endpoint(host.config),token:host.config.token};
    connectionAuthorization=host.config.authMode==='account'?{...owner(host),target:endpoint(host.config),url:relayURL(host.config.relay),account:accountFor(host.config.relay)}:null;
    $('connection-auth').value=host.config.authMode||'manual';
    $('relay-url').value=host.config.relay;$('relay-code').value=host.config.code;$('access-token').value=host.config.token;
    $('remember-token').checked=!!read(localStorage,host.id==='local'?'sma.workspace.token':hostTokenKey(host.id));
    $('connection-error').textContent='';$('account-relay-url').value=host.config.relay||$('default-relay').value;renderAccountPanel();renderAuthField('connection');$('connection-dialog').showModal();$('relay-url').focus();
  }
  function loadHosts(){
    try{const seen=new Set(['local']);return JSON.parse(read(localStorage,'sma.workspace.hosts')||'[]').filter(host=>{
      if(!host||typeof host.id!=='string'||!host.id||seen.has(host.id)||typeof host.name!=='string'||typeof host.code!=='string'||!host.code.trim()||host.code.length>128||typeof host.relay!=='string'||!host.relay.trim())return false;
      try{C.socketURL(host.relay,location.origin);seen.add(host.id);return true;}catch{return false;}
    }).slice(0,31).map(({id,name,code,relay,authMode})=>({id,name:name.slice(0,40),code,relay,authMode:authMode==='account'?'account':'manual'}));}catch{return [];}
  }
  function profileToken(profile){
    const key='sma.workspace.profile-token.'+profile.id;
    const target=profileBinding(profile);
    for(const storage of [sessionStorage,localStorage]){const binding=read(storage,key+'.target');if(binding===target||(!profile.code&&!profile.excludedRooms?.length&&binding===profile.endpoint)){const value=read(storage,key);if(value)return value;}}
    return '';
  }
  function profileBinding(profile){return JSON.stringify([profile.endpoint,profile.code||'',...(profile.excludedRooms?.length?[profile.excludedRooms]:[])]);}
  function roomAllowed(scope,code){return (!scope.onlyRoom||scope.code===code)&&!scope.excludedRooms?.includes(code);}
  function loadRelayProfiles(){
    try{return JSON.parse(read(localStorage,'sma.workspace.relay-profiles')||'[]').filter((profile,index,all)=>{
      if(!profile||typeof profile.id!=='string'||!profile.id||profile.id.length>128||typeof profile.endpoint!=='string'||all.findIndex(item=>item?.id===profile.id)!==index)return false;
      if(profile.code!==undefined&&(typeof profile.code!=='string'||profile.code.length>128||/[\x00-\x1f\x7f]/.test(profile.code)))return false;
      if(profile.excludedRooms!==undefined&&(!Array.isArray(profile.excludedRooms)||profile.excludedRooms.length>64||profile.excludedRooms.some(code=>typeof code!=='string'||!code||code.length>128||/[\x00-\x1f\x7f]/.test(code))))return false;
      try{return C.socketURL(profile.endpoint,location.origin)===profile.endpoint;}catch{return false;}
    }).slice(0,32).map(({id,endpoint,code,excludedRooms})=>({id,endpoint,code:code||'',excludedRooms:[...new Set(excludedRooms||[])]}));}catch{return [];}
  }
  function profileEndpoint(address,port){
    address=address.trim();if(!address)throw new Error('请填写 IP 或服务器地址。');
    if(port&&(!/^\d+$/.test(port)||Number(port)<1||Number(port)>65535))throw new Error('端口应为 1～65535。');
    const explicit=/^[a-z]+:\/\//i.test(address);
    if(!explicit&&!address.startsWith('[')&&address.split('/')[0].split(':').length>2){const slash=address.indexOf('/');address='['+(slash<0?address:address.slice(0,slash))+']'+(slash<0?'':address.slice(slash));}
    const embedded=address.match(/^(?:[a-z]+:\/\/)?(?:\[[^\]]+\]|[^/?#:]+):(\d+)(?:[/?#]|$)/i),url=new URL(explicit?address:'https://'+address);
    if(!explicit&&['localhost','127.0.0.1','[::1]'].includes(url.hostname))url.protocol='http:';
    if(embedded)url.port=embedded[1];else if(port)url.port=port;
    if(url.hostname==='117.50.48.22'&&url.port==='8817'&&!explicit)url.protocol='http:';
    return C.socketURL(url.toString(),location.origin);
  }
  function renderRelayProfiles(){
    const list=$('relay-profile-list');if(!list)return;list.replaceChildren();
    relayProfiles.forEach((profile,index)=>{
      const directory=directories.get(profile.endpoint),token=profileToken(profile);
      const count=(directory?.hosts||[]).filter(host=>host.online&&directory.tokens[host.token_index]===token&&(!profile.code||host.code===profile.code)&&!profile.excludedRooms?.includes(host.code)).length;
      const row=node('div','relay-profile-row');row.append(node('span','',profile.endpoint),node('small','muted','凭据 '+(index+1)+' · '+(!token?'需要填写 Token':directory?.phase==='connected'?count+' 个房间':directory?.phase==='unsupported'?'中继暂不支持此凭据的自动发现':'正在连接…')));
      row.append(button('移除','移除连接 '+(index+1),()=>{
        relayProfiles=relayProfiles.filter(item=>item.id!==profile.id);save(localStorage,'sma.workspace.relay-profiles',JSON.stringify(relayProfiles));
        for(const storage of [localStorage,sessionStorage])for(const suffix of ['', '.target'])save(storage,'sma.workspace.profile-token.'+profile.id+suffix,'');
        refreshDirectories();renderRelayProfiles();
      }));
      if(token)for(const room of (directory?.availableHosts||directory?.hosts||[]).filter(room=>room.online&&directory.tokens[room.token_index]===token&&(!profile.code||profile.code===room.code))){
        const label=node('label','check relay-room-choice'),check=node('input');check.type='checkbox';check.checked=!profile.excludedRooms?.includes(room.code);
        check.onchange=()=>{
          if(!check.checked&&(profile.excludedRooms||[]).length>=64&&!profile.excludedRooms.includes(room.code)){check.checked=true;return;}
          const excluded=new Set(profile.excludedRooms||[]);check.checked?excluded.delete(room.code):excluded.add(room.code);profile.excludedRooms=[...excluded];
          const key='sma.workspace.profile-token.'+profile.id;
          for(const storage of [sessionStorage,localStorage])if(read(storage,key))save(storage,key+'.target',profileBinding(profile));
          save(localStorage,'sma.workspace.relay-profiles',JSON.stringify(relayProfiles));refreshDirectories();renderRelayProfiles();
        };
        label.append(check,node('span','',(room.machine||room.code)+' · '+room.code));row.append(label);
      }
      list.append(row);
    });
    $('relay-profile-status').textContent=relayProfiles.length?'房间会自动显示在左侧，无需填写房间号。':'添加连接后，将自动显示此 Token 有权访问的房间。';
  }
  function showRelayProfiles(legacy='connection'){
    profileLegacy=legacy;closeAppMenu();cancelRelayProbe();$('relay-profile-error').textContent='';
    $('relay-profiles-dialog').querySelector('details').open=false;
    let url;try{url=new URL(C.socketURL(currentHost()?.config.code?currentHost().config.relay:relayProfiles.at(-1)?.endpoint||homeRelays[0]?.url||$('default-relay').value,location.origin));}catch{url=new URL(C.socketURL($('default-relay').value,location.origin));}
    $('relay-profile-address').value=['/','/ws','/ws/'].includes(url.pathname)?url.hostname:url.toString();$('relay-profile-port').value=url.port||(url.protocol==='wss:'?'443':'80');$('relay-profile-room').value='';$('relay-profile-token').value='';$('relay-profile-remember').checked=read(localStorage,'sma.workspace.profile-remember')!=='off';prefilledTokenTarget='';defaultTokenEdited=false;
    const stored=[...relayProfiles].reverse().find(profile=>profile.endpoint===url.toString()&&!profile.code&&profileToken(profile));
    if(stored){$('relay-profile-token').value=profileToken(stored);prefilledTokenTarget=stored.endpoint;defaultTokenEdited=true;}
    renderRelayProfiles();$('relay-profiles-dialog').showModal();prefillRuntimeToken();$('relay-profile-address').focus();
    const local=hosts.get('local');if(local?.connected&&homeRelayAccess())send(owner(local),16,{sessions:openTabs.map(id=>panes.get(id)).filter(pane=>pane?.host===local).map(pane=>pane.raw)});
  }
  function prefillRuntimeToken(){
    if(defaultTokenEdited||!$('relay-profiles-dialog').open)return;
    let target;try{target=profileEndpoint($('relay-profile-address').value,$('relay-profile-port').value);}catch{return;}
    const local=hosts.get('local'),isDefault=target===C.socketURL($('default-relay').value,location.origin);
    const configured=homeRelayAccess()&&local?.connected&&homeRelays.some(relay=>{try{return C.socketURL(relay.url,location.origin)===target;}catch{return false;}});
    const token=(isDefault?runtimeDefaultToken:'')||(configured?local.config.token:'');
    if(!isDefault&&!configured)return;
    $('relay-profile-token').value=token;prefilledTokenTarget=token?target:'';
    $('relay-profile-token').title=token?(isDefault&&runtimeDefaultToken?'默认来自本机 token.txt，可手动替换':'来自本机已配置的中继连接，可手动替换'):'';
  }
  function closeAppMenu(){const menu=$('app-menu');if(menu)menu.hidden=true;$('app-menu-toggle')?.setAttribute('aria-expanded','false');}
  function updateDaemonInfo(host,info){
    const pid=Number.isInteger(info.pid)&&info.pid>0&&info.pid<=2147483647?info.pid:null;
    const uptime=typeof info.uptime_seconds==='number'&&Number.isFinite(info.uptime_seconds)&&info.uptime_seconds>=0&&info.uptime_seconds<=Number.MAX_SAFE_INTEGER?info.uptime_seconds:null;
    host.daemonInfo={pid,uptime,receivedAt:performance.now()};
  }
  function invalidateDaemonMonitorHost(host){
    if(daemonMonitor.pending?.context.host===host)daemonMonitor.pending=null;
    if(daemonMonitor.denied?.host===host)daemonMonitor.denied=null;
    if(daemonMonitor.hostID===host.id){$('daemon-monitor-log').textContent='';$('daemon-monitor-status').textContent='连接已变更，等待重新读取运行日志。';}
  }
  function daemonUptime(host){
    const info=host.daemonInfo;if(info?.uptime===null||info?.uptime===undefined)return '运行时长未知';
    const seconds=Math.floor(info.uptime+Math.max(0,performance.now()-info.receivedAt)/1000);
    return '已运行 '+(seconds>=86400?Math.floor(seconds/86400)+'天 ':'')+Math.floor(seconds%86400/3600)+'时 '+Math.floor(seconds%3600/60)+'分 '+seconds%60+'秒';
  }
  function renderDaemonMonitor(){
    if(!$('daemon-monitor-dialog').open)return;
    if(!hosts.has(daemonMonitor.hostID)){
      daemonMonitor.hostID=hosts.has(selectedHost)?selectedHost:hosts.keys().next().value||'';
      daemonMonitor.pending=null;daemonMonitor.denied=null;$('daemon-monitor-log').textContent='';
    }
    const list=$('daemon-monitor-list'),select=$('daemon-monitor-select'),options=[];list.replaceChildren();
    for(const host of hosts.values()){
      const label=host.identity.machine||host.name,room=host.config.code||'本机直连';
      const phase=host.connected?'已连接':({'auth-failed':'验证失败',connecting:'连接中',reconnecting:'重连中',offline:'已断开',invalid:'连接无效',unsupported:'后台版本不兼容'}[host.phase]||'未连接');
      const row=node('div','daemon-monitor-row');row.setAttribute('role','listitem');row.dataset.host=host.id;row.dataset.current=String(host.id===daemonMonitor.hostID);
      row.append(node('strong','',label+' · '+room),node('span','',phase+' · '+host.catalog.length+' 个窗口 / '+host.catalog.reduce((count,win)=>count+(win.sessions||[]).length,0)+' 个终端'),node('span','',(host.daemonInfo?.pid?'PID '+host.daemonInfo.pid:'PID 未知')+' · '+daemonUptime(host)));
      list.append(row);const option=node('option','',label+' · '+room);option.value=host.id;options.push(option);
    }
    if(select.options.length!==options.length||options.some((option,index)=>select.options[index].value!==option.value||select.options[index].textContent!==option.textContent))select.replaceChildren(...options);
    select.value=daemonMonitor.hostID;select.disabled=!hosts.size;
  }
  function requestDaemonLogs(){
    if(!$('daemon-monitor-dialog').open)return;
    renderDaemonMonitor();const host=hosts.get(daemonMonitor.hostID);
    if(!host?.connected){daemonMonitor.pending=null;daemonMonitor.denied=null;$('daemon-monitor-log').textContent='';$('daemon-monitor-status').textContent='此电脑未连接，连接恢复后自动读取日志。';return;}
    if(host.capabilities.daemon_logs!==true){daemonMonitor.pending=null;daemonMonitor.denied=null;$('daemon-monitor-log').textContent='';$('daemon-monitor-status').textContent='此电脑的后台版本不支持运行日志，请升级对应电脑的后台；窗口和终端状态仍可查看。';return;}
    if(daemonMonitor.denied&&validOwner(daemonMonitor.denied)&&daemonMonitor.denied.host===host)return;
    const pending=daemonMonitor.pending;
    if(pending&&validOwner(pending.context)&&pending.context.host===host&&performance.now()<pending.deadline)return;
    daemonMonitor.pending=null;
    const context=owner(host),request='daemon-log-'+(++daemonMonitor.sequence)+'-'+Date.now().toString(36);
    if(send(context,20,{request,lines:80})){
      daemonMonitor.pending={context,request,deadline:performance.now()+6000};
      $('daemon-monitor-status').textContent='正在读取 '+(host.identity.machine||host.name)+' 的运行日志…';
    }else $('daemon-monitor-status').textContent='日志连接暂不可用，稍后自动重试。';
  }
  function receiveDaemonLogs(host,info){
    const pending=daemonMonitor.pending;
    if(!$('daemon-monitor-dialog').open||!pending||!validOwner(pending.context)||pending.context.host!==host||host.id!==daemonMonitor.hostID||performance.now()>pending.deadline||!info||info.request!==pending.request)return;
    daemonMonitor.pending=null;
    if(info.error){daemonMonitor.denied=info.error_code==='owner_required'?pending.context:null;$('daemon-monitor-status').textContent=String(info.error).slice(0,300);$('daemon-monitor-log').textContent='';return;}
    if(typeof info.text!=='string'){$('daemon-monitor-status').textContent='后台返回的日志内容无效，稍后自动重试。';return;}
    if(info.pid!==undefined||info.uptime_seconds!==undefined)updateDaemonInfo(host,info);
    const bytes=encoder.encode(info.text);let start=Math.max(0,bytes.length-32768);while(start<bytes.length&&(bytes[start]&0xc0)===0x80)start++;
    const text=decoder.decode(bytes.subarray(start)).split('\n').slice(-80).join('\n'),log=$('daemon-monitor-log');
    const follow=log.scrollHeight-log.clientHeight-log.scrollTop<=4,position=log.scrollTop;
    log.textContent=text;if(follow)log.scrollTop=log.scrollHeight;else log.scrollTop=position;
    $('daemon-monitor-status').textContent='每 2 秒更新所选电脑 · 最多 80 行';renderDaemonMonitor();
  }
  function closeDaemonMonitor(){clearInterval(daemonMonitor.timer);daemonMonitor.timer=null;daemonMonitor.pending=null;daemonMonitor.denied=null;}
  function showDaemonMonitor(){
    closeAppMenu();closeDaemonMonitor();daemonMonitor.hostID=hosts.has(selectedHost)?selectedHost:hosts.keys().next().value||'';
    $('daemon-monitor-log').textContent='';$('daemon-monitor-status').textContent='';$('daemon-monitor-dialog').showModal();requestDaemonLogs();daemonMonitor.timer=setInterval(requestDaemonLogs,2000);
  }
  function cancelRelayProbe(clear=true){
    const probe=relayProbe;relayProbe=null;if(probe){clearTimeout(probe.timer);probe.socket.onclose=null;probe.socket.close();}
    $('relay-profile-connect').disabled=true;$('relay-profile-connect').textContent='连接所选房间';$('relay-profile-form').querySelector('button[type=submit]').disabled=false;
    if(clear){$('relay-probe-rooms').replaceChildren();$('relay-probe-status').textContent='';}
  }
  function renderRelayProbe(probe){
    const list=$('relay-probe-rooms');list.replaceChildren();
    for(const [code,selected] of probe.selected)if(selected&&!probe.rooms.some(room=>room.code===code))probe.selected.delete(code);
    for(const room of probe.rooms){
      if(!probe.selected.has(room.code))probe.selected.set(room.code,true);
      const label=node('label','check relay-room-choice'),check=node('input');check.type='checkbox';check.checked=probe.selected.get(room.code);
      check.onchange=()=>{if(!check.checked&&[...probe.selected.values()].filter(value=>!value).length>=64){check.checked=true;return;}probe.selected.set(room.code,check.checked);$('relay-profile-connect').disabled=!probe.rooms.some(room=>probe.selected.get(room.code));};
      label.append(check,node('span','',(room.machine||room.code)+' · '+room.code));list.append(label);
    }
    $('relay-profile-connect').disabled=probe.rooms.length>0&&!probe.rooms.some(room=>probe.selected.get(room.code));
    $('relay-profile-connect').textContent=probe.rooms.length?'连接所选房间':'保存中继';
    $('relay-probe-status').textContent=probe.rooms.length?'测试成功，发现 '+probe.rooms.length+' 个房间；'+(probe.restoredSelection?'已保留上次勾选。':'默认全选。'):'服务器已连接，当前没有授权的在线房间；可保存中继，等待房间上线。';
  }
  function closeRoomMenu(){roomMenu?.remove();roomMenu=null;}
  async function closeRoomWindows(context,windows){
    const host=context.host;
    for(const id of windows){
      if(!validOwner(context)||!host.connected)return;
      if(!host.catalog.some(win=>win.id===id))continue;
      if(!send(context,9,{window:id}))return;
      const deadline=performance.now()+10000;
      while(validOwner(context)&&host.connected&&host.catalog.some(win=>win.id===id)&&performance.now()<deadline)await new Promise(resolve=>setTimeout(resolve,40));
      if(host.catalog.some(win=>win.id===id)){notice('部分窗口暂未确认关闭，请检查连接后重试。');return;}
    }
  }
  function showRoomMenu(event,host){
    closeRoomMenu();closeAppMenu();const context=owner(host),windows=host.catalog.map(win=>win.id);
    const menu=node('div','room-menu');menu.setAttribute('role','menu');roomMenu=menu;
    const add=(label,action,disabled=false,requiresConnection=true)=>{const item=button(label,label,()=>{closeRoomMenu();if(validOwner(context)&&(!requiresConnection||host.connected))action();});item.setAttribute('role','menuitem');item.disabled=disabled;menu.append(item);};
    add('新增窗口',()=>newSessionFor(host),!host.connected);
    add('刷新所有窗口',()=>{
      const sessions=openTabs.map(id=>panes.get(id)).filter(pane=>pane?.host===host).map(pane=>pane.raw);
      send(context,16,{sessions,refresh:true});for(const pane of panes.values())if(pane.host===host)pane.term.refresh(0,pane.term.rows-1);
    },!host.connected);
    add('关闭所有窗口',()=>{
      if(!confirm('关闭 '+(host.identity.machine||host.name)+' 的这 '+windows.length+' 个窗口？其中运行的终端进程也会结束。'))return;
      if(!validOwner(context)||!host.connected)return;
      closeRoomWindows(context,windows);
    },!host.connected||!windows.length);
    if(host.id!=='local'&&!host.autoDirectory)add('编辑工作区 '+host.name,()=>showWorkspace(host.id),false,false);
    document.body.append(menu);const rect=event.currentTarget.getBoundingClientRect();Object.assign(menu.style,{position:'fixed',left:Math.max(4,Math.min(rect.left,innerWidth-menu.offsetWidth-4))+'px',top:Math.max(4,Math.min(rect.bottom,innerHeight-menu.offsetHeight-4))+'px'});menu.querySelector('button:not(:disabled)')?.focus();
  }
  const hostTokenKey=id=>'sma.workspace.host-token.'+id;
  function boundToken(id,settings){
    const tokenKey=id==='local'?'sma.workspace.token':hostTokenKey(id),target=endpoint(settings);
    for(const storage of [sessionStorage,localStorage]){
      const token=read(storage,tokenKey),binding=read(storage,tokenKey+'.target');
      if(token&&binding===target)return token;
      if(token&&!binding){save(storage,tokenKey+'.target',target);return token;} // Migrate established per-host credentials once.
      if(token){save(storage,tokenKey,'');save(storage,tokenKey+'.target','');}
    }
    return '';
  }
  function saveHostToken(id,token,remember){const settings=savedHosts.find(host=>host.id===id);save(sessionStorage,hostTokenKey(id),token);save(localStorage,hostTokenKey(id),remember?token:'');for(const storage of [sessionStorage,localStorage])save(storage,hostTokenKey(id)+'.target',token&&settings?endpoint(settings):'');}
  function hostRow(host){
      const row=node('div','workspace-host');row.dataset.current=String(host.id===selectedHost);row.dataset.host=host.id;row.dataset.phase=host.phase;
      const toggle=button('', '',()=>{
        host.collapsed=!host.collapsed;save(sessionStorage,'sma.workspace.collapsed.'+host.id,String(host.collapsed));
        const windows=$('host-windows-'+encodeURIComponent(host.id));if(windows)windows.hidden=host.collapsed;
        updateToggle();
      });toggle.className='workspace-host-toggle';toggle.setAttribute('aria-controls','host-windows-'+encodeURIComponent(host.id));
      function updateToggle(){toggle.textContent=host.collapsed?'▸':'▾';toggle.setAttribute('aria-expanded',String(!host.collapsed));toggle.title=(host.collapsed?'展开':'收起')+'窗口列表';toggle.setAttribute('aria-label',toggle.title+' '+(host.identity.machine||host.name));}
      updateToggle();row.append(toggle);
      const pick=button('','切换到'+(host.id==='local'?host.name:' '+host.name),()=>switchHost(host.id));pick.className='workspace-host-pick';pick.setAttribute('aria-current',String(host.id===selectedHost));
      const rooms=host.config.code?[host.config.code]:host.id==='local'?[...new Set(homeRelays.map(relay=>relay.code).filter(code=>typeof code==='string'&&code))]:[];
      pick.append(node('span','workspace-host-name',host.identity.machine||host.name),node('small','muted',rooms.length?'房间号：'+rooms.join('、'):'未配置房间号'));
      pick.append(node('span','workspace-host-status',(host.connected?'已连接':host.phase)+' · '+(host.meter.rtt===null?'—':Math.round(host.meter.rtt)+' ms')),
        node('small','host-rates','↑ '+C.formatRate(host.rates.tx)+' ↓ '+C.formatRate(host.rates.rx)));row.append(pick);
      const actions=button('···','房间菜单 '+(host.identity.machine||host.name),event=>showRoomMenu(event,host));actions.className='workspace-host-edit';row.append(actions);return row;
  }
  function renderHosts(){
    for(const computer of $('tree').querySelectorAll('.computer-tree')){
      const host=hosts.get(computer.dataset.host);if(host)computer.querySelector('.workspace-host')?.replaceWith(hostRow(host));
    }
  }
  function switchHost(id){
    const host=hosts.get(id);if(!host)return;selectedHost=id;save(sessionStorage,'sma.workspace.activeHost',id);TabThemes.close();
    const existing=openTabs.find(key=>panes.get(key)?.host===host);
    if(existing)openView(existing,false);
    else{const sessions=host.catalog.flatMap(win=>win.sessions||[]);for(const session of sessions)openView(key(host,session.id),false);if(sessions.length)openView(key(host,sessions[0].id),false);}
    renderTree();renderHosts();updateConnection();updateFooter();
  }
  function showWorkspace(id=''){
    const host=savedHosts.find(item=>item.id===id);editingHost=host?.id||'';
    $('workspace-dialog-title').textContent=host?'编辑工作区':'增加工作区';$('workspace-name').value=host?.name||'';$('workspace-code').value=host?.code||'';
    $('workspace-relay').value=host?.relay||currentHost()?.config.relay||homeRelays.find(item=>item.up)?.url||homeRelays[0]?.url||savedHosts.find(item=>item.relay)?.relay||$('default-relay').value;
    workspaceAuthorization=host?.authMode==='account'?{target:endpoint(host),url:relayURL(host.relay),code:host.code,account:accountFor(host.relay)}:null;
    $('workspace-auth').value=host?.authMode||'manual';
    $('workspace-token').value=host?(read(sessionStorage,hostTokenKey(host.id))||read(localStorage,hostTokenKey(host.id))):'';
    $('workspace-remember').checked=!!(host&&read(localStorage,hostTokenKey(host.id)));$('workspace-remove').hidden=!host;$('workspace-error').textContent='';
    $('workspace-dialog').showModal();renderDiscovery();renderAuthField('workspace');$('workspace-code').focus();
  }
  function clearChangedCredential(prefix,original){
    try{if(original&&endpoint({relay:$(prefix==='workspace'?'workspace-relay':'relay-url').value,code:$(prefix==='workspace'?'workspace-code':'relay-code').value})!==endpoint(original))$(prefix==='workspace'?'workspace-token':'access-token').value='';}catch{}
  }
  for(const id of ['workspace-relay','workspace-code'])$(id).addEventListener('input',()=>{
    const original=savedHosts.find(host=>host.id===editingHost);clearChangedCredential('workspace',original);clearAccountSelection('workspace');$('workspace-verification').textContent='';renderDiscovery();
  });
  for(const id of ['relay-url','relay-code'])$(id).addEventListener('input',()=>{clearChangedCredential('connection',connectionOwner?.host.config);clearAccountSelection('connection');});
  function detachHost(host){
    stopHost(host);for(const [id,pane] of [...panes])if(pane.host===host)removeView(id,false);hosts.delete(host.id);aggregateCatalog();
  }
  $('workspace-form').onsubmit=event=>{
    event.preventDefault();const code=$('workspace-code').value.trim(),relay=$('workspace-relay').value.trim();
    if(!code||!relay||code.length>128){$('workspace-error').textContent='请填写有效房间码和中继地址。';return;}
    if(!editingHost&&hosts.size>=32){$('workspace-error').textContent='最多保存 32 台电脑。';return;}
    try{endpoint({relay,code});}catch(error){$('workspace-error').textContent=error.message;return;}
    const id=editingHost||(typeof crypto.randomUUID==='function'?crypto.randomUUID():'host-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
    const previous=savedHosts.find(host=>host.id===id),old=hosts.get(id),settings={id,name:($('workspace-name').value.trim()||'电脑 '+code).slice(0,40),relay,code};
    const authMode=$('workspace-auth').value;
    if(authMode==='account'&&!authorizedSelection('workspace',{relay,code})){$('workspace-error').textContent='请登录并从授权电脑列表重新选择目标。';return;}
    settings.authMode=authMode;let token=authMode==='account'?'':$('workspace-token').value.trim();if(previous&&endpoint(previous)!==endpoint(settings)&&token===old?.config.token)token='';
    const index=savedHosts.findIndex(host=>host.id===id);if(index<0)savedHosts.push(settings);else savedHosts[index]=settings;
    save(localStorage,'sma.workspace.hosts',JSON.stringify(savedHosts));saveHostToken(id,token,$('workspace-remember').checked);
    if(old)detachHost(old);const host=new HostConnection(id,settings.name,{relay,code,token,authMode});hosts.set(id,host);
    $('workspace-dialog').close();selectedHost=id;save(sessionStorage,'sma.workspace.activeHost',id);connect(host);refreshDirectories();renderTree();renderTabs();renderLayout();
  };
  $('workspace-close').onclick=$('workspace-cancel').onclick=()=>$('workspace-dialog').close();
  $('workspace-remove').onclick=()=>{
    const id=editingHost,host=hosts.get(id);if(!host)return;detachHost(host);
    savedHosts=savedHosts.filter(host=>host.id!==id);save(localStorage,'sma.workspace.hosts',JSON.stringify(savedHosts));saveHostToken(id,'',false);
    $('workspace-dialog').close();if(selectedHost===id)switchHost('local');refreshDirectories();renderHosts();renderTree();renderTabs();renderLayout();subscribe();
  };
  $('connection-form').onsubmit=event=>{
    event.preventDefault();if(!validOwner(connectionOwner)){$('connection-error').textContent='此连接已改变，请重新打开设置。';return;}
    const host=connectionOwner.host,relay=$('relay-url').value.trim(),code=$('relay-code').value.trim(),authMode=$('connection-auth').value;let token=authMode==='account'?'':$('access-token').value.trim();
    if(authMode==='account'&&!authorizedSelection('connection',{relay,code})){$('connection-error').textContent='请登录并重新选择此中继授权电脑。';return;}
    if(host.id!=='local'&&(!relay||!code)){$('connection-error').textContent='此工作区需要中继地址和房间码。';return;}
    try{if(endpoint({relay,code})!==connectionOwner.target&&token===connectionOwner.token)token='';}catch(error){$('connection-error').textContent=error.message;return;}
    if(host.id==='local'){
      homeConfig={relay,code,token,authMode};config={...homeConfig};save(localStorage,'sma.workspace.auth-mode',authMode);save(localStorage,'sma.workspace.relay',relay);save(localStorage,'sma.workspace.code',code);
      save(sessionStorage,'sma.workspace.token',token);save(localStorage,'sma.workspace.token',$('remember-token').checked?token:'');for(const storage of [sessionStorage,localStorage])save(storage,'sma.workspace.token.target',token?endpoint({relay,code}):'');
    }else{const saved=savedHosts.find(item=>item.id===host.id);saved.relay=relay;saved.code=code;saved.authMode=authMode;save(localStorage,'sma.workspace.hosts',JSON.stringify(savedHosts));saveHostToken(host.id,token,$('remember-token').checked);}
    // A different endpoint is a different authority: discard old directory and views.
    if(endpoint(host.config)!==endpoint({relay,code})){
      for(const [id,pane] of [...panes])if(pane.host===host)removeView(id,false);host.catalog=[];host.groups=[];host.controls={};host.identity={};aggregateCatalog();
    }
    host.config={relay,code,token,authMode};$('connection-dialog').close();connect(host);refreshDirectories();renderTree();renderTabs();renderLayout();
  };
  $('connection-close').onclick=()=>{cancelAccountLogin();returnToWorkspace=false;$('connection-dialog').close();};$('connect-button').onclick=()=>showRelayProfiles();
  $('rename-cancel').onclick=()=>$('rename-dialog').close();$('rename-form').onsubmit=e=>{e.preventDefault();send(renameWindow,15,{action:'title',window:renameWindow?.id,title:$('rename-value').value.trim()});$('rename-dialog').close();};
  $('terminate-cancel').onclick=()=>$('terminate-dialog').close();$('terminate-form').onsubmit=async e=>{
    e.preventDefault();const context=terminateSession,host=context?.host,dialog=$('terminate-dialog'),message=dialog.querySelector('p'),submit=dialog.querySelector('.danger');
    if(!validOwner(context)){dialog.close();return;}
    if(!host.connected||!send(context,9,{session:context.id})){message.textContent='当前电脑未连接，结束指令未发送。请恢复连接后重试。';return;}
    submit.disabled=true;message.textContent='正在等待后台确认结束会话…';
    try{
      const exists=()=>host.catalog.some(win=>(win.sessions||[]).some(session=>session.id===context.id)),deadline=performance.now()+8000;
      while(validOwner(context)&&host.connected&&exists()&&performance.now()<deadline)await new Promise(resolve=>setTimeout(resolve,40));
      if(validOwner(context)&&host.connected&&!exists())dialog.close();
      else message.textContent='尚未收到后台结束确认，请检查连接后重试。';
    }finally{submit.disabled=false;}
  };
  $('new-project').onclick=()=>showRelayProfiles('workspace');
  const tabPicker=node('div','tab-picker'),tabPickerToggle=button('全部窗口 ▾','查看全部已打开窗口',()=>{const menu=$('tabs-overflow-menu'),show=menu.hidden;closeRoomMenu();closeAppMenu();renderTabPicker();menu.hidden=!show;positionTabPicker();tabPickerToggle.setAttribute('aria-expanded',String(show));if(show)(menu.querySelector('[aria-checked="true"]')||menu.querySelector('button'))?.focus();});
  tabPickerToggle.id='tabs-overflow-toggle';tabPickerToggle.setAttribute('aria-haspopup','menu');tabPickerToggle.setAttribute('aria-expanded','false');tabPickerToggle.setAttribute('aria-controls','tabs-overflow-menu');
  const tabPickerMenu=node('div');tabPickerMenu.id='tabs-overflow-menu';tabPickerMenu.hidden=true;tabPickerMenu.setAttribute('role','menu');tabPickerMenu.setAttribute('aria-label','全部已打开窗口');tabPicker.append(tabPickerToggle,tabPickerMenu);
  const titlebar=document.querySelector('.titlebar');titlebar.querySelector('.header-spacer').before(tabPicker);
  for(const [direction,label,arrow] of [[-1,'向左滚动页签','‹'],[1,'向右滚动页签','›']]){const control=button(arrow,label,()=>$('tabs').scrollBy({left:direction*Math.max(120,$('tabs').clientWidth*.7),behavior:'smooth'}));control.className='tab-scroll';control.id=direction<0?'tabs-scroll-left':'tabs-scroll-right';if(direction<0)$('tabs').before(control);else $('tabs').after(control);}
  $('tabs').addEventListener('scroll',updateTabNavigation,{passive:true});addEventListener('resize',updateTabNavigation);
  const titlebarObserver=new ResizeObserver(()=>{document.documentElement.style.setProperty('--workspace-titlebar-height',titlebar.getBoundingClientRect().height+'px');updateTabNavigation();});titlebarObserver.observe(titlebar);addEventListener('beforeunload',()=>titlebarObserver.disconnect(),{once:true});
  $('app-menu-toggle').onclick=()=>{closeTabPicker();closeRoomMenu();const menu=$('app-menu');menu.hidden=!menu.hidden;$('app-menu-toggle').setAttribute('aria-expanded',String(!menu.hidden));if(!menu.hidden)menu.querySelector('button')?.focus();};
  $('menu-connect').onclick=()=>showRelayProfiles();
  $('menu-daemon-monitor').onclick=showDaemonMonitor;
  $('daemon-monitor-close').onclick=()=>$('daemon-monitor-dialog').close();
  $('daemon-monitor-dialog').addEventListener('close',closeDaemonMonitor);
  $('daemon-monitor-select').onchange=()=>{daemonMonitor.hostID=$('daemon-monitor-select').value;daemonMonitor.pending=null;daemonMonitor.denied=null;$('daemon-monitor-log').textContent='';requestDaemonLogs();};
  $('refresh-relays').onclick=()=>refreshRelayCatalogs();
  $('relay-profiles-close').onclick=()=>$('relay-profiles-dialog').close();
  $('relay-profiles-dialog').addEventListener('close',()=>cancelRelayProbe());
  $('relay-profiles-advanced').onclick=()=>{$('relay-profiles-dialog').close();profileLegacy==='workspace'?showWorkspace():showConnection();};
  $('relay-profile-form').onsubmit=event=>{
    event.preventDefault();cancelRelayProbe();$('relay-profile-error').textContent='';try{
      const target=profileEndpoint($('relay-profile-address').value,$('relay-profile-port').value.trim()),token=$('relay-profile-token').value.trim(),code=$('relay-profile-room').value.trim();
      if(code.length>128||/[\x00-\x1f\x7f]/.test(code))throw new Error('房间号格式无效。');
      if(!token||token.length>4096)throw new Error('请填写有效的 Token。');
      const previous=relayProfiles.find(profile=>profile.endpoint===target&&(profile.code||'')===code&&profileToken(profile)===token);
      const excluded=previous?.excludedRooms||[];
      const socket=new WebSocket(target),probe={target,token,code,socket,timer:0,rooms:[],selected:new Map(excluded.map(code=>[code,false])),restoredSelection:excluded.length>0};relayProbe=probe;
      const live=()=>relayProbe===probe&&$('relay-profiles-dialog').open;
      const failed=message=>{if(!live())return;cancelRelayProbe();$('relay-profile-error').textContent=message;};
      $('relay-profile-form').querySelector('button[type=submit]').disabled=true;$('relay-probe-status').textContent='正在测试连接并获取全部授权房间…';
      probe.timer=setTimeout(()=>failed('测试连接超时，请检查服务器地址、端口和 Token。'),5000);
      socket.onopen=()=>{if(live())socket.send(JSON.stringify({op:'watch',rooms:code?[{code,token}]:[],tokens:[token]}));};
      socket.onmessage=event=>{
        if(!live()||typeof event.data!=='string'||event.data.length>1048576)return;
        try{
          const data=JSON.parse(event.data);if(data.op!=='directory'||!Array.isArray(data.hosts)||data.hosts.length>64)return;
          clearTimeout(probe.timer);$('relay-profile-form').querySelector('button[type=submit]').disabled=false;
          const seen=new Set();probe.rooms=data.hosts.filter(room=>room&&room.online===true&&typeof room.code==='string'&&room.code.length>0&&room.code.length<=128&&!/[\x00-\x1f\x7f]/.test(room.code)&&(!code||room.code===code)&&(data.capabilities?.token_discovery===true?room.token_index===0:!!code&&room.code===code)).filter(room=>{if(seen.has(room.code))return false;seen.add(room.code);return true;}).map(room=>({code:room.code,machine:String(room.machine||'').slice(0,40)}));
          renderRelayProbe(probe);
        }catch{failed('服务器返回了无效的房间列表。');}
      };
      socket.onerror=()=>failed('测试连接失败，请检查加密入口、地址和端口。');socket.onclose=()=>failed('目录连接已关闭，请重新测试连接。');
    }catch(error){$('relay-profile-error').textContent=error.message;}
  };
  $('relay-profile-connect').onclick=()=>{
    const probe=relayProbe;if(!probe)return;
    try{
      const {target,token,code}=probe;
      if(target!==profileEndpoint($('relay-profile-address').value,$('relay-profile-port').value.trim())||token!==$('relay-profile-token').value.trim()||code!==$('relay-profile-room').value.trim())throw new Error('连接信息已修改，请重新测试。');
      if(probe.rooms.length&&!probe.rooms.some(room=>probe.selected.get(room.code)))throw new Error('请至少勾选一个房间。');
      let profile=relayProfiles.find(item=>item.endpoint===target&&(item.code||'')===code&&(profileToken(item)===token||!profileToken(item)));
      if(!profile){if(relayProfiles.length>=32)throw new Error('最多添加 32 组连接。');profile={id:crypto.randomUUID(),endpoint:target,code};relayProfiles.push(profile);}
      profile.excludedRooms=[...probe.selected].filter(([,selected])=>!selected).map(([code])=>code);
      const binding=profileBinding(profile),key='sma.workspace.profile-token.'+profile.id;save(sessionStorage,key,token);save(sessionStorage,key+'.target',binding);
      save(localStorage,key,$('relay-profile-remember').checked?token:'');save(localStorage,key+'.target',$('relay-profile-remember').checked?binding:'');
      save(localStorage,'sma.workspace.profile-remember',$('relay-profile-remember').checked?'on':'off');
      save(localStorage,'sma.workspace.relay-profiles',JSON.stringify(relayProfiles));cancelRelayProbe();prefilledTokenTarget=target;defaultTokenEdited=true;$('relay-profile-error').textContent='';refreshDirectories();renderRelayProfiles();
    }catch(error){$('relay-profile-error').textContent=error.message;}
  };
  $('relay-profile-token').addEventListener('input',()=>{prefilledTokenTarget='';defaultTokenEdited=true;});
  for(const id of ['relay-profile-address','relay-profile-port','relay-profile-room','relay-profile-token'])$(id).addEventListener('input',()=>cancelRelayProbe());
  for(const id of ['relay-profile-address','relay-profile-port'])$(id).addEventListener('input',()=>{
    if(!prefilledTokenTarget)return;let same=false;try{same=profileEndpoint($('relay-profile-address').value,$('relay-profile-port').value)===prefilledTokenTarget;}catch{}
    if(!same){$('relay-profile-token').value='';prefilledTokenTarget='';defaultTokenEdited=true;$('relay-profile-token').title='';}
  });
  document.addEventListener('click',event=>{if(!event.target.closest('.tab-picker'))closeTabPicker();if(!event.target.closest('#app-menu,#app-menu-toggle')||event.target.closest('#app-menu button'))closeAppMenu();if(roomMenu&&!event.target.closest('.room-menu,.workspace-host-edit'))closeRoomMenu();});
  document.addEventListener('keydown',event=>{
    const pickerOpen=!$('tabs-overflow-menu').hidden;
    const menu=roomMenu||(pickerOpen?$('tabs-overflow-menu'):!$('app-menu').hidden?$('app-menu'):null);if(!menu)return;
    if(event.key==='Escape'){event.preventDefault();closeRoomMenu();closeAppMenu();if(pickerOpen)closeTabPicker(true);else $('app-menu-toggle').focus();}
    if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();const items=[...menu.querySelectorAll('button:not(:disabled)')];if(!items.length)return;const index=items.indexOf(document.activeElement);items[event.key==='Home'?0:event.key==='End'?items.length-1:(index+(event.key==='ArrowUp'?-1:1)+items.length)%items.length].focus();}
  });
  for(const [command,label] of presets){const option=node('option','',label);option.value=command;$('preset').append(option);}
  $('new-session').onclick=newSession;$('empty-new').onclick=newSession;
  $('split-horizontal').onclick=()=>split('horizontal');$('split-vertical').onclick=()=>split('vertical');
  $('maximize').onclick=()=>{if(!active)return;maximized=!maximized;$('maximize').setAttribute('aria-pressed',String(maximized));renderLayout();};
  $('take-control').onclick=()=>takeControl();$('renderer').value=renderer;
  $('agent-mode').onchange=()=>{const pane=panes.get(active);if(!pane)return;save(localStorage,agentModeKey(pane),$('agent-mode').value);pane.agentRequested=null;updateAgentMode(pane);};
  $('highlight-toggle').setAttribute('aria-pressed',String(highlightEnabled));
  if(!window.NativeUpdates)$('check-updates').onclick=()=>alert('此窗口未接入本机更新服务。请从 Windows 桌面版的启动入口打开，再检查更新。');
  $('highlight-toggle').onclick=()=>{
    highlightEnabled=!highlightEnabled;save(localStorage,'sma.workspace.highlight',highlightEnabled?'on':'off');
    $('highlight-toggle').setAttribute('aria-pressed',String(highlightEnabled));
    for(const pane of panes.values()){pane.highlighter?.setEnabled(highlightEnabled);pane.questions?.setEnabled(highlightEnabled);}
  };
  $('renderer').onchange=()=>{renderer=C.rendererName($('renderer').value);save(localStorage,'sma.workspace.renderer',renderer);for(const pane of panes.values())setRenderer(pane);updateFooter();};
  $('sidebar-toggle').onclick=()=>{if(mobile())$('app').classList.toggle('mobile-sidebar');else {$('app').classList.toggle('sidebar-hidden');$('app').style.gridTemplateColumns=$('app').classList.contains('sidebar-hidden')?'0 minmax(0,1fr)':($('sidebar').style.width||'240px')+' minmax(0,1fr)';}scheduleVisibleFit();};
  const sidebarObserver=new ResizeObserver(()=>{if(!$('app').classList.contains('sidebar-hidden')&&!mobile())$('app').style.gridTemplateColumns=$('sidebar').getBoundingClientRect().width+'px minmax(0,1fr)';});sidebarObserver.observe($('sidebar'));
  $('ctrl-key').onclick=()=>{setCtrl(!ctrl);panes.get(active)?.term.focus();};
  const keys={escape:'\x1b',tab:'\t',up:'\x1b[A',down:'\x1b[B',left:'\x1b[D',right:'\x1b[C'};
  for(const b of document.querySelectorAll('[data-key]')){b.onpointerdown=e=>e.preventDefault();b.onclick=()=>{const term=panes.get(active)?.term;input(active,C.cursorKey?.(term,b.dataset.key)||keys[b.dataset.key]);term?.focus();};}
  addEventListener('resize',()=>{if(mobile())$('app').style.gridTemplateColumns='';renderLayout();});
  addEventListener('keydown',e=>{if(e.ctrlKey&&e.altKey&&e.key.toLowerCase()==='n'){e.preventDefault();newSession();}if(e.key==='Escape')$('app').classList.remove('mobile-sidebar');});
  function relayURL(value){return C.socketURL(value,location.origin);}
  function accountTransport(value){
    const url=new URL(relayURL(value)),local=['localhost','[::1]','::1'].includes(url.hostname)||/^127(?:\.\d{1,3}){3}$/.test(url.hostname);
    if(url.protocol!=='wss:'&&!local)throw new Error('请先为中继配置 HTTPS/WSS；公网 ws 不可发送密码或账号会话。');
    return url.toString();
  }
  function accountFor(value){
    try{const account=relayAccounts.get(accountTransport(value));return account?.session&&account.expires*1000>Date.now()?account:null;}catch{return null;}
  }
  function saveRelayAccounts(){
    save(sessionStorage,'sma.workspace.relay-accounts',JSON.stringify([...relayAccounts.values()].filter(account=>accountFor(account.url)===account).map(({url,session,expires,account})=>({url,session,expires,account}))));
  }
  function loadRelayAccounts(){
    try{const stored=JSON.parse(read(sessionStorage,'sma.workspace.relay-accounts')||'[]');if(!Array.isArray(stored))return;
      for(const item of stored.slice(0,32)){
        if(!item||typeof item.url!=='string'||typeof item.session!=='string'||!item.session||item.session.length>4096||!Number.isFinite(item.expires)||item.expires*1000<=Date.now()||typeof item.account?.id!=='string')continue;
        let url;try{url=accountTransport(item.url);}catch{continue;}if(url!==item.url)continue;
        const account={url,session:item.session,expires:item.expires,account:{id:item.account.id,email:String(item.account.email||'').slice(0,254)},generation:0,ws:null,retry:0,retryTimer:0,expiryTimer:0,hosts:[],phase:'connecting',revision:0};
        relayAccounts.set(url,account);scheduleAccountExpiry(account);
      }
    }catch{}saveRelayAccounts();
  }
  function scheduleAccountExpiry(account){
    clearTimeout(account.expiryTimer);account.expiryTimer=setTimeout(()=>{
      if(relayAccounts.get(account.url)!==account)return;
      if(account.expires*1000<=Date.now())forgetAccount(account,'账号会话已过期，请重新登录。');else scheduleAccountExpiry(account);
    },Math.min(2147483647,Math.max(1,account.expires*1000-Date.now())));
  }
  function stopAccountDirectory(account){
    account.generation++;clearTimeout(account.retryTimer);if(account.ws){account.ws.onclose=null;account.ws.close();account.ws=null;}
  }
  function stopAccountHost(host,message){
    stopHost(host);host.phase='auth-failed';host.error=message;host.catalog=[];host.groups=[];host.controls={};host.identity={};
    for(const [id,pane] of [...panes])if(pane.host===host)removeView(id,false);
    aggregateCatalog();renderTree();renderTabs();renderLayout();renderHosts();updateConnection();updateFooter();
  }
  function forgetAccount(account,message){
    if(relayAccounts.get(account.url)!==account)return;
    stopAccountDirectory(account);clearTimeout(account.expiryTimer);relayAccounts.delete(account.url);account.hosts=[];account.session='';saveRelayAccounts();
    for(const host of hosts.values())if(host.config.authMode==='account'&&relayURL(host.config.relay)===account.url)stopAccountHost(host,message);
    if(workspaceAuthorization?.url===account.url)clearAccountSelection('workspace');
    if(connectionAuthorization?.url===account.url)clearAccountSelection('connection');
    renderDiscovery();renderAccountPanel();
    $('relay-account-status').textContent=message;
  }
  function connectAccountDirectory(account){
    if(accountFor(account.url)!==account)return;
    stopAccountDirectory(account);const generation=account.generation,session=account.session;
    const live=()=>relayAccounts.get(account.url)===account&&account.generation===generation&&accountFor(account.url)===account;
    account.phase='connecting';account.hosts=[];account.revision=0;
    const socket=new WebSocket(accountTransport(account.url));account.ws=socket;
    socket.onopen=()=>{if(live())socket.send(JSON.stringify({op:'watch',session}));};
    socket.onmessage=event=>{
      if(!live()||typeof event.data!=='string'||event.data.length>1048576)return;
      try{
        const data=JSON.parse(event.data);
        if(data.op!=='directory'||!data.capabilities?.relay_accounts||!Array.isArray(data.hosts)||data.hosts.length>64||!Number.isSafeInteger(data.revision)||data.revision<account.revision)return;
        account.hosts=data.hosts.filter(host=>host&&typeof host.code==='string'&&host.code.length<=128&&typeof host.endpoint==='string'&&accountTransport(host.endpoint)===account.url).map(host=>({code:host.code,endpoint:account.url,online:host.online===true,
          ...(host.online===true?{machine:String(host.machine||'').slice(0,40),project:String(host.project||'').slice(0,40)}:{})}));
        account.revision=data.revision;account.phase='connected';account.retry=0;
        const granted=new Set(account.hosts.map(host=>host.code));
        if(workspaceAuthorization?.account===account&&!granted.has(workspaceAuthorization.code))clearAccountSelection('workspace');
        if(connectionAuthorization?.account===account){const code=JSON.parse(connectionAuthorization.target)[1];if(!granted.has(code))clearAccountSelection('connection');}
        for(const host of hosts.values())if(host.config.authMode==='account'&&relayURL(host.config.relay)===account.url&&!granted.has(host.config.code))stopAccountHost(host,'此电脑的账号授权已撤销。');
        renderDiscovery();renderAccountPanel();
      }catch{account.hosts=[];account.phase='unsupported';renderDiscovery();renderAccountPanel();}
    };
    socket.onerror=()=>{};
    socket.onclose=event=>{
      if(relayAccounts.get(account.url)!==account||account.generation!==generation)return;
      if(event.code===4001||!accountFor(account.url)){forgetAccount(account,'账号会话已失效，请重新登录。');return;}
      account.hosts=[];account.phase=event.code===4000?'unsupported':'offline';renderDiscovery();renderAccountPanel();
      if(account.phase!=='unsupported')account.retryTimer=setTimeout(()=>{if(live())connectAccountDirectory(account);},C.retryDelay(account.retry++));
    };
  }
  function clearAccountSelection(prefix){
    const auth=$(prefix==='workspace'?'workspace-auth':'connection-auth');
    const wasAccount=auth.value==='account';
    if(prefix==='workspace')workspaceAuthorization=null;else connectionAuthorization=null;
    if(wasAccount){auth.value='manual';$(prefix==='workspace'?'workspace-token':'access-token').value='';}
    renderAuthField(prefix);
  }
  function authorizedSelection(prefix,settings){
    try{
      const selection=prefix==='workspace'?workspaceAuthorization:connectionAuthorization,account=accountFor(settings.relay);
      return !!account&&!!selection&&selection.account===account&&selection.target===endpoint(settings)&&account.hosts.some(host=>host.code===settings.code&&host.online);
    }catch{return false;}
  }
  function renderAuthField(prefix){
    const workspace=prefix==='workspace',auth=$(workspace?'workspace-auth':'connection-auth'),input=$(workspace?'workspace-token':'access-token'),remember=$(workspace?'workspace-remember':'remember-token');
    const settings={relay:$(workspace?'workspace-relay':'relay-url').value,code:$(workspace?'workspace-code':'relay-code').value},account=accountFor(settings.relay),using=auth.value==='account';
    const local=tokenlessLocal(settings)&&(!workspace?endpoint(settings)===connectionOwner?.target:true);
    input.closest('label').hidden=local;remember.closest('label').hidden=local;auth.closest('label').hidden=local;
    if(!workspace)$('relay-code').closest('label').hidden=local;
    if(local){$(workspace?'workspace-account-status':'connection-account-status').textContent='本机 127.0.0.1 直连无需 Token 和房间号。';return;}
    input.readOnly=using;remember.disabled=using;if(using){input.value=account?'••••••••':'';remember.checked=false;}else if(input.value==='••••••••')input.value='';
    $(workspace?'workspace-account-status':'connection-account-status').textContent=using?(account?'中继账号：'+account.account.email+'；凭据仅用于此中继，不作为电脑 Token。':'请先登录此中继，并选择账号授权的电脑。'):'手动 Token 只用于所填电脑；账号登录单独管理。';
  }
  $('workspace-auth').onchange=()=>{if($('workspace-auth').value==='manual')workspaceAuthorization=null;renderAuthField('workspace');};
  $('connection-auth').onchange=()=>{
    if($('connection-auth').value==='account'){
      const settings={relay:$('relay-url').value,code:$('relay-code').value},account=accountFor(settings.relay);
      connectionAuthorization=account&&account.hosts.some(host=>host.code===settings.code&&host.online)?{target:endpoint(settings),url:account.url,account}:null;
    }else connectionAuthorization=null;
    renderAuthField('connection');
  };
  $('relay-url').addEventListener('input',()=>renderAuthField('connection'));
  function renderAccountPanel(){
    let account=null,message='';try{const url=accountTransport($('account-relay-url').value||$('default-relay').value);account=accountFor(url);message=account?'已登录 '+account.account.email+' · '+(account.phase==='connected'?'授权电脑目录已连接':account.phase):'登录后仅显示管理员授予此账号的电脑。';}catch(error){message=error.message;}
    $('relay-account-status').textContent=message;$('relay-account-logout').disabled=!account;$('relay-account-computers').disabled=!account?.hosts.some(host=>host.online);
    if(account&&!$('relay-account-email').value)$('relay-account-email').value=account.account.email;
  }
  function cancelAccountLogin(){
    accountLoginGeneration++;if(accountLogin){clearTimeout(accountLogin.timer);accountLogin.socket.onclose=null;accountLogin.socket.close();accountLogin=null;}
    $('relay-account-password').value='';$('relay-account-login').disabled=false;
  }
  $('account-relay-url').addEventListener('input',()=>{cancelAccountLogin();renderAccountPanel();});
  $('connection-dialog').addEventListener('cancel',()=>{cancelAccountLogin();returnToWorkspace=false;});
  for(const id of ['relay-account-email','relay-account-password'])$(id).addEventListener('keydown',event=>{
    if(event.key==='Enter'){event.preventDefault();$('relay-account-login').click();}
  });
  let returnToWorkspace=false;
  $('workspace-account-login').onclick=()=>{
    const relay=$('workspace-relay').value;returnToWorkspace=true;$('workspace-dialog').close();showConnection();$('account-relay-url').value=relay||$('default-relay').value;renderAccountPanel();$('relay-account-email').focus();
  };
  $('relay-account-computers').onclick=()=>{returnToWorkspace=false;$('connection-dialog').close();showWorkspace();};
  $('relay-account-login').onclick=()=>{
    const email=$('relay-account-email').value.trim(),password=$('relay-account-password').value;let url;
    try{url=accountTransport($('account-relay-url').value||$('default-relay').value);}catch(error){$('relay-account-status').textContent=error.message;$('relay-account-password').value='';return;}
    if(!email||!password){$('relay-account-status').textContent='请填写中继账号邮箱和密码。';return;}
    if(!relayAccounts.has(url)&&relayAccounts.size>=32){$('relay-account-status').textContent='最多登录 32 个中继。';return;}
    cancelAccountLogin();const generation=accountLoginGeneration,socket=new WebSocket(url);
    const request={socket,url,generation,timer:0};accountLogin=request;$('relay-account-login').disabled=true;$('relay-account-status').textContent='正在登录…';
    const live=()=>accountLogin===request&&accountLoginGeneration===generation&&relayURL($('account-relay-url').value||$('default-relay').value)===url;
    const finish=message=>{const current=live();clearTimeout(request.timer);if(accountLogin===request){accountLogin=null;$('relay-account-login').disabled=false;}socket.onclose=null;socket.close();if(current)$('relay-account-status').textContent=message;};
    request.timer=setTimeout(()=>finish('账号登录超时，请检查中继地址与加密配置。'),5000);
    socket.onopen=()=>{if(live())socket.send(JSON.stringify({op:'relay_login',email,password}));else finish('');};
    socket.onmessage=event=>{
      if(!live()){finish('');return;}if(typeof event.data!=='string'||event.data.length>1048576)return;
      try{
        const data=JSON.parse(event.data);if(data.op!=='relay_auth')return;
        if(data.error){finish('登录失败：'+String(data.error));return;}
        if(typeof data.session!=='string'||!data.session||data.session.length>4096||!Number.isFinite(data.expires)||data.expires*1000<=Date.now()||typeof data.account?.id!=='string'){finish('中继返回了无效账号会话。');return;}
        finish('登录成功，正在获取授权电脑。');const previous=relayAccounts.get(url);
        if(previous){
          if(previous.account.id!==data.account.id)forgetAccount(previous,'已切换中继账号；旧账号视图已清除。');
          else{stopAccountDirectory(previous);clearTimeout(previous.expiryTimer);}
        }
        const account={url,session:data.session,expires:data.expires,account:{id:data.account.id,email:String(data.account.email||email).slice(0,254)},generation:0,ws:null,retry:0,retryTimer:0,expiryTimer:0,hosts:[],phase:'connecting',revision:0};
        relayAccounts.set(url,account);saveRelayAccounts();scheduleAccountExpiry(account);connectAccountDirectory(account);renderAccountPanel();
        for(const host of hosts.values())if(host.config.authMode==='account'&&relayURL(host.config.relay)===url)connect(host);
        if(returnToWorkspace){returnToWorkspace=false;$('connection-dialog').close();showWorkspace(editingHost);}
      }catch{finish('无法解析中继账号响应。');}
    };
    socket.onerror=()=>finish('账号连接失败，请检查 HTTPS/WSS 和证书。');socket.onclose=()=>finish('账号连接已关闭，登录未完成。');
  };
  $('relay-account-logout').onclick=()=>{
    const account=accountFor($('account-relay-url').value);if(!account)return;
    const url=accountTransport(account.url),session=account.session;forgetAccount(account,'已注销；相关账号连接已停止。');
    const socket=new WebSocket(url),timer=setTimeout(()=>socket.close(),2000);
    socket.onopen=()=>{socket.send(JSON.stringify({op:'relay_logout',session}));};socket.onmessage=()=>socket.close();socket.onclose=()=>clearTimeout(timer);socket.onerror=()=>socket.close();
  };
  function stopDirectory(directory){
    directory.generation++;clearTimeout(directory.retryTimer);
    if(directory.ws){directory.ws.onclose=null;directory.ws.close();directory.ws=null;}
  }
  let lastRelayRefresh=-Infinity;
  function refreshRelayCatalogs(){
    const now=performance.now();if(now-lastRelayRefresh<1000)return;lastRelayRefresh=now;
    refreshDirectories();
    for(const directory of directories.values()){
      if(directory.ws?.readyState===WebSocket.OPEN){
        directory.ws.send(JSON.stringify({op:'watch',rooms:directory.rooms,tokens:directory.tokens}));
      }else if(directory.ws?.readyState!==WebSocket.CONNECTING){
        directory.revision=0;connectDirectory(directory);
      }
    }
    for(const account of relayAccounts.values()){
      if(account.ws?.readyState===WebSocket.OPEN){
        account.ws.send(JSON.stringify({op:'watch',session:account.session}));
      }else if(account.ws?.readyState!==WebSocket.CONNECTING)connectAccountDirectory(account);
    }
    for(const host of hosts.values()){
      if(host.connected){
        const sessions=openTabs.map(id=>panes.get(id)).filter(pane=>pane?.host===host&&sessionInfo(pane.sid)).map(pane=>pane.raw);
        send(owner(host),16,{sessions});
      }else if((host.config.token||accountFor(host.config.relay))&&(!host.ws||host.ws.readyState>=WebSocket.CLOSING))connect(host);
    }
    const count=directories.size+relayAccounts.size;
    status(count?'已请求刷新 '+count+' 个中继的授权房间及窗口列表。':'尚未配置可用中继，请先连接工作区。');
  }
  function refreshDirectories(){
    const wanted=new Map();
    // Invalid saved scope bindings must not reopen a broader implicit home scope.
    const explicitScope=(url,token)=>relayProfiles.some(profile=>profile.endpoint===url&&(profileToken(profile)===token||[sessionStorage,localStorage].some(storage=>read(storage,'sma.workspace.profile-token.'+profile.id)===token)));
    for(const profile of relayProfiles){const token=profileToken(profile);if(!token)continue;if(!wanted.has(profile.endpoint))wanted.set(profile.endpoint,[]);wanted.get(profile.endpoint).push({code:profile.code||'',token,onlyRoom:!!profile.code,excludedRooms:profile.excludedRooms||[]});}
    for(const host of [...hosts.values()].sort((a,b)=>Number(b.connected)-Number(a.connected)))if(!host.autoDirectory&&host.config.authMode!=='account'&&host.config.code&&host.config.token){
      const url=JSON.parse(endpoint(host.config))[0];if(explicitScope(url,host.config.token))continue;if(!wanted.has(url))wanted.set(url,[]);
      const rooms=wanted.get(url);if(!rooms.some(room=>room.code===host.config.code)&&rooms.length<64)rooms.push({code:host.config.code,token:host.config.token});
    }
    const local=hosts.get('local');
    if(homeRelayAccess()&&local?.config.token)for(const relay of homeRelays){
      if(typeof relay.url!=='string')continue;
      const code=typeof relay.code==='string'?relay.code:'';
      let url;try{url=JSON.parse(endpoint({relay:relay.url,code}))[0];}catch{continue;}
      if(explicitScope(url,local.config.token))continue;
      if(!wanted.has(url))wanted.set(url,[]);const rooms=wanted.get(url);
      if(!rooms.some(room=>room.code===code&&room.token===local.config.token)&&rooms.length<64)rooms.push({code,token:local.config.token});
    }
    for(const [url,directory] of directories)if(!wanted.has(url)){stopDirectory(directory);syncDiscoveredHosts(directory,[]);directories.delete(url);}
    for(const [url,rooms] of wanted){
      let directory=directories.get(url);
      if(!directory){directory={url,rooms:[],generation:0,ws:null,retry:0,retryTimer:0,signature:'',hosts:[],phase:'connecting',revision:0};directories.set(url,directory);}
      const signature=JSON.stringify(rooms);if(directory.signature===signature)continue;
      const oldTokens=directory.tokens||[],tokens=[...new Set(rooms.map(room=>room.token))].slice(0,32);
      const retained=(directory.hosts||[]).filter(host=>Number.isInteger(host.token_index)&&tokens.includes(oldTokens[host.token_index])&&rooms.some(scope=>scope.token===oldTokens[host.token_index]&&roomAllowed(scope,host.code))).map(host=>({...host,token_index:tokens.indexOf(oldTokens[host.token_index])}));
      directory.availableHosts=(directory.availableHosts||directory.hosts||[]).filter(host=>tokens.includes(oldTokens[host.token_index])&&rooms.some(scope=>scope.token===oldTokens[host.token_index]&&(!scope.onlyRoom||scope.code===host.code))).map(host=>({...host,token_index:tokens.indexOf(oldTokens[host.token_index])}));
      directory.rooms=rooms.filter((room,index)=>room.code&&rooms.findIndex(item=>item.code===room.code)===index).map(({code,token})=>({code,token}));directory.scopes=rooms;directory.tokens=tokens;directory.signature=signature;directory.hosts=retained;directory.selfRooms??=new Set();directory.revision=0;
      syncDiscoveredHosts(directory,retained);
      // Close before replacing credentials, so stale authorized metadata cannot be displayed.
      connectDirectory(directory);
    }
    renderDiscovery();
  }
  function connectDirectory(directory){
    stopDirectory(directory);const generation=directory.generation;directory.phase='connecting';
    const live=()=>directories.get(directory.url)===directory&&directory.generation===generation;
    const socket=new WebSocket(directory.url);directory.ws=socket;
    socket.onopen=()=>{if(live())socket.send(JSON.stringify({op:'watch',rooms:directory.rooms,tokens:directory.tokens}));};
    socket.onmessage=event=>{
      if(!live()||typeof event.data!=='string'||event.data.length>1048576)return;
      try{
        const data=JSON.parse(event.data);
        if(data.op!=='directory'||!Array.isArray(data.hosts)||data.hosts.length>64||!Number.isSafeInteger(data.revision)||data.revision<directory.revision)return;
        const known=new Set(directory.rooms.map(room=>room.code));
        const discovery=data.capabilities?.token_discovery===true;
        directory.hosts=data.hosts.filter(host=>typeof host.code==='string'&&host.code.length>0&&host.code.length<=128&&(known.has(host.code)||(discovery&&Number.isInteger(host.token_index)&&host.token_index>=0&&host.token_index<directory.tokens.length))).map(host=>({code:host.code,online:host.online===true,
          ...(discovery&&Number.isInteger(host.token_index)&&host.token_index>=0&&host.token_index<directory.tokens.length?{token_index:host.token_index}:{}),
          ...(host.online===true?{machine:String(host.machine||'').slice(0,40),project:String(host.project||'').slice(0,40)}:{})}));
        directory.availableHosts=directory.hosts.map(host=>Number.isInteger(host.token_index)?host:{...host,token_index:directory.tokens.indexOf(directory.rooms.find(room=>room.code===host.code)?.token)}).filter(host=>directory.scopes.some(scope=>scope.token===directory.tokens[host.token_index]&&(!scope.onlyRoom||scope.code===host.code)));
        directory.hosts=directory.availableHosts.filter(host=>directory.scopes.some(scope=>scope.token===directory.tokens[host.token_index]&&roomAllowed(scope,host.code)));
        directory.revision=data.revision;directory.phase='connected';directory.retry=0;syncDiscoveredHosts(directory,directory.hosts);renderDiscovery();
      }catch{directory.phase='unsupported';directory.hosts=[];directory.availableHosts=[];syncDiscoveredHosts(directory,[]);renderDiscovery();}
    };
    socket.onerror=()=>{};
    socket.onclose=event=>{
      if(!live())return;directory.hosts=[];directory.availableHosts=[];directory.phase=[4000,4001,4003].includes(event.code)?'unsupported':'offline';syncDiscoveredHosts(directory,[]);renderDiscovery();
      if(directory.phase!=='unsupported')directory.retryTimer=setTimeout(()=>{if(live())connectDirectory(directory);},C.retryDelay(directory.retry++));
    };
  }
  function homeRelayAccess(){
    const local=hosts.get('local');if(!local||local.config.code||local.config.authMode==='account')return false;
    try{return ['localhost','127.0.0.1','[::1]','::1'].includes(new URL(C.socketURL(local.config.relay,location.origin)).hostname);}catch{return false;}
  }
  function isLocalRelayCopy(host){
    // Frozen hosts omitted their room code. Recognize the same authenticated
    // terminal inventory rather than treating a matching computer name as proof.
    const local=hosts.get('local');if(!homeRelayAccess()||!local?.connected||!host.catalog.length)return false;
    if(!homeRelays.some(relay=>{try{return JSON.parse(endpoint({relay:relay.url,code:''}))[0]===host.autoDirectory;}catch{return false;}}))return false;
    if(!local.identity.machine||host.identity.machine!==local.identity.machine||host.identity.project!==local.identity.project)return false;
    const inventory=value=>JSON.stringify(value.map(win=>[win.id,(win.sessions||[]).map(session=>session.id).sort()]).sort((a,b)=>a[0].localeCompare(b[0])));
    return inventory(host.catalog)===inventory(local.catalog);
  }
  function syncDiscoveredHosts(directory,items){
    const wanted=new Set();let changed=false;
    for(const item of items){
      if(!item.online||directory.selfRooms?.has(item.code)||!Number.isInteger(item.token_index)||!directory.tokens?.[item.token_index])continue;
      const token=directory.tokens[item.token_index],target=JSON.stringify([directory.url,item.code]);
      if([...hosts.values()].some(host=>!host.autoDirectory&&endpoint(host.config)===target))continue;
      if(homeRelayAccess()&&homeRelays.some(relay=>{try{return endpoint({relay:relay.url,code:relay.code})===target;}catch{return false;}}))continue;
      const id='discovered:'+target;wanted.add(id);let host=hosts.get(id);
      if(!host){if(hosts.size>=64)continue;host=new HostConnection(id,item.machine||item.code,{relay:directory.url,code:item.code,token,authMode:'manual'});host.autoDirectory=directory.url;hosts.set(id,host);changed=true;connect(host);}
      else if(host.config.token!==token||host.phase==='offline'){host.config.token=token;connect(host);}
      host.name=item.machine||item.code;host.identity={machine:item.machine,project:item.project};
    }
    for(const host of [...hosts.values()])if(host.autoDirectory===directory.url&&!wanted.has(host.id)){
      detachHost(host);changed=true;if(selectedHost===host.id){selectedHost='local';save(sessionStorage,'sma.workspace.activeHost','local');}
    }
    if(changed){aggregateCatalog();renderTree();renderTabs();renderLayout();subscribe();updateConnection();updateFooter();}
  }
  function renderDiscovery(){
    renderRelayProfiles();
    const list=$('workspace-known');if(!list)return;const selected=list.value;list.replaceChildren();
    const placeholder=node('option','','选择已授权电脑');placeholder.value='';list.append(placeholder);
    for(const account of relayAccounts.values())if(accountFor(account.url)===account)for(const host of account.hosts)if(host.online){
      const option=node('option','',[account.account.email,host.project,host.machine,host.code].filter(Boolean).join(' / '));option.value=JSON.stringify(['account',account.url,host.code]);list.append(option);
    }
    for(const directory of directories.values())for(const host of directory.hosts)if(host.online){
      const option=node('option','',[host.project,host.machine,host.code].filter(Boolean).join(' / '));option.value=JSON.stringify([directory.url,host.code]);list.append(option);
    }
    if([...list.options].some(option=>option.value===selected))list.value=selected;
    $('workspace-directory-status').textContent=relayAccounts.size?'已登录账号的授权在线电脑会自动列出；手动 Token 目录独立保留。':[...directories.values()].some(directory=>directory.phase==='connected')?'仅显示此设备已授权的已知电脑；不会公开其他房间。':directories.size?'目录暂不可用；各电脑的终端连接独立工作。':'登录中继账号自动发现授权电脑，或手填房间码和 Token。';
  }
  $('workspace-known').onchange=()=>{
    const value=$('workspace-known').value;if(!value)return;
    const choice=JSON.parse(value);
    if(choice[0]==='account'){
      const [,url,code]=choice,account=accountFor(url),host=account?.hosts.find(host=>host.code===code&&host.online);if(!host)return;
      $('workspace-name').value=host.machine||host.project||'电脑 '+code;$('workspace-relay').value=host.endpoint;$('workspace-code').value=host.code;
      $('workspace-auth').value='account';workspaceAuthorization={target:endpoint({relay:host.endpoint,code}),url,code,account};renderAuthField('workspace');
      $('workspace-verification').textContent='账号授权在线电脑：'+[host.machine,host.project].filter(Boolean).join(' / ');return;
    }
    const [url,code]=choice,directory=directories.get(url),host=directory?.hosts.find(host=>host.code===code&&host.online);
    const enrolled=[...hosts.values()].find(host=>host.config.authMode!=='account'&&host.config.code===code&&relayURL(host.config.relay)===url);
    if(!host||!enrolled)return;
    if(enrolled.autoDirectory){$('workspace-dialog').close();switchHost(enrolled.id);return;}
    showWorkspace(enrolled.id);$('workspace-verification').textContent='已授权在线电脑：'+[host.machine,host.project].filter(Boolean).join(' / ');
  };
  $('workspace-verify').onclick=()=>{
    const code=$('workspace-code').value.trim(),token=$('workspace-token').value.trim(),relay=$('workspace-relay').value.trim();let url;
    if($('workspace-auth').value==='account'){$('workspace-verification').textContent=authorizedSelection('workspace',{relay,code})?'账号已授权此在线电脑。':'请登录并重新选择授权电脑。';return;}
    try{url=JSON.parse(endpoint({relay,code}))[0];}catch(error){$('workspace-verification').textContent=error.message;return;}
    const directory=directories.get(url),known=directory?.rooms.find(room=>room.code===code&&room.token===token),identity=known&&directory.hosts.find(host=>host.code===code&&host.online);
    if(identity){$('workspace-verification').textContent='已验证在线电脑：'+[identity.machine,identity.project].filter(Boolean).join(' / ');return;}
    // An explicit verification can authenticate one candidate; it never asks for a roster.
    if(!code||!token){$('workspace-verification').textContent='请填写此电脑的房间码和 Token。';return;}
    const request=JSON.stringify([url,code,token]),socket=new WebSocket(url);let complete=false;
    $('workspace-verification').textContent='正在验证已知电脑…';
    const finish=message=>{if(complete)return;complete=true;clearTimeout(timer);socket.close();
      let current='';try{current=JSON.stringify([JSON.parse(endpoint({relay:$('workspace-relay').value.trim(),code:$('workspace-code').value.trim()}))[0],$('workspace-code').value.trim(),$('workspace-token').value.trim()]);}catch{}
      if($('workspace-dialog').open&&request===current)$('workspace-verification').textContent=message;
    };
    const timer=setTimeout(()=>finish('未能验证；电脑未上线、凭据无效或中继不支持目录。'),2500);
    socket.onopen=()=>socket.send(JSON.stringify({op:'watch',rooms:[{code,token}]}));
    socket.onmessage=event=>{try{const data=JSON.parse(event.data),host=data.op==='directory'&&data.hosts?.find(host=>host.code===code&&host.online);finish(host?'已验证在线电脑：'+[String(host.machine||'').slice(0,40),String(host.project||'').slice(0,40)].filter(Boolean).join(' / '):'无法验证此电脑的在线身份。');}catch{finish('中继不支持已知电脑目录。');}};
    socket.onerror=()=>finish('无法连接电脑目录。');socket.onclose=()=>finish('无法验证此电脑的在线身份。');
  };
  const meterTimer=setInterval(()=>{for(const host of hosts.values())host.rates=host.meter.sample(performance.now());updateConnection();renderHosts();},1000);
  const activityTimer=setInterval(updateSessionDots,300);
  addEventListener('beforeunload',()=>{closeDaemonMonitor();cancelRelayProbe();clearInterval(meterTimer);clearInterval(activityTimer);for(const host of hosts.values())stopHost(host);for(const directory of directories.values())stopDirectory(directory);cancelAccountLogin();for(const account of relayAccounts.values()){stopAccountDirectory(account);clearTimeout(account.expiryTimer);}});
  // Launch secrets are consumed once. Fragments never reach HTTP access logs.
  if(params.has('token')||launch.has('token')){
    save(sessionStorage,'sma.workspace.token',config.token);const clean=new URL(location.href);clean.searchParams.delete('token');launch.delete('token');clean.hash=launch.toString();history.replaceState(null,'',clean);
  }
  window.smaWorkspace={get activeSession(){return active;},get terminal(){return panes.get(active)?.term;},get panes(){return panes;},metrics,
    get activePane(){return panes.get(active);},get activeHost(){return currentHost();},get connections(){return hosts;},get directories(){return directories;},get relayAccounts(){return relayAccounts;},
    get isComposing(){return [...panes.values()].some(pane=>pane.composing);},
    captureUIState:()=>({selectedHost,active,tabs:[...openTabs],layout,renderer}),
    pauseForUIUpdate:()=>{
      const states=[...panes.values()].map(pane=>({pane,disabled:pane.term.options.disableStdin,readonly:pane.term.textarea.readOnly}));
      for(const {pane} of states){pane.term.options.disableStdin=true;pane.term.textarea.readOnly=true;}
      return ()=>{for(const {pane,disabled,readonly} of states)if(livePane(pane)){pane.term.options.disableStdin=disabled;pane.term.textarea.readOnly=readonly;}};
    },
    get effectiveRenderer(){return panes.get(active)?.renderer;},get connected(){return !!currentHost()?.connected;},get layout(){return layout;},
    openSession:(id,takeover=true)=>openView(sessionInfo(id)?id:key(currentHost(),id),takeover),openHostSession:(hostID,id,takeover=true)=>{const host=hosts.get(hostID);if(host)openView(key(host,id),takeover);},switchHost,split,
    closeView:id=>removeView(panes.has(id)?id:key(currentHost(),id)),takeControl,redraw:()=>redrawPane(panes.get(active)),setRenderer:value=>{$('renderer').value=C.rendererName(value);$('renderer').onchange();},
    get controls(){return Object.fromEntries([...hosts.values()].flatMap(host=>Object.entries(host.controls).map(([id,value])=>[key(host,id),value])));}};
  function bootstrap(){
    loadRelayAccounts();
    if(!explicitToken){
      const established={relay:read(localStorage,'sma.workspace.relay'),code:read(localStorage,'sma.workspace.code')};
      const target=endpoint(homeConfig),bound=[sessionStorage,localStorage].some(storage=>read(storage,'sma.workspace.token.target')===target);
      homeConfig.token=bound||endpoint(established)===target?boundToken('local',homeConfig):'';config.token=homeConfig.token;
    }
    else save(sessionStorage,'sma.workspace.token.target',endpoint(homeConfig));
    const home=new HostConnection('local',homeConfig.code?'当前连接':'本机',homeConfig);hosts.set(home.id,home);
    for(const saved of savedHosts)hosts.set(saved.id,new HostConnection(saved.id,saved.name,{relay:saved.relay,code:saved.code,token:saved.authMode==='account'?'':boundToken(saved.id,saved),authMode:saved.authMode}));
    const selected=restoredUI?.selectedHost||read(sessionStorage,'sma.workspace.activeHost');selectedHost=hosts.has(selected)?selected:'local';
    for(const host of hosts.values())connect(host);for(const account of relayAccounts.values())connectAccountDirectory(account);refreshDirectories();renderTree();updateFooter();
    if(!tokenlessLocal(config)&&!config.token&&!config.code)setTimeout(()=>{if(!userConnectedOnce)showRelayProfiles();},1500);
  }
  bootstrap();
  window.NativeUpdates?.uiReady();
})();

;
/* Independent file broker JSON transport; no terminal or native API dependency. */
(function(root,factory){
  'use strict';
  const api=factory(root);
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.SuperMonoFileClient=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(root){
  'use strict';
  const MAX_FRAME=262144,TIMEOUT=15000,MAX_PENDING=64;
  const encoder=new TextEncoder();
  class FileClientError extends Error{constructor(code){super(code);this.name='FileClientError';this.code=code;}}
  const fail=code=>{throw new FileClientError(code);};
  const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
  function parse(value){
    if(typeof value!=='string'||!value||value.length>4096||/[\s\u0000-\u001f\u007f\\?#]/u.test(value))fail('invalid_endpoint');
    let url;try{url=new URL(value);}catch{fail('invalid_endpoint');}
    if(url.username||url.password||!url.hostname||url.port==='0')fail('invalid_endpoint');
    if(['ws:','http:'].includes(url.protocol)){
      const authority=value.slice(value.indexOf('://')+3).split('/')[0];
      if(!/^(?:localhost|127\.0\.0\.1|\[::1\])(?::[0-9]+)?$/i.test(authority))fail('insecure_endpoint');
    }
    return url;
  }
  function brokerURL(value){
    const url=parse(value);
    if(!['https:','http:','wss:','ws:'].includes(url.protocol))fail('invalid_endpoint');
    const protocol=['https:','wss:'].includes(url.protocol)?'wss:':'ws:';
    return protocol+'//'+url.host+'/file/ws';
  }
  function endpoint(value){
    const url=parse(value);
    if(!['wss:','ws:'].includes(url.protocol)||url.pathname!=='/file/ws')fail('invalid_endpoint');
    return url.href;
  }
  function nonce(){
    if(!root.crypto?.getRandomValues)fail('unsupported');
    return [...root.crypto.getRandomValues(new Uint8Array(12))].map(value=>value.toString(16).padStart(2,'0')).join('');
  }
  function createClient(options){
    if(!object(options))fail('invalid_configuration');
    const url=endpoint(options.url),room=options.room,token=options.token;
    if(typeof room!=='string'||!room||room.length>128||room!==room.trim()||/[\u0000-\u001f\u007f]/u.test(room))fail('invalid_room');
    if(typeof token!=='string'||!token||token.length>8192||/[\u0000-\u001f\u007f]/u.test(token))fail('missing_token');
    let socket=null,epoch=0,closed=false,ready=null,opening=null,sequence=0,prefix='';
    const pending=new Map();
    function disconnect(code,ws,generation){
      if(ws!==socket||generation!==epoch)return;
      socket=null;epoch++;ready=null;
      if(opening){clearTimeout(opening.timer);opening.reject(new FileClientError(code));opening=null;}
      for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(new FileClientError(code));}
      pending.clear();
      try{ws?.close();}catch{}
    }
    function connect(){
      if(closed)return Promise.reject(new FileClientError('closed'));
      if(ready&&socket?.readyState===1)return Promise.resolve(ready);
      if(opening)return opening.promise;
      if(typeof root.WebSocket!=='function')return Promise.reject(new FileClientError('unsupported'));
      prefix=nonce();sequence=0;
      const generation=++epoch,hello=prefix+'_hello';
      let ws;try{ws=new root.WebSocket(url);}catch{return Promise.reject(new FileClientError('connection_failed'));}
      socket=ws;
      let resolve,reject;
      const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});
      const timer=setTimeout(()=>disconnect('ready_timeout',ws,generation),TIMEOUT);
      opening={promise,resolve,reject,timer};
      const current=()=>socket===ws&&epoch===generation;
      ws.onopen=()=>{
        if(!current())return;
        try{ws.send(JSON.stringify({protocol:'sma-files-1',id:hello,role:'client',room,token}));}
        catch{disconnect('connection_failed',ws,generation);}
      };
      ws.onmessage=event=>{
        if(!current())return;
        let message;
        try{
          if(typeof event.data!=='string'||encoder.encode(event.data).length>MAX_FRAME)fail('invalid_response');
          message=JSON.parse(event.data);if(!object(message))fail('invalid_response');
        }catch{disconnect('invalid_response',ws,generation);return;}
        if(!ready){
          if(message.type!=='ready'||message.id!==hello||message.role!=='client'||message.room!==room||typeof message.agent_online!=='boolean'){
            disconnect('invalid_response',ws,generation);return;
          }
          ready={room,agent_online:message.agent_online};
          const entry=opening;opening=null;clearTimeout(entry.timer);entry.resolve(ready);return;
        }
        if(message.type!=='response'||typeof message.id!=='string')return;
        const entry=pending.get(message.id);if(!entry)return;
        pending.delete(message.id);clearTimeout(entry.timer);
        if(message.ok===true&&object(message.result))entry.resolve(message.result);
        else if(message.ok===false){const code=typeof message.error==='string'&&/^[a-z_]{1,64}$/.test(message.error)?message.error:'service_unavailable';entry.reject(new FileClientError(code));}
        else entry.reject(new FileClientError('invalid_response'));
      };
      ws.onerror=()=>disconnect(opening?'connection_failed':'disconnected',ws,generation);
      ws.onclose=()=>disconnect(opening?'authentication_failed':'disconnected',ws,generation);
      return promise;
    }
    async function request(action,session,data={}){
      if(typeof action!=='string'||action.length>64||!/^[a-z]+(?:\.[a-z]+)+$/.test(action)
        ||typeof session!=='string'||!session||session.length>256||/[\u0000-\u001f\u007f]/u.test(session)||!object(data))fail('invalid_request');
      // Validate and copy before connecting; invalid requests must not send credentials.
      let copied;try{copied=JSON.parse(JSON.stringify(data));}catch{fail('invalid_request');}
      if(!object(copied))fail('invalid_request');
      if(encoder.encode(JSON.stringify({type:'request',id:'x'.repeat(64),action,session,data:copied})).length>MAX_FRAME)fail('request_too_large');
      await connect();
      if(closed||!socket||socket.readyState!==1)fail('disconnected');
      if(pending.size>=MAX_PENDING)fail('service_busy');
      if(socket.bufferedAmount>MAX_FRAME*4)fail('service_busy');
      const ws=socket,generation=epoch,id=prefix+'_'+(++sequence).toString(36);
      const raw=JSON.stringify({type:'request',id,action,session,data:copied});
      return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{if(pending.delete(id))reject(new FileClientError('request_timeout'));},TIMEOUT);
        pending.set(id,{resolve,reject,timer});
        try{if(ws!==socket||generation!==epoch)fail('disconnected');ws.send(raw);}
        catch{disconnect('disconnected',ws,generation);}
      });
    }
    function close(){closed=true;disconnect('closed',socket,epoch);}
    return {connect,request,close,get connected(){return !!ready&&socket?.readyState===1;},get pendingCount(){return pending.size;}};
  }
  return {createClient,brokerURL,FileClientError,MAX_FRAME};
});

;
/* Optional file-workspace footer. Captured transfers survive ordinary tab changes. */
(function(){
  'use strict';
  if(typeof window==='undefined')return;
  const root=window;let installing=false,stopped=false;
  const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
  const text=value=>typeof value==='string'&&value.length<=4096&&!/[\u0000-\u001f\u007f]/u.test(value);
  const integer=value=>Number.isSafeInteger(value)&&value>=0;
  const codeError=code=>Object.assign(new Error(code),{code});
  const messages={host_unavailable:'目标电脑未安装或未连接文件助手。',authentication_failed:'文件服务 Token 验证失败。',
    connection_failed:'无法连接文件服务，请检查服务是否安装。',disconnected:'文件服务连接已断开，请重试。',
    ready_timeout:'文件服务连接超时，请检查服务是否安装。',request_timeout:'目标文件助手响应超时。',
    route_timeout:'目标文件助手未响应。',unauthorized:'目标电脑未确认窗口所有者权限。',
    session_unavailable:'目标窗口已关闭或尚未就绪。',target_changed:'窗口或连接已变化，请重新打开设置。',
    revision_conflict:'目录配置已被修改，请重新加载后再保存。',directory_unavailable:'目标目录不可用；交换目录必须在项目目录内。',
    project_required:'请先在底部选择当前项目目录；附件将保存到该项目的 tmp，不能使用用户主目录。',
    missing_token:'当前连接缺少文件服务 Token。',insecure_endpoint:'文件服务需要 WSS 加密连接。',
    invalid_endpoint:'文件服务地址无效。',unsupported:'当前客户端不支持文件工作区。'};
  const message=error=>Object.hasOwn(messages,error?.code)?messages[error.code]:'文件工作区暂不可用，请检查目标电脑的文件助手。';
  const create=(tag,content)=>{const element=document.createElement(tag);if(content!==undefined)element.textContent=content;return element;};
  const joinTmp=value=>{const separator=value.includes('\\')?'\\':'/';return value.replace(/[\\/]+$/,'')+separator+'tmp';};
  const normal=value=>value.replace(/\\/g,'/').replace(/\/+$/,'');
  async function boot(){
    if(stopped||installing||root.SuperMonoFileWorkspaces||!root.smaWorkspace||!root.SuperMonoFileClient)return;
    const native=root.pywebview?.api?.file_exchange_config;
    if(!object(root.SuperMonoFileWorkspaceConfig)&&typeof native!=='function')return;
    installing=true;
    let nativeConfig;
    try{nativeConfig=object(root.SuperMonoFileWorkspaceConfig)?root.SuperMonoFileWorkspaceConfig:await native();}
    catch{installing=false;return;}
    installing=false;
    if(stopped||!object(nativeConfig)||nativeConfig.enabled!==true)return;
    const W=root.smaWorkspace,F=root.SuperMonoFileClient,footer=document.querySelector('main footer')||document.querySelector('footer');
    if(!footer)return;
    let destroyed=false,active=null,reading=0,modalTarget=null,modalRevision=null,browseSequence=0,browseField='',browsePage=null,autoExchange=false;
    const clients=[],originalStatus=document.getElementById('status'),statusHidden=originalStatus?.hidden;
    const originalFooter=footer.getAttribute('data-file-workspaces');
    function config(){return object(root.SuperMonoFileWorkspaceConfig)?root.SuperMonoFileWorkspaceConfig:nativeConfig;}
    function transport(host){
      const cfg=config(),settings=host?.config;
      if(!cfg||cfg.enabled!==true||!settings||typeof settings.token!=='string'||!settings.token)throw codeError('missing_token');
      const code=typeof settings.code==='string'?settings.code:'';
      const local=!code&&host.id==='local';
      const room=local?cfg.local_room:code;
      if(typeof room!=='string'||!room||room.length>128||room!==room.trim())throw codeError('unsupported');
      const endpoint=F.brokerURL(local?cfg.broker_url:settings.relay);
      return {host,hostID:host.id,ws:host.ws,generation:host.generation,token:settings.token,room,endpoint,
              relay:settings.relay,code:settings.code,authMode:settings.authMode};
    }
    function sameTransport(a,b){return !!a&&!!b&&['host','hostID','ws','generation','token','room','endpoint','relay','code','authMode'].every(key=>a[key]===b[key]);}
    function liveTransport(value){
      try{return !destroyed&&value.host.connected&&value.ws?.readyState===1
        &&W.connections.get(value.hostID)===value.host&&sameTransport(value,transport(value.host));}catch{return false;}
    }
    function windowFor(host,session){return host.catalog?.find(win=>(win.sessions||[]).some(item=>item.id===session));}
    function captureTarget(){
      const pane=W.activePane,key=W.activeSession;
      if(!pane||!key||W.panes.get(key)!==pane||!pane.ready||pane.generation!==pane.host?.generation)return null;
      const binding=transport(pane.host),win=windowFor(pane.host,pane.raw);
      if(!liveTransport(binding)||!win||typeof win.id!=='string'||typeof pane.raw!=='string')return null;
      return Object.freeze({...binding,pane,key,session:pane.raw,window_id:win.id,paneGeneration:pane.generation,
        machine:String(pane.host.name||pane.host.id).slice(0,128),title:String(win.title||pane.raw).slice(0,128)});
    }
    function isCurrent(target){return !!target&&liveTransport(target)&&W.panes.get(target.key)===target.pane
      &&target.pane.host===target.host&&target.pane.raw===target.session&&target.pane.ready
      &&target.pane.generation===target.paneGeneration&&target.paneGeneration===target.generation
      &&windowFor(target.host,target.session)?.id===target.window_id;}
    const isActive=target=>isCurrent(target)&&W.activePane===target.pane&&W.activeSession===target.key;
    function prune(){for(let i=clients.length-1;i>=0;i--)if(!liveTransport(clients[i])){clients[i].client.close();clients.splice(i,1);}}
    function getClient(target){
      if(!isCurrent(target))throw codeError('target_changed');
      prune();let entry=clients.find(item=>sameTransport(item,target));
      if(!entry){if(clients.length>=128)throw codeError('service_busy');entry={...target,client:F.createClient({url:target.endpoint,room:target.room,token:target.token})};clients.push(entry);}
      return entry.client;
    }
    async function request(target,action,data={}){
      if(!isCurrent(target))throw codeError('target_changed');
      const client=getClient(target);await client.connect();
      if(!isCurrent(target))throw codeError('target_changed');
      const result=await client.request(action,target.session,data);
      if(!isCurrent(target))throw codeError('target_changed');
      return result;
    }
    async function uiRequest(target,action,data={}){
      if(!isActive(target))throw codeError('target_changed');
      const client=getClient(target);await client.connect();
      if(!isActive(target))throw codeError('target_changed');
      const result=await client.request(action,target.session,data);
      if(!isActive(target))throw codeError('target_changed');
      return result;
    }
    function workspace(target,value){
      if(!object(value)||value.window_id!==target.window_id||value.session_id!==target.session
        ||typeof value.daemon_epoch!=='string'||!value.daemon_epoch||value.daemon_epoch.length>128
        ||!text(value.project_dir)||!value.project_dir||!text(value.exchange_dir)||!value.exchange_dir||!integer(value.revision))throw codeError('invalid_response');
      return {...value};
    }
    async function getWorkspace(target){return workspace(target,await request(target,'workspace.get',{}));}
    const style=create('style');style.id='file-workspace-style';
    style.textContent=`footer[data-file-workspaces]{min-width:0;height:auto;min-height:29px;flex-wrap:wrap;gap:6px}footer[data-file-workspaces]>.footer-spacer{display:none}#file-workspace-footer{display:grid;grid-template-columns:minmax(0,1fr);flex:1 1 180px;min-width:0;max-width:100%;line-height:1.2}#file-workspace-footer button{min-width:0;max-width:100%;width:100%;min-height:12px;height:12px;padding:0;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px;line-height:12px}#file-workspace-dialog{width:580px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 24px);overflow:auto;overflow-wrap:anywhere}#file-workspace-dialog label{margin:12px 0 4px}#file-workspace-dialog input{width:100%;min-width:0;max-width:100%}#file-workspace-dialog .file-path-row{display:flex;gap:6px;min-width:0}#file-workspace-dialog .file-path-row input{flex:1}#file-workspace-dialog .file-path-row button{flex:none}#file-workspace-browser{margin-top:12px;padding-top:10px;border-top:1px solid #444}#file-workspace-browser nav{display:flex;flex-wrap:wrap;gap:5px}#file-browse-list{display:grid;gap:3px;max-height:220px;overflow:auto;margin:8px 0}#file-browse-list button{text-align:left;overflow-wrap:anywhere;min-width:0;white-space:normal}#file-workspace-state,#file-browse-path{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}#file-workspace-dialog .dialog-actions{flex-wrap:wrap;margin-top:12px}@media(max-width:600px){#file-workspace-footer{flex-basis:100%}#file-workspace-dialog{padding:14px}}`;
    document.head.append(style);
    const paths=create('div');paths.id='file-workspace-footer';paths.setAttribute('aria-label','当前窗口文件目录');
    const projectButton=create('button','项目: 未选择窗口'),exchangeButton=create('button','交换: 未选择窗口');
    projectButton.id='file-workspace-project';exchangeButton.id='file-workspace-exchange';
    projectButton.disabled=exchangeButton.disabled=true;
    projectButton.type=exchangeButton.type='button';paths.append(projectButton,exchangeButton);footer.prepend(paths);
    footer.setAttribute('data-file-workspaces','true');if(originalStatus)originalStatus.hidden=true;
    const dialog=create('dialog');dialog.id='file-workspace-dialog';dialog.setAttribute('aria-label','窗口文件目录');
    const form=create('form'),heading=create('h2','窗口文件目录'),targetLabel=create('p'),note=create('p','交换目录必须位于项目内；留空使用项目/tmp。此设置不会改变终端当前目录。');
    targetLabel.id='file-workspace-target';
    const project=create('input'),exchange=create('input');project.id='file-project';exchange.id='file-exchange';
    project.type=exchange.type='text';project.maxLength=exchange.maxLength=4096;project.autocomplete=exchange.autocomplete='off';project.required=true;
    const projectLabel=create('label','项目目录'),exchangeLabel=create('label','交换目录');projectLabel.htmlFor=project.id;exchangeLabel.htmlFor=exchange.id;
    const projectRow=create('div'),exchangeRow=create('div');projectRow.className=exchangeRow.className='file-path-row';
    const browseProject=create('button','浏览…'),browseExchange=create('button','浏览…');browseProject.id='file-browse-project';browseExchange.id='file-browse-exchange';
    browseProject.type=browseExchange.type='button';projectRow.append(project,browseProject);exchangeRow.append(exchange,browseExchange);
    const browser=create('section');browser.id='file-workspace-browser';browser.hidden=true;
    const browsePath=create('p');browsePath.id='file-browse-path';const nav=create('nav');
    const roots=create('button','驱动器'),parent=create('button','上级目录'),use=create('button','使用此目录'),more=create('button','下一页');
    roots.id='file-browse-roots';parent.id='file-browse-parent';use.id='file-browse-use';more.id='file-browse-more';
    for(const button of [roots,parent,use,more])button.type='button';nav.append(roots,parent,use,more);
    const list=create('div');list.id='file-browse-list';browser.append(browsePath,nav,list);
    const state=create('p');state.id='file-workspace-state';state.setAttribute('role','status');
    const actions=create('div');actions.className='dialog-actions';
    const reload=create('button','重新加载'),cancel=create('button','关闭'),save=create('button','保存目录');
    reload.id='file-workspace-reload';cancel.id='file-workspace-close';save.id='file-workspace-save';
    reload.type=cancel.type='button';save.type='submit';actions.append(reload,cancel,save);
    form.append(heading,targetLabel,note,projectLabel,projectRow,exchangeLabel,exchangeRow,browser,state,actions);dialog.append(form);document.body.append(dialog);
    function display(value,error){
      for(const button of [projectButton,exchangeButton])button.disabled=!active;
      const required=value?.project_status==='selection_required';
      projectButton.textContent='项目: '+(required?'请选择当前项目目录':value?.project_dir||error||'未选择窗口');
      exchangeButton.textContent='交换: '+(required?'选择项目后使用 tmp':value?.exchange_dir||(error?'不可用':'未选择窗口'));
      projectButton.title=exchangeButton.title=required?messages.project_required:'';
      if(!required){projectButton.title=value?.project_dir||error||'';exchangeButton.title=value?.exchange_dir||error||'';}
    }
    async function refresh(){
      let target;try{target=captureTarget();}catch(error){active=null;display(null,message(error));return;}
      active=target;const sequence=++reading;
      if(!target){display(null);return;}
      display(null,'正在读取…');
      try{const value=await getWorkspace(target);if(sequence===reading&&isActive(target))display(value);}
      catch(error){if(sequence===reading&&isActive(target))display(null,message(error));}
    }
    function staleModal(){
      if(dialog.open&&!isActive(modalTarget)){save.disabled=browseProject.disabled=browseExchange.disabled=true;state.textContent=messages.target_changed;browseSequence++;}
    }
    async function loadModal(){
      const target=modalTarget;save.disabled=browseProject.disabled=browseExchange.disabled=true;state.textContent='正在读取目标目录…';
      try{
        const value=workspace(target,await uiRequest(target,'workspace.get',{}));
        if(!dialog.open||modalTarget!==target||!isActive(target))return;
        modalRevision=value.revision;project.value=value.project_dir;exchange.value=value.exchange_dir;
        autoExchange=normal(value.exchange_dir)===normal(joinTmp(value.project_dir));
        state.textContent=value.project_status==='selection_required'?messages.project_required:'';save.disabled=browseProject.disabled=browseExchange.disabled=false;
      }catch(error){if(dialog.open&&modalTarget===target)state.textContent=message(error);}
    }
    function open(){
      let target;try{target=captureTarget();}catch{return;}
      if(!target)return;modalTarget=target;modalRevision=null;browseSequence++;browser.hidden=true;
      targetLabel.textContent=target.machine+' / '+target.title;project.value=exchange.value='';dialog.showModal();loadModal();
    }
    projectButton.onclick=exchangeButton.onclick=open;
    cancel.onclick=()=>{browseSequence++;modalTarget=null;dialog.close();};
    dialog.addEventListener('cancel',()=>{browseSequence++;modalTarget=null;});reload.onclick=()=>{browser.hidden=true;loadModal();};
    project.addEventListener('input',()=>{if(autoExchange)exchange.value=joinTmp(project.value);});
    exchange.addEventListener('input',()=>{autoExchange=false;});
    function validateBrowse(value){
      if(!object(value)||!(value.path===null||text(value.path))||!(value.parent===null||text(value.parent))
        ||!Array.isArray(value.roots)||value.roots.length>26||!value.roots.every(text)
        ||!Array.isArray(value.directories)||value.directories.length>200||!value.directories.every(item=>object(item)&&text(item.name)&&text(item.path))
        ||!integer(value.offset)||!(value.next_offset===null||integer(value.next_offset)&&value.next_offset>value.offset))throw codeError('invalid_response');
      return value;
    }
    async function browse(path=null,offset=0){
      const target=modalTarget,sequence=++browseSequence;browser.hidden=false;list.replaceChildren();browsePath.textContent='正在读取目标电脑目录…';
      for(const button of [roots,parent,use,more])button.disabled=true;
      try{
        const value=validateBrowse(await uiRequest(target,'workspace.browse',{path,offset,limit:100}));
        if(sequence!==browseSequence||!dialog.open||modalTarget!==target||!isActive(target))return;
        browsePage=value;browsePath.textContent=value.path||'目标电脑的本地驱动器';
        const items=value.path===null?value.roots.map(path=>({name:path,path})):value.directories;
        for(const item of items){const button=create('button',item.name);button.type='button';button.title=item.path;button.onclick=()=>browse(item.path);list.append(button);}
        roots.disabled=false;parent.disabled=!value.parent;use.disabled=!value.path;more.disabled=value.next_offset===null;
      }catch(error){if(sequence===browseSequence&&dialog.open){browsePath.textContent=message(error);roots.disabled=!isActive(target);}}
    }
    browseProject.onclick=()=>{browseField='project';browse(project.value||null);};
    browseExchange.onclick=()=>{browseField='exchange';browse(exchange.value||project.value||null);};
    roots.onclick=()=>browse();parent.onclick=()=>browse(browsePage?.parent||null);more.onclick=()=>browse(browsePage?.path,browsePage?.next_offset||0);
    use.onclick=()=>{
      if(!isActive(modalTarget)||!browsePage?.path)return;
      if(browseField==='project'){project.value=browsePage.path;if(autoExchange)exchange.value=joinTmp(project.value);}
      else{exchange.value=browsePage.path;autoExchange=false;}
      browser.hidden=true;browseSequence++;
    };
    form.addEventListener('submit',async event=>{
      event.preventDefault();const target=modalTarget;
      if(save.disabled||!integer(modalRevision)||!isActive(target)){state.textContent=messages.target_changed;return;}
      save.disabled=true;state.textContent='正在保存到目标电脑…';
      try{
        const value=workspace(target,await uiRequest(target,'workspace.set',{project_dir:project.value,
          exchange_dir:exchange.value||joinTmp(project.value),expected_revision:modalRevision}));
        if(!dialog.open||modalTarget!==target||!isActive(target))return;
        modalRevision=value.revision;project.value=value.project_dir;exchange.value=value.exchange_dir;
        display(value);state.textContent='目录已保存。';
        root.dispatchEvent(new CustomEvent('sma-file-workspace-changed',{detail:{host_id:target.hostID,room:target.room,
          session_id:target.session,window_id:target.window_id,revision:value.revision,project_dir:value.project_dir,exchange_dir:value.exchange_dir}}));
      }catch(error){if(dialog.open&&modalTarget===target)state.textContent=message(error);}
      finally{if(modalTarget===target&&isActive(target))save.disabled=false;}
    });
    let observed=null;
    function sync(){
      if(destroyed)return;
      if(config()?.enabled!==true){destroy();return;}
      prune();let next;try{next=captureTarget();}catch(error){active=null;reading++;display(null,message(error));staleModal();return;}
      const changed=!next!==!observed||next&&(!observed||next.pane!==observed.pane||next.key!==observed.key||next.window_id!==observed.window_id||!sameTransport(next,observed));
      if(changed){observed=next;refresh();}staleModal();
    }
    const timer=setInterval(sync,250);
    async function refreshConfig(){
      if(typeof native==='function'&&!object(root.SuperMonoFileWorkspaceConfig)){
        try{nativeConfig=await native();}catch{return;}
      }
      prune();observed=null;sync();
    }
    function destroy(){
      if(destroyed)return;destroyed=true;stopped=true;clearInterval(timer);reading++;browseSequence++;
      for(const entry of clients)entry.client.close();clients.length=0;
      dialog.remove();paths.remove();style.remove();
      if(originalStatus)originalStatus.hidden=statusHidden;
      if(originalFooter===null)footer.removeAttribute('data-file-workspaces');else footer.setAttribute('data-file-workspaces',originalFooter);
      root.removeEventListener('beforeunload',destroy);root.removeEventListener('pywebviewready',boot);
      root.removeEventListener('sma-file-exchange-config-changed',refreshConfig);delete root.SuperMonoFileWorkspaces;
    }
    root.SuperMonoFileWorkspaces={captureTarget,getWorkspace,request,isCurrent,getClient,refresh,refreshConfig,destroy};
    root.addEventListener('beforeunload',destroy,{once:true});root.addEventListener('sma-file-exchange-config-changed',refreshConfig);
    sync();
  }
  root.addEventListener('pywebviewready',boot);boot();
})();

;
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.SuperMonoFileUpload=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
  const hex=(value,length)=>typeof value==='string'&&new RegExp('^[a-f0-9]{'+length+'}$').test(value);
  function workspace(value,session){
    if(!object(value)||typeof value.window_id!=='string'||!value.window_id||value.window_id.length>64
      ||typeof value.daemon_epoch!=='string'||!value.daemon_epoch||value.daemon_epoch.length>128
      ||!Number.isSafeInteger(value.revision)||value.revision<0
      ||value.session_id!==undefined&&value.session_id!==session)throw Error('文件目录回执无效。');
    if(value.project_status==='selection_required')throw Object.assign(Error('请先在底部选择当前项目目录，附件将保存到该项目的 tmp。'),{code:'project_required'});
    return value;
  }
  function validateSource(source){
    if(!object(source)||typeof source.name!=='string'||!source.name||source.name.length>200
      ||!Number.isSafeInteger(source.size)||source.size<0||source.size>512*1024*1024)throw Error('附件名称或大小无效。');
  }
  async function uploadExchange({session,getWorkspace,request,sources,isCurrent,signal,onProgress=()=>{}}){
    if(typeof session!=='string'||!session||session.length>256||typeof getWorkspace!=='function'
      ||typeof request!=='function'||typeof isCurrent!=='function'||!Array.isArray(sources)||sources.length>32)throw Error('上传请求无效。');
    const receipts=[],check=()=>{if(signal?.aborted)throw Error('文件传输已取消。');if(!isCurrent())throw Error('目标窗口或连接已变化。');};
    const progress=value=>{try{onProgress(value);}catch{}};
    try{for(const [index,source] of sources.entries()){
      validateSource(source);let upload_id=null,file_id=null,finishSent=false;
      try{
        check();progress({phase:'preparing',name:source.name,index,total:sources.length,loaded:0,size:source.size});
        let currentWorkspace;
        try{currentWorkspace=workspace(await getWorkspace(),session);}catch(error){error.beforeUpload=true;throw error;}
        const sha256=source.prepare?await source.prepare():source.sha256;
        if(!hex(sha256,64))throw Error('附件 SHA-256 无效。');check();
        const begin=await request('upload.begin',{original_name:source.name,size:source.size,sha256,
          window_id:currentWorkspace.window_id,daemon_epoch:currentWorkspace.daemon_epoch,
          workspace_revision:currentWorkspace.revision,timezone_offset_minutes:-new Date().getTimezoneOffset()});
        upload_id=begin?.upload_id;
        if(!hex(upload_id,48))throw Error('上传标识回执无效。');
        let offset=0;
        while(offset<source.size){
          check();const chunk=await source.read(offset);check();
          if(!chunk||typeof chunk.data!=='string'||!chunk.data||!Number.isSafeInteger(chunk.next)||chunk.next<=offset||chunk.next>source.size)throw Error('源文件分块无效。');
          const response=await request('upload.chunk',{upload_id,offset,data:chunk.data});
          if(response.received!==chunk.next)throw Error('接收进度不一致。');offset=chunk.next;
          progress({phase:'uploading',name:source.name,index,total:sources.length,loaded:offset,size:source.size});
        }
        check();finishSent=true;
        progress({phase:'submitting',name:source.name,index,total:sources.length,loaded:source.size,size:source.size,upload_id});
        const queued=await request('upload.finish',{upload_id});
        if(!hex(queued?.file_id,48))throw Error('提交结果无效。');upload_id=null;file_id=queued.file_id;
        progress({phase:'receiving',name:source.name,index,total:sources.length,loaded:source.size,size:source.size,file_id});
        const deadline=performance.now()+180000;let result;
        while(performance.now()<deadline){
          if(!isCurrent())throw Object.assign(Error('文件已存入中继，但目标连接已变化；请核对接收状态。'),{pendingFileId:file_id});
          result=await request('file.status',{file_id});
          if(result.state==='saved')break;
          if(['failed','cancelled'].includes(result.state))throw Error('目标电脑未能保存文件，请检查文件助手。');
          await new Promise(resolve=>setTimeout(resolve,250));
        }
        if(result?.state!=='saved')throw Object.assign(Error('文件已存入中继，尚未收到目标保存确认。'),{pendingFileId:file_id});
        const saved=result.receipt;
        if(!saved||typeof saved.path!=='string'||!saved.path||saved.path.length>4096||/[\u0000-\u001f\u007f]/.test(saved.path)
          ||saved.name!==begin.name||saved.size!==source.size||saved.sha256!==sha256)throw Error('目标保存回执无效。');
        const receipt=Object.freeze({name:source.name,savedName:saved.name,path:saved.path,size:saved.size,sha256});
        receipts.push(receipt);source.saved=true;file_id=null;
        progress({phase:'saved',name:source.name,index,total:sources.length,loaded:source.size,size:source.size,receipt});
      }catch(error){
        if(file_id&&!error.pendingFileId)error.pendingFileId=file_id;
        if(finishSent&&!file_id){error.unknownCommit=true;error.pendingUploadId=upload_id;error.message='提交结果待确认，勿重复上传；请先核对目标项目 tmp 的接收情况。';}
        throw error;
      }finally{
        if(upload_id&&!finishSent)try{await request('upload.cancel',{upload_id});}catch{}
        try{await source.dropPrepared?.();}catch{}
      }
    }}catch(error){error.receipts=[...receipts];throw error;}
    return receipts;
  }
  return {upload:uploadExchange};
});

;
/* File-only sidecar: normal text paste stays with xterm. */
(()=>{
  'use strict';
  if(window.SuperMonoFilePaste||!window.smaWorkspace)return;
  const W=window.smaWorkspace;
  let busy=false;const jobs=[];let activeJob=null;const MAX_JOBS=32,MAX_QUEUED_BYTES=512*1024*1024;
  const box=document.createElement('aside');box.id='file-transfer-progress';box.hidden=true;
  box.style.cssText='position:fixed;right:12px;bottom:38px;z-index:1300;max-width:calc(100vw - 24px);width:360px;background:#222;color:#eee;border:1px solid #666;border-radius:7px;padding:12px;overflow-wrap:anywhere';
  const text=document.createElement('p'),cancel=document.createElement('button');cancel.textContent='取消传输';cancel.onclick=cancelAll;const list=document.createElement('ul');list.id='file-transfer-queue';list.style.cssText='padding:0;list-style:none;max-height:160px;overflow:auto';box.append(text,list,cancel);document.body.append(box);
  function status(message){box.hidden=false;text.textContent=message;}
  const windowOf=(host,session)=>host.catalog?.find(w=>(w.sessions||[]).some(s=>s.id===session))?.id;
  function target(){const p=W.activePane;if(!p||!p.ready||!p.host.connected)throw Error('请先选择已连接的终端窗口。');return Object.freeze({pane:p,key:p.sid,host:p.host,generation:p.host.generation,paneGeneration:p.generation,ws:p.host.ws,session:p.raw,window_id:windowOf(p.host,p.raw),token:p.host.config?.token,room:p.host.config?.code,relay:p.host.config?.relay,authMode:p.host.config?.authMode});}
  function valid(t){return !!t&&W.panes.get(t.key||t.pane?.sid)===t.pane&&t.pane.host===t.host&&t.pane.raw===t.session&&windowOf(t.host,t.session)===t.window_id&&t.pane.generation===t.paneGeneration&&t.pane.ready&&t.host.ws===t.ws&&t.host.generation===t.generation&&t.host.connected&&t.host.config?.token===t.token&&t.host.config?.code===t.room&&t.host.config?.relay===t.relay&&t.host.config?.authMode===t.authMode;}
  function exchangeTarget(pinned){const F=window.SuperMonoFileWorkspaces;if(!F)return null;const t=F.captureTarget();if(!t||t.pane!==pinned.pane||t.ws!==pinned.ws||t.generation!==pinned.generation||t.session!==pinned.session)throw Error('目标窗口已变化，请重新选择附件。');return t;}
  function renderQueue(){list.replaceChildren();for(const job of jobs){const row=document.createElement('li');row.style.cssText='margin:5px 0;overflow-wrap:anywhere';const label=document.createElement('span');label.textContent=job.sources?.map(s=>s.name).join('、')||'剪贴板附件';row.append(label,document.createTextNode(' · '+({queued:'排队',reading:'读取附件',sending:'传输中',failed:'失败',pending:'中继待确认，请勿重复上传',unknown:'提交结果待确认，勿重复'}[job.state]||job.state)+(job.pendingFileId?' '+job.pendingFileId:job.pendingUploadId?' 上传 '+job.pendingUploadId:'')));if(job!==activeJob){if(job.state==='failed'){const retry=document.createElement('button');retry.textContent='重试';retry.onclick=()=>{if(!valid(job.pinned)){status('原窗口连接已变化，请移除后在正确窗口重新粘贴。');return;}if(!job.exchange)try{job.exchange=exchangeTarget(job.pinned);}catch(error){status(error.message);return;}job.state='queued';renderQueue();drain();};row.append(retry);}const remove=document.createElement('button');remove.textContent='移除';remove.onclick=()=>{job.controller.abort();forget(job);};row.append(remove);}list.append(row);}cancel.textContent=busy?'取消队列':'关闭';cancel.disabled=false;}
  async function forget(job){const index=jobs.indexOf(job);if(index>=0)jobs.splice(index,1);await job.ready;for(const source of job.sources||[])try{await source.release?.();}catch{}job.options.signal?.removeEventListener('abort',job.abort);renderQueue();}
  function cancelAll(){if(!busy){box.hidden=true;return;}for(const job of [...jobs]){job.controller.abort();if(job!==activeJob){job.reject(Error('文件传输已取消。'));forget(job);}}status('正在取消；已提交中继的文件会继续等待保存确认，不再发送下一项。');}
  function enqueue(getSources,options={},retain=false,fallback){
    if(jobs.length>=MAX_JOBS){status('附件队列已满（最多32次粘贴），请先传输或移除现有项目。');return Promise.reject(Error('附件队列已满。'));}
    let pinned,exchange;try{pinned=options.target||target();if(!valid(pinned))throw Error('目标窗口或连接已变化。');exchange=exchangeTarget(pinned);}catch(error){return Promise.reject(error);}
    let resolve,reject;const result=new Promise((yes,no)=>{resolve=yes;reject=no;});
    const job={pinned,exchange,options,retain,fallback,controller:new AbortController(),resolve,reject,state:'queued',sources:[]};
    job.abort=()=>{job.controller.abort();if(job!==activeJob){job.reject(Error('文件传输已取消。'));forget(job);}};
    // Snapshot now, before any await or FIFO wait: later clipboard contents
    // must never replace this event's attachments or its captured destination.
    try{job.ready=Promise.resolve(getSources()).then(async sources=>{
      const total=Array.isArray(sources)?sources.reduce((n,s)=>n+(Number.isSafeInteger(s.size)&&s.size>=0?s.size:Infinity),0):Infinity;
      const existing=jobs.reduce((n,j)=>n+j.sources.reduce((sum,s)=>sum+s.size,0),0);
      if(!Array.isArray(sources)||sources.length>32||total+existing>MAX_QUEUED_BYTES){for(const s of sources||[])try{await s.release?.();}catch{}job.sourceError=Error('附件队列总量超过512 MiB或单次超过32个文件，请分批粘贴。');return;}
      job.sources=sources;renderQueue();
    },e=>{job.sourceError=e;});}catch(error){job.sourceError=error;job.ready=Promise.resolve();}
    jobs.push(job);options.signal?.addEventListener('abort',job.abort,{once:true});if(options.signal?.aborted)job.controller.abort();
    renderQueue();drain();return result;
  }
  async function drain(){if(activeJob)return;const job=jobs.find(j=>j.state==='queued');if(!job){busy=false;renderQueue();return;}activeJob=job;busy=true;job.state='reading';status('正在读取粘贴文件…');renderQueue();
    try{await job.ready;if(job.controller.signal.aborted)throw Error('文件传输已取消。');if(job.sourceError)throw job.sourceError;if(!job.sources.length){if(!job.retain)throw Error('没有可上传的文件或图片。');job.fallback?.();job.resolve([]);await forget(job);}
      else{job.state='sending';renderQueue();const receipts=await transferExchange(job.pinned,job.sources.filter(s=>!s.saved),{...job.options,signal:job.controller.signal,exchangeTarget:job.exchange});job.resolve(receipts);status('已保存到目标项目 tmp：'+receipts.map(r=>r.path).join('、'));await forget(job);}}
    catch(error){if(error.code==='project_required')error.message='请先在底部选择当前项目目录，附件将保存到该项目的 tmp。';job.reject(error);status(String(error.message||error));if(job.retain&&(!job.controller.signal.aborted||error.unknownCommit||error.pendingFileId)&&job.sources.length){job.state=error.unknownCommit?'unknown':error.pendingFileId?'pending':'failed';job.pendingFileId=error.pendingFileId;job.pendingUploadId=error.pendingUploadId;renderQueue();}else await forget(job);}
    finally{activeJob=null;busy=false;drain();}
  }
  function run(getSources,fallback,pinned){return enqueue(getSources,{target:pinned},true,fallback).catch(error=>{status(String(error.message||error));});}
  async function nativeSources(){const api=window.pywebview?.api;if(!api?.clipboard_files)throw Error('当前外壳尚未提供文件剪贴板入口。');const snapshot=await api.clipboard_files();return snapshot.items.map(item=>({...item,read:offset=>api.clipboard_chunk(item.id,offset),release:()=>api.clipboard_release(item.id)}));}
  async function browserSources(files){if(files.length>32)throw Error('一次最多粘贴 32 个文件。');return files.map(f=>{if(f.size>64*1024*1024)throw Error('浏览器粘贴单文件限 64 MiB；较大文件请使用 Windows 原生文件粘贴。');let bytes;return {name:f.name,size:f.size,prepare:async()=>{bytes=new Uint8Array(await f.arrayBuffer());const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(v=>v.toString(16).padStart(2,'0')).join('');},read:async offset=>{const part=bytes.subarray(offset,offset+96*1024);let value='';for(const v of part)value+=String.fromCharCode(v);return {data:btoa(value),next:offset+part.length};},release:()=>{bytes=null;},dropPrepared:()=>{bytes=null;}};});}
  document.addEventListener('paste',event=>{
    if(!event.target.closest?.('.terminal-screen'))return;
    const files=[...(event.clipboardData?.files||[])],native=!!window.supermonoClipboardHasFiles;
    const plain=event.clipboardData?.getData('text/plain')||'';
    // The current paste event is authoritative for text. A stale file-format
    // beacon or an unavailable native bridge must not consume or delay it.
    if(plain&&!files.length)return;
    if(!files.length&&!native)return;
    const pane=W.activePane;
    if(pane?.term?.textarea&&event.target.closest('.terminal-screen')!==pane.term.textarea.closest('.terminal-screen')){event.preventDefault();event.stopImmediatePropagation();status('请选择该终端窗口后再粘贴附件。');return;}
    let pinned;try{pinned=target();}catch(error){event.preventDefault();status(error.message);return;}
    event.preventDefault();event.stopImmediatePropagation();
    const fallback=()=>{if(plain&&valid(pinned)&&W.activePane===pane)pane.term.paste(plain);};
    // Do not await clipboard_has_files: it can race with another Ctrl+V.
    // Native snapshots are immutable handles, browser Files belong to this event.
    if(files.length)run(()=>browserSources(files),fallback,pinned);
    else run(nativeSources,fallback,pinned);
  },true);
  function nativeMenu(){const menu=document.getElementById('app-menu');if(menu&&window.pywebview?.api?.clipboard_files&&!document.getElementById('paste-native-files')){const item=document.createElement('button');item.id='paste-native-files';item.type='button';item.setAttribute('role','menuitem');item.textContent='粘贴文件到当前窗口';item.onclick=()=>run(nativeSources);menu.append(item);}}
  nativeMenu();addEventListener('pywebviewready',nativeMenu,{once:true});
  function uploadSources(getSources,options={}){return enqueue(getSources,options);}
  let directSequence=0;
  function directRequest(pinned,body,options,cleanup=false){
    return new Promise((resolve,reject)=>{
      const socket=pinned.ws,C=window.TerminalClient;
      if(!socket||!C||!cleanup&&!valid(pinned)){reject(Error('目标连接已变化或上传已取消。'));return;}
      const request='desktop-file-'+Date.now().toString(36)+'-'+(++directSequence),encoder=new TextEncoder(),decoder=new TextDecoder();let timer,settled=false;
      const done=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);socket.removeEventListener('message',receive);socket.removeEventListener('close',closed);options.signal?.removeEventListener('abort',aborted);error?reject(error):resolve(value);};
      const closed=()=>done(Error('文件上传连接已断开。')),aborted=()=>done(Error('上传已取消。'));
      const receive=event=>{try{
        if(!(event.data instanceof ArrayBuffer))return;const frame=C.unpack(event.data);if(frame.op!==21)return;
        const value=JSON.parse(decoder.decode(frame.payload));if(value.request!==request)return;
        if(!cleanup&&!valid(pinned))done(Error('目标终端已变化。'));
        else if(value.ok!==true){const error=Error(value.error||'目标电脑拒绝接收文件。');error.code=value.error_code||'failed';done(error);}
        else done(null,value);
      }catch{}};
      socket.addEventListener('message',receive);socket.addEventListener('close',closed);if(!cleanup)options.signal?.addEventListener('abort',aborted,{once:true});
      timer=setTimeout(()=>done(Error('等待文件接收确认超时。')),cleanup?3000:15000);
      try{socket.send(C.pack(21,encoder.encode(JSON.stringify({request,session:pinned.session,...body}))));}catch{done(Error('无法发送文件数据。'));}
    });
  }
  async function transferDirect(pinned,sources,options){
    const receipts=[],progress=value=>{
      if(value.phase==='preparing')status('准备传输 '+value.name+'…');
      else if(value.phase==='uploading')status(value.name+' · '+(value.size?Math.floor(value.loaded/value.size*100):100)+'%');
      else if(value.phase==='receiving')status('正在等待目标电脑保存确认：'+value.name);
      else if(value.phase==='submitting')status('正在提交，请等待结果确认：'+value.name);
      try{options.onProgress?.(value);}catch{}
    };
    try{for(const [index,source] of sources.entries()){
      let id=null,finishSent=false;
      try{
        if(options.signal?.aborted||!valid(pinned))throw Error('目标窗口或连接已变化。');
        progress({phase:'preparing',name:source.name,index,total:sources.length,loaded:0,size:source.size});
        const sha256=source.prepare?await source.prepare():source.sha256;
        if(!/^[a-f0-9]{64}$/.test(sha256||''))throw Error('附件 SHA-256 无效。');
        const begin=await directRequest(pinned,{action:'begin',name:source.name,size:source.size,sha256},options);
        if(!/^[a-f0-9]{48}$/.test(begin.id||'')||begin.received!==0)throw Error('接收端返回了无效的上传标识。');id=begin.id;
        let offset=0;
        while(offset<source.size){
          if(options.signal?.aborted||!valid(pinned))throw Error('目标窗口或连接已变化。');
          const chunk=await source.read(offset);
          if(!chunk||typeof chunk.data!=='string'||!chunk.data||chunk.next<=offset||chunk.next>source.size)throw Error('源文件分块无效。');
          const result=await directRequest(pinned,{action:'chunk',id,offset,data:chunk.data},options);
          if(result.received!==chunk.next)throw Error('接收进度不一致，上传已停止。');offset=chunk.next;
          progress({phase:'uploading',name:source.name,index,total:sources.length,loaded:offset,size:source.size});
        }
        if(options.signal?.aborted||!valid(pinned))throw Error('目标窗口或连接已变化。');finishSent=true;
        progress({phase:'submitting',name:source.name,index,total:sources.length,loaded:source.size,size:source.size,upload_id:id});
        const saved=await directRequest(pinned,{action:'finish',id},options);
        if(typeof saved.path!=='string'||!saved.path||saved.path.length>4096||/[\u0000-\u001f\u007f]/.test(saved.path))throw Error('未收到目标电脑的有效保存路径。');
        const receipt=Object.freeze({name:source.name,savedName:source.name,path:saved.path,size:source.size,sha256});receipts.push(receipt);source.saved=true;id=null;
        progress({phase:'saved',name:source.name,index,total:sources.length,loaded:source.size,size:source.size,receipt});
      }catch(error){if(finishSent){error.unknownCommit=true;error.pendingUploadId=id;error.message='提交结果待确认，勿重复上传；请先核对目标电脑的接收情况。';}throw error;}
      finally{if(id&&!finishSent)try{await directRequest(pinned,{action:'cancel',id},options,true);}catch{}try{await source.dropPrepared?.();}catch{}}
    }}catch(error){error.receipts=[...receipts];throw error;}
    return receipts;
  }
  async function transferExchange(pinned,sources,options){
    const F=window.SuperMonoFileWorkspaces,direct=pinned.host.capabilities?.file_transfer===true;
    if(!F){
      if(direct)return transferDirect(pinned,sources,options);
      throw Error('文件交换助手尚未安装，请更新完整客户端并在接收电脑启用文件助手。');
    }
    const target=options.exchangeTarget;
    if(!target||target.pane!==pinned.pane||target.ws!==pinned.ws||target.generation!==pinned.generation)throw Error('目标窗口已变化，请重新打开编辑框。');
    try{
      return await window.SuperMonoFileUpload.upload({session:target.session,getWorkspace:()=>F.getWorkspace(target),
        request:(action,data)=>F.request(target,action,data),sources,
        isCurrent:()=>!options.signal?.aborted&&valid(pinned)&&F.isCurrent(target),signal:options.signal,onProgress:value=>{
          if(value.phase==='preparing')status('准备传输 '+value.name+'…');
          else if(value.phase==='uploading')status(value.name+' · '+(value.size?Math.floor(value.loaded/value.size*100):100)+'%');
          else if(value.phase==='receiving')status('已存入中继，正在等待目标项目 tmp 保存确认：'+value.name);
          else if(value.phase==='submitting')status('正在提交中继，请等待结果确认：'+value.name);
          try{options.onProgress?.(value);}catch{}
        }});
    }catch(error){
      if(direct&&error.beforeUpload===true&&['host_unavailable','connection_failed','unsupported'].includes(error.code))return transferDirect(pinned,sources,options);
      throw error;
    }
  }
  window.SuperMonoFilePaste={paste:()=>run(nativeSources),captureTarget:target,isCurrent:valid,
    upload:(files,options={})=>uploadSources(()=>browserSources([...files]),options),
    uploadClipboard:(options={})=>uploadSources(nativeSources,options),get busy(){return busy||jobs.some(job=>job.state==='queued');},get queued(){return jobs.length;}};
  addEventListener('beforeunload',()=>{for(const job of [...jobs]){job.controller.abort();job.reject(Error('窗口已关闭。'));forget(job);}},{once:true});
})();

;
/* Additive, target-bound text draft and attachment editor. No global paste hooks. */
(()=>{
  'use strict';
  if(window.SuperMonoTerminalComposer||!window.smaWorkspace)return;
  const W=window.smaWorkspace,toolbar=document.querySelector('main>footer');
  if(!toolbar)return;
  const node=(tag,text)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;return el;};
  const button=(id,text)=>{const el=node('button',text);el.id=id;el.type='button';return el;};
  const plain=(value,max)=>typeof value==='string'&&value.length>0&&value.length<=max&&!/[\u0000-\u001f\u007f]/u.test(value);
  const style=node('style');style.id='terminal-composer-style';
  style.textContent=`#terminal-composer-open{flex:none;white-space:nowrap;font-size:10px}footer:has(>#terminal-composer-open){min-width:0;overflow-x:auto}#terminal-composer{width:620px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 24px);padding:18px;overflow:auto;overflow-wrap:anywhere}#terminal-composer h2{font-size:16px;overflow-wrap:anywhere;line-height:1.5}#terminal-composer label{display:block;margin:10px 0 5px}#terminal-composer-text{box-sizing:border-box;width:100%;min-width:0;max-width:100%;min-height:120px;height:220px;max-height:40dvh;resize:vertical;border:1px solid #555;border-radius:5px;padding:9px;background:#141414;color:inherit;font:inherit;font-size:13px;line-height:1.6;white-space:pre-wrap;overflow:auto}#terminal-composer .composer-actions{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}#terminal-composer input[type=file]{max-width:100%;min-width:0;width:100%}#terminal-composer-files,#terminal-composer-receipts{list-style:none;padding:0;margin:8px 0;max-height:160px;overflow:auto}#terminal-composer li{display:flex;gap:6px;align-items:center;min-width:0;padding:4px 0;border-bottom:1px solid #383838}#terminal-composer li>span{flex:1;min-width:0;overflow-wrap:anywhere;white-space:pre-wrap}#terminal-composer li>button{flex:none;font-size:11px}#terminal-composer p{margin:8px 0;font-size:12px;line-height:1.5;white-space:pre-wrap}#terminal-composer-state{color:#ddd}#terminal-composer-progress{width:100%;height:10px}#terminal-composer-hint,#terminal-composer-capability{color:#aaa}@media(max-width:600px){#terminal-composer{padding:13px}#terminal-composer-text{height:170px;min-height:90px}#terminal-composer-files,#terminal-composer-receipts{max-height:110px}}`;
  document.head.append(style);
  const openButton=button('terminal-composer-open','编辑');openButton.title='编辑文本与附件';toolbar.prepend(openButton);
  const dialog=node('dialog');dialog.id='terminal-composer';dialog.setAttribute('aria-label','编辑文本与附件');
  const heading=node('h2','编辑文本与附件'),label=node('label','多行文本');label.htmlFor='terminal-composer-text';
  const textarea=node('textarea');textarea.id='terminal-composer-text';textarea.rows=8;textarea.spellcheck=false;
  textarea.placeholder='自由编辑多行文本；支持正常 Ctrl+V';
  const hint=node('p','编辑后粘贴到当前终端，不额外按 Enter；提交行为由终端程序决定。草稿会保留。');hint.id='terminal-composer-hint';
  const paste=button('terminal-composer-paste','粘贴文本'),fileLabel=node('label','选择附件（每批最多 32 个，每个不超过 64 MiB）');
  const picker=node('input');picker.id='terminal-composer-files-input';picker.type='file';picker.multiple=true;picker.hidden=true;fileLabel.htmlFor=picker.id;
  const chooseFiles=button('terminal-composer-choose-files','选择文件'),chooseImages=button('terminal-composer-choose-images','选择图片');
  const files=node('ul');files.id='terminal-composer-files';const receipts=node('ul');receipts.id='terminal-composer-receipts';
  const capability=node('p');capability.id='terminal-composer-capability';
  const progress=node('progress');progress.id='terminal-composer-progress';progress.max=100;progress.value=0;progress.hidden=true;
  const state=node('p');state.id='terminal-composer-state';state.setAttribute('role','status');state.setAttribute('aria-live','polite');
  const upload=button('terminal-composer-upload','上传附件'),cancel=button('terminal-composer-cancel','取消上传'),insert=button('terminal-composer-insert','插入输入行'),close=button('terminal-composer-close','关闭');
  insert.className='primary';
  const actions=node('div');actions.className='composer-actions';actions.append(paste,chooseFiles,chooseImages,upload,cancel,insert,close);
  dialog.append(heading,label,textarea,hint,fileLabel,picker,files,receipts,capability,progress,state,actions);document.body.append(dialog);
  const drafts=[],transfers=new Set();let current=null,inflight=null,nextFile=0,destroyed=false,openError='',listDraft=null,listSignature='';
  function windowOf(host,session){return host.catalog?.find(win=>(win.sessions||[]).some(item=>item.id===session));}
  function capture(){
    const api=window.SuperMonoFilePaste;
    const bound=typeof api?.captureTarget==='function'?api.captureTarget():null;
    if(typeof api?.captureTarget==='function'&&!bound)throw Error('请先选择已连接的目标窗口。');
    const pane=bound?.pane||W.activePane,host=pane?.host,key=pane?.sid||W.activeSession,win=host&&windowOf(host,pane.raw);
    if(!pane||!host||!key||!host.connected||!pane.ready||pane.generation!==host.generation||W.panes.get(key)!==pane||host.ws?.readyState!==1)throw Error('请先选择已连接的目标窗口。');
    return {bound,api,pane,term:pane.term,host,key,ws:host.ws,generation:host.generation,paneGeneration:pane.generation,
      hostID:host.id,session:pane.raw,windowID:win?.id,token:host.config?.token,relay:host.config?.relay,
      code:host.config?.code,authMode:host.config?.authMode,room:bound?.room,endpoint:bound?.endpoint||bound?.broker_url,
      machine:String(host.name||host.id).slice(0,128),
      title:String(win?.title||pane.title?.textContent||pane.raw).slice(0,128)};
  }
  function live(target){
    if(!target||destroyed||W.panes.get(target.key)!==target.pane||target.pane.host!==target.host
      ||target.pane.raw!==target.session||target.host.ws!==target.ws||target.ws?.readyState!==1
      ||!target.host.connected||target.host.generation!==target.generation||target.pane.generation!==target.paneGeneration
      ||target.host.id!==target.hostID||target.host.config?.token!==target.token||target.host.config?.relay!==target.relay
      ||target.host.config?.code!==target.code||target.host.config?.authMode!==target.authMode
      ||windowOf(target.host,target.session)?.id!==target.windowID)return false;
    if(W.connections?.get&&W.connections.get(target.hostID)!==target.host)return false;
    if(target.bound){try{return window.SuperMonoFilePaste===target.api&&typeof target.api.isCurrent==='function'&&target.api.isCurrent(target.bound)===true;}catch{return false;}}
    return true;
  }
  const active=target=>live(target)&&W.activePane===target.pane&&W.activeSession===target.key&&target.pane.ready&&target.pane.term===target.term;
  const canInsert=target=>active(target)&&typeof target.term?.paste==='function'&&target.term.options?.disableStdin!==true&&target.term.textarea?.readOnly!==true;
  const sameDraft=(a,b)=>['host','hostID','session','windowID','token','relay','code','authMode','room','endpoint'].every(key=>a[key]===b[key]);
  function draftFor(target){
    let draft=drafts.find(item=>sameDraft(item.target,target));
    if(!draft){
      if(drafts.length>=64){const empty=drafts.findIndex(item=>!item.text&&!item.files.length&&!item.receipts.length&&inflight?.draft!==item);if(empty<0)throw Error('已保留 64 个会话草稿；请先处理已有草稿。');drafts.splice(empty,1);}
      draft={target,text:'',revision:0,inserted:-1,files:[],receipts:[],message:''};drafts.push(draft);
    }
    draft.target=target;
    return draft;
  }
  function remember(){if(current&&textarea.value!==current.draft.text){current.draft.text=textarea.value;current.draft.revision++;}}
  function usableUpload(target){return live(target)&&!!target.bound&&typeof target.api?.upload==='function'&&typeof target.api?.captureTarget==='function'&&typeof target.api?.isCurrent==='function';}
  function receipt(value){return value&&plain(value.name,256)&&plain(value.path,4096)&&!value.path.includes('://')
    &&Number.isSafeInteger(value.size)&&value.size>=0&&typeof value.sha256==='string'&&/^[a-fA-F0-9]{64}$/.test(value.sha256);}
  function adopt(draft,values){
    for(const value of values||[]){
      if(!receipt(value))continue;
      if(!draft.receipts.some(old=>old.path===value.path&&old.sha256===value.sha256))draft.receipts.push(Object.freeze({name:value.name,path:value.path,size:value.size,sha256:value.sha256}));
    }
  }
  function render(){
    const ctx=current,draft=ctx?.draft,target=ctx?.target;
    insert.disabled=!ctx||!canInsert(target)||!draft.text||draft.inserted===draft.revision;
    paste.disabled=!ctx;picker.disabled=!ctx||inflight?.draft===draft;chooseFiles.disabled=chooseImages.disabled=picker.disabled;
    upload.disabled=!ctx||!!inflight||!draft.files.some(item=>!item.pending&&!item.nativeClipboard)||!usableUpload(target)||!active(target);
    cancel.disabled=!inflight||inflight.controller.signal.aborted;
    capability.textContent=ctx&&!usableUpload(target)?'附件上传不可用：当前客户端缺少目标绑定上传入口，或目标连接已变化。文本草稿仍保留。':'附件仅上传保存到目标目录；不会自动导入模型。';
    if(ctx&&!active(target))capability.textContent+=' 当前活动窗口已变化；返回此窗口或重新选择编辑目标后再插入。';
    const signature=JSON.stringify([(draft?.files||[]).map(item=>[item.id,item.pending,item.pendingFileId,item.pendingUploadId,item.unknownCommit]),(draft?.receipts||[]).map(item=>[item.path,item.sha256]),inflight?.draft===draft]);
    if(listDraft!==draft||listSignature!==signature){listDraft=draft;listSignature=signature;files.replaceChildren();receipts.replaceChildren();
    for(const item of draft?.files||[]){
      const pending=item.pending?(item.unknownCommit?' · 提交结果待确认，勿重复':' · 中继已暂存，待目标确认')+(item.pendingFileId?' · 任务 '+item.pendingFileId:item.pendingUploadId?' · 上传 '+item.pendingUploadId:''):item.nativeClipboard?' · 原生附件未完成，请重新复制后粘贴':'';
      const row=node('li'),name=node('span',item.file.name+' · '+item.file.size+' 字节'+pending),remove=button('',item.pending?'待确认':'移除');
      remove.removeAttribute('id');remove.disabled=inflight?.draft===draft||item.pending===true;
      remove.onclick=()=>{draft.files=draft.files.filter(value=>value!==item);render();};row.append(name,remove);files.append(row);
    }
    for(const saved of draft?.receipts||[]){
      const row=node('li'),name=node('span','已保存: '+saved.path),add=button('','路径加到草稿');add.removeAttribute('id');
      add.onclick=()=>{if(!current||current.draft!==draft)return;remember();draft.text+=(draft.text&&!draft.text.endsWith('\n')?'\n':'')+saved.path;draft.revision++;textarea.value=draft.text;draft.message='路径已加到草稿，尚未插入终端或导入模型。';render();};
      row.append(name,add);receipts.append(row);
    }
    }
    state.textContent=draft?.message||openError;
    if(inflight&&inflight.draft!==draft)state.textContent+='\n'+inflight.target.machine+' / '+inflight.target.title+' 仍在上传；不会改投当前窗口。';
    progress.hidden=!inflight;
  }
  function open(){
    if(destroyed)return;remember();
    try{const target=capture(),draft=draftFor(target);current={target,draft};openError='';heading.textContent='编辑 · '+target.machine+' / '+target.title;textarea.value=draft.text;textarea.disabled=false;}
    catch(error){current=null;heading.textContent='编辑文本与附件';textarea.value='';textarea.disabled=true;openError=String(error.message||'目标窗口不可用。');}
    if(!dialog.open)dialog.showModal();render();textarea.focus();
  }
  function dismiss(){remember();dialog.close();}
  openButton.onclick=open;close.onclick=dismiss;dialog.addEventListener('cancel',()=>remember());
  textarea.addEventListener('input',()=>{remember();render();});
  async function pasteClipboard(){
    const ctx=current;if(!ctx||!dialog.open||textarea.disabled||textarea.readOnly||!active(ctx.target))return false;
    remember();const revision=ctx.draft.revision,start=textarea.selectionStart,end=textarea.selectionEnd;
    try{
      const api=window.pywebview?.api;
      let files=false;try{files=typeof api?.clipboard_has_files==='function'&&await api.clipboard_has_files()===true;}catch{}
      if(!dialog.open||current!==ctx||!active(ctx.target))return false;
      if(files){
        if(typeof ctx.target.api?.uploadClipboard!=='function'){ctx.draft.message='当前客户端缺少原生附件上传入口，请更新完整客户端。';render();return false;}
        return startUpload(true,ctx);
      }
      let value;
      try{if(typeof api?.clipboard_read_text!=='function')throw Error();value=await api.clipboard_read_text();}
      catch{if(!navigator.clipboard?.readText)throw Error();value=await navigator.clipboard.readText();}
      if(!dialog.open||current!==ctx||!active(ctx.target))return false;
      if(textarea.disabled||textarea.readOnly||ctx.draft.revision!==revision||textarea.selectionStart!==start||textarea.selectionEnd!==end){ctx.draft.message='草稿、光标或编辑权限已变化，请在所需光标位置重新粘贴。';render();return false;}
      if(typeof value!=='string'||!value){ctx.draft.message='剪贴板没有可用文本；文件或图片请使用下方选择附件。';render();return false;}
      textarea.setRangeText(value,start,end,'end');textarea.dispatchEvent(new Event('input',{bubbles:true}));ctx.draft.message='文本已放入草稿。';render();textarea.focus();return true;
    }catch{if(current===ctx){ctx.draft.message='无法读取剪贴板，请在文本框中使用原生 Ctrl+V。';render();textarea.focus();}return false;}
  }
  paste.textContent='粘贴';paste.onclick=pasteClipboard;
  function addFiles(values){
    const draft=current?.draft,chosen=[...(values||[])];if(!draft||!dialog.open||!active(current.target))return false;
    if(draft.files.length+chosen.length>32){draft.message='每批最多选择 32 个文件。';render();return false;}
    if(chosen.some(file=>!plain(file.name,256)||!Number.isSafeInteger(file.size)||file.size<0||file.size>64*1024*1024||file.webkitRelativePath)){
      draft.message='请选择普通文件；每个文件不超过 64 MiB，暂不支持整个文件夹。';render();return false;
    }
    draft.files.push(...chosen.map(file=>({id:++nextFile,file})));draft.message='已选择附件，尚未上传保存。';render();return true;
  }
  chooseFiles.onclick=()=>{picker.accept='';picker.click();};
  chooseImages.onclick=()=>{picker.accept='image/*';picker.click();};
  dialog.addEventListener('paste',event=>{
    if(event.target!==textarea)return;
    const selected=[...(event.clipboardData?.files||[])],plain=event.clipboardData?.getData('text/plain')||'';
    if(plain&&!selected.length)return;
    if(!selected.length&&!window.supermonoClipboardHasFiles)return;
    event.preventDefault();event.stopImmediatePropagation();
    const ctx=current;
    if(!ctx||!active(ctx.target)){if(ctx){ctx.draft.message='目标窗口已变化，请重新选择后再粘贴附件。';render();}return;}
    if(selected.length&&!addFiles(selected))return;
    startUpload(selected.length===0,ctx);
  });
  picker.addEventListener('change',()=>{const chosen=[...(picker.files||[])];picker.value='';addFiles(chosen);});
  async function startUpload(native=false,ctx=current){
    if(!ctx||(!native&&inflight)||transfers.size>=32||!usableUpload(ctx.target)||!active(ctx.target)||(!native&&!ctx.draft.files.some(item=>!item.pending&&!item.nativeClipboard)))return false;
    const transfer={target:ctx.target,draft:ctx.draft,native,files:native?[]:ctx.draft.files.filter(item=>!item.pending&&!item.nativeClipboard),controller:new AbortController(),saved:new Set(),phase:'',index:0,pendingId:null};transfers.add(transfer);if(!inflight)inflight=transfer;
    transfer.draft.message='正在上传到 '+transfer.target.machine+' / '+transfer.target.title+'…';progress.value=0;render();
    const markSaved=(value,index)=>{
      if(!receipt(value))return;
      const item=Number.isInteger(index)?transfer.files[index]:transfer.files.find(file=>file.file.name===value.name&&file.file.size===value.size&&!transfer.saved.has(file.id));
      if(item&&item.file.size===value.size&&!transfer.saved.has(item.id)){adopt(transfer.draft,[value]);transfer.saved.add(item.id);transfer.draft.files=transfer.draft.files.filter(file=>file.id!==item.id);}
    };
    try{
      const options={target:transfer.target.bound,signal:transfer.controller.signal,onProgress:value=>{
        if(!transfers.has(transfer)||destroyed)return;
        inflight=transfer;
        if(value&&typeof value==='object'){
          if(native&&value.phase==='preparing'&&Number.isInteger(value.index)&&value.index>=0&&value.index<32&&!transfer.files[value.index]){
            if(!plain(value.name,256)||!Number.isSafeInteger(value.size)||value.size<0||transfer.draft.files.length>=32){transfer.limitExceeded=true;transfer.controller.abort();return;}
            const item={id:++nextFile,file:{name:value.name,size:value.size},nativeClipboard:true};transfer.files[value.index]=item;transfer.draft.files.push(item);
          }
          if(Number.isInteger(value.index)&&value.index>=0&&value.index<transfer.files.length)transfer.index=value.index;
          if(typeof value.phase==='string')transfer.phase=value.phase;
          if(value.phase==='preparing')transfer.pendingId=null;
          if(value.phase==='receiving'&&typeof value.file_id==='string'&&/^[a-f0-9]{48}$/.test(value.file_id))transfer.pendingId=value.file_id;
          if(value.phase==='saved')markSaved(value.receipt,value.index);
          const loaded=Number(value.loaded),size=Number(value.size),index=Number(value.index),total=Number(value.total);
          if(Number.isFinite(loaded)&&size>0&&Number.isInteger(index)&&total>0)progress.value=Math.max(0,Math.min(value.phase==='saved'?100:99,(index+loaded/size)/total*100));
          const name=typeof value.name==='string'?value.name.slice(0,256):'';
          transfer.draft.message=(value.phase==='saved'?'已收到目标保存确认: ':value.phase==='submitting'?'正在提交中继，等待结果确认: ':value.phase==='receiving'?'中继已暂存，等待目标保存确认: ':'正在传输: ')+name;
        }
        render();
      }};
      const values=await (native?transfer.target.api.uploadClipboard(options):transfer.target.api.upload(transfer.files.map(item=>item.file),options));
      if(!live(transfer.target))throw Error('目标连接已变化。');
      if(!Array.isArray(values)||values.length!==transfer.files.length||values.some(value=>!receipt(value)))throw Error('目标未返回有效保存凭据。');
      values.forEach((value,index)=>markSaved(value,index));
      if(transfer.saved.size!==transfer.files.length)throw Error('目标未返回完整保存凭据。');
      transfer.draft.message='已保存 '+values.length+' 个附件到捕获目标；'+(transfer.controller.signal.aborted?'已提交项保存完成，取消后不会继续新文件。':'')+'尚未导入模型。可将路径显式加到草稿。';
      return true;
    }catch(error){
      if(Array.isArray(error?.receipts))error.receipts.forEach((value,index)=>markSaved(value,index));
      const pending=transfer.files[transfer.index],pendingId=typeof error?.pendingFileId==='string'&&/^[a-f0-9]{48}$/.test(error.pendingFileId)?error.pendingFileId:transfer.pendingId;
      const unknownCommit=error?.unknownCommit===true||transfer.phase==='submitting';
      const uncertain=pending&&!transfer.saved.has(pending.id)&&(pendingId||transfer.phase==='receiving'||unknownCommit);
      if(uncertain){pending.pending=true;pending.pendingFileId=pendingId;pending.unknownCommit=unknownCommit;
        if(typeof error?.pendingUploadId==='string'&&/^[a-f0-9]{48}$/.test(error.pendingUploadId))pending.pendingUploadId=error.pendingUploadId;}
      const missing=/文件交换助手尚未安装|更新完整客户端/.test(typeof error?.message==='string'?error.message:'');
      transfer.draft.message=transfer.files.length>0&&transfer.saved.size===transfer.files.length?'附件均已收到保存确认；捕获目标状态已变化，尚未导入模型。草稿和凭据保留。':
        (transfer.saved.size?'已保存 '+transfer.saved.size+' 项；':'')+(uncertain?(unknownCommit?'提交结果待确认，勿重复；已挂起且不会再次上传，请先核对目标项目 tmp。':'另有文件已中继暂存但未获目标保存确认，已挂起且不会再次上传。请核对任务状态。'):
        missing?'文件交换助手尚未安装，请更新完整客户端及接收机助手。':transfer.limitExceeded?'附件队列最多32项，请先移除或处理已有项目。':transfer.controller.signal.aborted?'未提交项上传已取消。':'其余附件未完成，请检查目标后台能力或连接。')+' 文本、附件记录及保存凭据均保留。';return false;
    }finally{transfers.delete(transfer);if(inflight===transfer)inflight=transfers.values().next().value||null;if(!destroyed)render();}
  }
  upload.onclick=()=>startUpload();
  cancel.onclick=()=>{if(inflight){for(const item of transfers)item.controller.abort();inflight.draft.message=inflight.phase==='receiving'?
    '本项已提交中继，不能撤销；正在等待目标确认，之后停止后续附件。':inflight.phase==='submitting'?
    '提交结果尚待确认；取消后不会继续后续附件，请勿重复上传。':'正在取消未提交上传；已保存项会保留。';render();}};
  insert.onclick=()=>{
    const ctx=current;if(!ctx)return;remember();
    if(!canInsert(ctx.target)){ctx.draft.message='当前活动窗口或输入能力已变化；请返回捕获窗口并检查输入权限。';render();return;}
    if(!ctx.draft.text||ctx.draft.inserted===ctx.draft.revision)return;
    try{ctx.target.term.paste(ctx.draft.text);ctx.draft.inserted=ctx.draft.revision;ctx.draft.message='已通过终端粘贴插入；未额外发送 Enter。草稿与附件保存凭据保留。';}
    catch{ctx.draft.message='无法插入当前输入行；草稿已保留，请检查终端连接。';}
    render();
  };
  const timer=setInterval(()=>{
    for(const item of transfers)if(!live(item.target)&&!item.controller.signal.aborted)item.controller.abort();
    if(dialog.open)render();
    openButton.disabled=!W.activePane?.host?.connected;
  },200);
  function destroy(){
    if(destroyed)return;destroyed=true;for(const item of transfers)item.controller.abort();clearInterval(timer);window.removeEventListener('beforeunload',destroy);
    dialog.remove();openButton.remove();style.remove();drafts.length=0;current=null;delete window.SuperMonoTerminalComposer;
  }
  window.SuperMonoTerminalComposer={open,close:dismiss,destroy,pasteClipboard,addFiles,get busy(){return transfers.size>0;}};
  window.addEventListener('beforeunload',destroy,{once:true});render();
})();

;
/* Passive submitted-input marks; no history guessing, input changes or storage. */
(()=>{
  'use strict';
  if(window.TerminalQuestions)return;
  const MAX_TEXT=4096,MAX_PENDING=4,MAX_MARKS=64,MAX_MARK_TEXT=65536,LIFETIME=8000;
  function create(pane,{enabled=true,isCurrent=()=>true}={}){
    const term=pane.term,doc=term.textarea?.ownerDocument||document;
    let dead=false,draft='',invalid=false,enter=null,liveOutput=false,identity=null,pending=[],marks=[];
    const capture=()=>({host:pane.host,ws:pane.host?.ws,hostGeneration:pane.host?.generation,
      generation:pane.generation,raw:pane.raw,sid:pane.sid,token:pane.host?.config?.token,
      relay:pane.host?.config?.relay,code:pane.host?.config?.code,authMode:pane.host?.config?.authMode});
    const same=(a,b)=>a&&b&&Object.keys(a).every(key=>a[key]===b[key]);
    function drop(item){clearTimeout(item.timer);for(const d of item.decorations||[])d.dispose();item.marker?.dispose();}
    function clear(){for(const item of [...pending,...marks])drop(item);if(enter){clearTimeout(enter.timer);drop(enter.item||{});}pending=[];marks=[];draft='';invalid=false;enter=null;liveOutput=false;}
    function valid(){
      if(dead)return false;
      const next=capture();if(!same(identity,next)){clear();identity=next;}
      try{return enabled&&isCurrent(pane)!==false&&pane.ready===true&&pane.host?.connected===true
        &&pane.host?.ws?.readyState===1&&!pane.replayPending&&term.options.disableStdin!==true
        &&term.textarea?.readOnly!==true;}catch{return false;}
    }
    function cursorSegment(){
      const b=term.buffer.active,end=b.baseY+b.cursorY;
      let start=end;while(start>0&&b.getLine(start)?.isWrapped)start--;
      if(end-start>=32)return null;
      let text='';const positions=[];
      for(let row=start;row<=end;row++){
        const line=b.getLine(row);if(!line)return null;
        const limit=row===end?b.cursorX:term.cols;
        for(let x=0;x<limit;x++){
          const cell=line.getCell(x);if(!cell?.getWidth())continue;
          const value=cell.getChars()||' ';
          for(let i=0;i<value.length;i++)positions.push({row,x,width:cell.getWidth()});
          text+=value;if(text.length>MAX_TEXT+1024)return null;
        }
      }
      return {text,positions,buffer:b};
    }
    function anchor(text){
      if(typeof text!=='string'||!text||text.length>MAX_TEXT||/[\x00-\x1f\x7f-\x9f]/.test(text))return null;
      const segment=cursorSegment();if(!segment?.text.endsWith(text))return null;
      const cells=segment.positions.slice(segment.text.length-text.length),ranges=[];
      for(const cell of cells){
        const old=ranges.at(-1);
        if(old&&old.row===cell.row&&cell.x<=old.x+old.width)old.width=Math.max(old.width,cell.x+cell.width-old.x);
        else ranges.push({row:cell.row,x:cell.x,width:cell.width});
      }
      if(!ranges.length)return null;
      const first=ranges[0].row,marker=term.registerMarker(first-segment.buffer.baseY-segment.buffer.cursorY);
      if(!marker)return null;
      return {text,marker,buffer:segment.buffer,ranges:ranges.map(r=>({...r,row:r.row-first})),identity:capture()};
    }
    function queue(item){
      if(!item)return false;
      if(pending.length>=MAX_PENDING)drop(pending.shift());
      item.timer=setTimeout(()=>{const at=pending.indexOf(item);if(at>=0){pending.splice(at,1);drop(item);}},LIFETIME);
      pending.push(item);return true;
    }
    function keydown(event){
      if(event.target!==term.textarea||!event.isTrusted||event.key!=='Enter'||event.repeat
        ||event.isComposing||pane.composing||event.shiftKey||event.ctrlKey||event.altKey||event.metaKey||!valid())return;
      const proof={item:!invalid?anchor(draft):null};enter=proof;
      // A browser may run microtasks between event listeners. Expire at the
      // next task so xterm's synchronous onData can confirm this same event.
      proof.timer=setTimeout(()=>{if(enter===proof){drop(proof.item||{});enter=null;}},0);
    }
    function observeAcceptedInput(text){
      if(!valid()||typeof text!=='string'||!text)return;
      if((text==='\r'||text==='\n')&&enter){
        const item=enter.item;clearTimeout(enter.timer);enter=null;draft='';invalid=false;queue(item);return;
      }
      if(text.startsWith('\x1b[200~')&&text.endsWith('\x1b[201~'))text=text.slice(6,-6);
      if(/[\x00-\x1f\x7f-\x9f]/.test(text)||draft.length+text.length>MAX_TEXT){draft='';invalid=true;return;}
      if(!invalid)draft+=text;
    }
    function textAt(item){
      const b=term.buffer.active;let text='';
      for(const range of item.ranges){
        const line=b.getLine(item.marker.line+range.row);if(!line)return null;
        for(let x=range.x;x<range.x+range.width;x++){
          const c=line.getCell(x);if(!c?.getWidth())continue;
          if(c.isInverse()||c.isInvisible()||!c.isBgDefault())return null;
          text+=c.getChars()||' ';
        }
      }
      return text;
    }
    function parsed(){
      const live=liveOutput;liveOutput=false;
      if(!valid()||!live)return;
      const b=term.buffer.active,current=b.baseY+b.cursorY;
      let start=current,end=current;
      while(start>0&&b.getLine(start)?.isWrapped)start--;
      while(end+1<b.length&&b.getLine(end+1)?.isWrapped)end++;
      for(const item of [...pending]){
        if(item.marker.isDisposed||item.buffer!==b||!same(item.identity,capture())){
          pending.splice(pending.indexOf(item),1);drop(item);continue;
        }
        const first=item.marker.line,last=first+item.ranges.at(-1).row;
        if(start<=last&&end>=first)continue;
        pending.splice(pending.indexOf(item),1);clearTimeout(item.timer);
        if(textAt(item)!==item.text){drop(item);continue;}
        item.decorations=[];
        for(const range of item.ranges){
          const marker=term.registerMarker(first+range.row-b.baseY-b.cursorY);
          if(!marker)continue;
          const d=term.registerDecoration({marker,x:range.x,width:range.width,foregroundColor:'#ffd75f',layer:'top'});
          if(d)item.decorations.push({dispose(){d.dispose();marker.dispose();}});else marker.dispose();
        }
        if(item.decorations.length){
          marks.push(item);
          while(marks.length>MAX_MARKS||marks.reduce((sum,item)=>sum+item.text.length,0)>MAX_MARK_TEXT)drop(marks.shift());
        }
        else drop(item);
      }
      marks=marks.filter(item=>{
        const first=item.marker.line,last=first+item.ranges.at(-1).row;
        if(item.marker.isDisposed||start<=last&&end>=first||textAt(item)!==item.text){drop(item);return false;}
        return true;
      });
    }
    doc.addEventListener('keydown',keydown,{capture:true,passive:true});
    const subscriptions=[term.onWriteParsed(parsed),term.buffer.onBufferChange(()=>clear())];
    identity=capture();
    return {
      observeAcceptedInput,
      beforeOutput({replay=false}={}){if(replay){clear();identity=capture();}else if(valid())liveOutput=true;},
      recordSubmission({text,source}={}){return valid()&&source==='explicit-submit'?queue(anchor(text)):false;},
      setEnabled(value){enabled=!!value;if(!enabled)clear();},
      reset(){clear();identity=capture();},
      dispose(){if(dead)return;dead=true;clear();doc.removeEventListener('keydown',keydown,true);for(const s of subscriptions)s.dispose();}
    };
  }
  window.TerminalQuestions=Object.freeze({create});
})();

;
/* Explicit clipboard actions for terminals and ordinary text editors. */
(()=>{
  'use strict';
  if(window.SuperMonoClipboardContext||!window.smaWorkspace)return;
  const W=window.smaWorkspace,menu=document.createElement('div'),notice=document.createElement('div'),style=document.createElement('style');
  menu.id='clipboard-context-menu';menu.setAttribute('role','menu');menu.hidden=true;
  notice.id='clipboard-context-status';notice.setAttribute('role','status');notice.hidden=true;
  style.textContent='#clipboard-context-menu{position:fixed;z-index:5000;min-width:170px;padding:4px;background:#242424;border:1px solid #626262;border-radius:5px;box-shadow:0 6px 20px #0008}#clipboard-context-menu[hidden],#clipboard-context-status[hidden]{display:none}#clipboard-context-menu button{display:block;width:100%;padding:7px 10px;text-align:left;color:#eee;background:transparent;border:0}#clipboard-context-menu button:disabled{color:#777}#clipboard-context-status{position:fixed;bottom:42px;right:18px;z-index:5001;max-width:min(440px,90vw);background:#292929;color:#eee;border:1px solid #555;padding:9px;overflow-wrap:anywhere}';
  const copy=document.createElement('button'),paste=document.createElement('button');
  copy.type=paste.type='button';copy.textContent='复制选中文本   Ctrl+C';paste.textContent='粘贴到光标处   Ctrl+V';
  copy.id='clipboard-context-copy';paste.id='clipboard-context-paste';copy.setAttribute('role','menuitem');paste.setAttribute('role','menuitem');menu.append(copy,paste);
  document.head.append(style);document.body.append(menu,notice);
  let current=null,timer=0,dead=false;
  const api=()=>window.pywebview?.api;
  function mount(target){const parent=target?.dialog?.open?target.dialog:document.body;parent.append(menu,notice);}
  function message(text,target){mount(target);notice.textContent=text;notice.hidden=false;clearTimeout(timer);timer=setTimeout(()=>notice.hidden=true,4500);}
  function close(){menu.hidden=true;current=null;}
  function paneIdentity(pane){return pane?{pane,host:pane.host,ws:pane.host.ws,generation:pane.generation,hostGeneration:pane.host.generation,token:pane.host.config?.token,raw:pane.raw}:null;}
  function samePane(value){return !value||W.panes.get(value.pane.sid)===value.pane&&value.pane.host===value.host&&value.host.ws===value.ws&&value.pane.generation===value.generation&&value.host.generation===value.hostGeneration&&value.host.config?.token===value.token&&value.pane.raw===value.raw;}
  function locate(element){
    if(!(element instanceof Element)||element.closest('#clipboard-context-menu'))return null;
    const field=element.closest('textarea,input');
    if(field&&!field.closest('.terminal-screen')&&!field.disabled&&(field.tagName==='TEXTAREA'||['text','search','url','email','tel','password'].includes(field.type))){
      const start=field.selectionStart,end=field.selectionEnd;
      if(!Number.isInteger(start)||!Number.isInteger(end))return null;
      return {kind:'field',field,start,end,value:field.value,dialog:field.closest('dialog'),identity:paneIdentity(W.activePane),selected:field.type==='password'?'':field.value.slice(start,end),canPaste:!field.readOnly};
    }
    const screen=element.closest('.terminal-screen');
    const pane=screen&&[...W.panes.values()].find(value=>value.screen===screen);
    if(!pane)return null;
    let fileTarget=null;try{fileTarget=window.SuperMonoFilePaste?.captureTarget?.();}catch{}
    return {kind:'terminal',identity:paneIdentity(pane),selected:pane.term.getSelection(),canPaste:pane.ready&&pane.host.connected&&!pane.term.options.disableStdin,fileTarget};
  }
  function valid(target){
    if(dead||!target||!samePane(target.identity))return false;
    if(target.kind==='terminal')return W.activePane===target.identity.pane&&target.identity.pane.ready&&target.identity.host.connected&&target.identity.ws?.readyState===1;
    return target.field.isConnected&&!target.field.disabled&&(!target.dialog||target.dialog.open)&&(!target.identity||W.activePane===target.identity.pane)&&target.field.value===target.value&&target.field.selectionStart===target.start&&target.field.selectionEnd===target.end;
  }
  async function copyText(target){
    if(!target?.selected||target.selected.length>524288)return;
    try{if(typeof api()?.clipboard_write_text==='function')await api().clipboard_write_text(target.selected);else await navigator.clipboard.writeText(target.selected);message('已复制选中文本。',target);if(valid(target)){if(target.kind==='terminal')target.identity.pane.term.focus();else target.field.focus();}}
    catch{message('复制未完成，请重试。',target);}
  }
  async function pasteText(target){
    if(!valid(target)||!target.canPaste)return;
    try{
      if(target.kind==='field'&&target.field.id==='terminal-composer-text'&&window.SuperMonoTerminalComposer?.pasteClipboard){await window.SuperMonoTerminalComposer.pasteClipboard();return;}
      const native=api();
      if(target.kind==='terminal'&&typeof native?.clipboard_has_files==='function'&&await native.clipboard_has_files()){
        if(!valid(target))throw Error('target_changed');
        if(!target.fileTarget||!window.SuperMonoFilePaste?.uploadClipboard)throw Error('files_unavailable');
        target.identity.pane.term.focus();
        await window.SuperMonoFilePaste.uploadClipboard({target:target.fileTarget});return;
      }
      const text=typeof native?.clipboard_read_text==='function'?await native.clipboard_read_text():await navigator.clipboard.readText();
      if(!valid(target)||(target.kind==='field'&&target.field.readOnly)||(target.kind==='terminal'&&target.identity.pane.term.options.disableStdin)||typeof text!=='string'||text.length>524288)throw Error('target_changed');
      if(!text){message('剪贴板中没有可粘贴的文本。',target);return;}
      if(target.kind==='terminal'){target.identity.pane.term.paste(text);target.identity.pane.term.focus();}
      else{const limit=target.field.maxLength,remaining=limit<0?text.length:Math.max(0,limit-(target.value.length-(target.end-target.start)));target.field.focus();target.field.setSelectionRange(target.start,target.end);target.field.setRangeText(text.slice(0,remaining),target.start,target.end,'end');target.field.dispatchEvent(new Event('input',{bubbles:true}));}
    }catch{message('粘贴未完成。请检查目标窗口；附件需要先设置项目目录和文件助手。',target);}
  }
  function context(event){const target=locate(event.target);if(!target)return;event.preventDefault();event.stopPropagation();mount(target);current=target;copy.disabled=!target.selected;paste.disabled=!target.canPaste;menu.hidden=false;
    menu.style.left=Math.max(4,Math.min(event.clientX,innerWidth-menu.offsetWidth-4))+'px';menu.style.top=Math.max(4,Math.min(event.clientY,innerHeight-menu.offsetHeight-4))+'px';(copy.disabled?paste:copy).focus();}
  function down(event){if(!event.target.closest?.('#clipboard-context-menu'))close();}
  function dialogClosed(event){if(event.target===menu.closest('dialog'))close();}
  function filePaste(event){
    if(event.target?.id!=='terminal-composer-text'||event.target.disabled||event.target.readOnly||!event.clipboardData?.files?.length||!window.SuperMonoTerminalComposer?.addFiles)return;
    event.preventDefault();event.stopPropagation();
    window.SuperMonoTerminalComposer.addFiles([...event.clipboardData.files]);
  }
  function key(event){
    if(!menu.hidden&&event.key==='Escape'){event.preventDefault();event.stopPropagation();const target=current;close();if(valid(target)){if(target.kind==='terminal')target.identity.pane.term.focus();else target.field.focus();}return;}
    if(!event.ctrlKey||event.metaKey||event.altKey||event.shiftKey)return;
    const target=locate(event.target);if(!target)return;
    const letter=event.key.toLowerCase();
    if(letter==='c'&&target.selected&&typeof api()?.clipboard_write_text==='function'){event.preventDefault();event.stopPropagation();copyText(target);}
    else if(letter==='v'&&target.kind==='field'&&typeof api()?.clipboard_read_text==='function'){event.preventDefault();event.stopPropagation();pasteText(target);}
  }
  copy.onclick=()=>{const target=current;close();copyText(target);};paste.onclick=()=>{const target=current;close();pasteText(target);};
  document.addEventListener('contextmenu',context,true);document.addEventListener('pointerdown',down,true);document.addEventListener('keydown',key,true);document.addEventListener('close',dialogClosed,true);document.addEventListener('paste',filePaste,true);
  function destroy(){if(dead)return;dead=true;clearTimeout(timer);document.removeEventListener('contextmenu',context,true);document.removeEventListener('pointerdown',down,true);document.removeEventListener('keydown',key,true);document.removeEventListener('close',dialogClosed,true);document.removeEventListener('paste',filePaste,true);window.removeEventListener('beforeunload',destroy);menu.remove();notice.remove();style.remove();delete window.SuperMonoClipboardContext;}
  window.SuperMonoClipboardContext={destroy};window.addEventListener('beforeunload',destroy,{once:true});
})();

;
/* Desktop-owned local worktree sidecar. No terminal input or transport hooks. */
(function installMylib(){
  'use strict';
  if(document.getElementById('mylib-toggle')||!window.smaWorkspace)return;
  if(!window.pywebview?.api?.recommend_skills){addEventListener('pywebviewready',installMylib,{once:true});return;}
  const style=document.createElement('style');
  style.textContent=`#mylib-panel{position:fixed;right:0;top:44px;bottom:0;width:350px;z-index:20;background:#191919;border-left:1px solid #444;padding:14px;overflow:auto;overflow-wrap:anywhere}body.mylib-open #app{margin-right:350px}#mylib-panel h2{font-size:15px}#mylib-panel p{font-size:12px;line-height:1.6;color:#bbb}#mylib-panel article{border:1px solid #444;border-radius:6px;padding:10px;margin:10px 0}#mylib-panel code{font-size:11px}#mylib-panel button{border:1px solid #444;margin:3px}#mylib-context{max-height:140px;overflow:auto;white-space:pre-wrap;font-size:11px;color:#aaa}.mylib-actions{display:flex;flex-wrap:wrap;gap:3px}.mylib-status{color:#aaa!important;font-size:11px!important}.mylib-change-list{max-height:220px;overflow:auto;font-size:11px}.mylib-candidate{border-color:#668!important}@media(max-width:1050px){body.mylib-open #app{margin-right:0}#mylib-panel{width:min(350px,100vw)}}`;
  style.textContent+='#mylib-panel{top:var(--workspace-titlebar-height,44px)}#mylib-library-source{display:flex;align-items:flex-start;gap:7px}#mylib-library-source::before{content:"";flex:0 0 8px;width:8px;height:8px;margin-top:5px;border-radius:50%;background:#666}#mylib-library-source[data-accessible="true"]::before{background:#65c466;box-shadow:0 0 5px #65c46666}';
  document.head.append(style);
  const toggle=document.createElement('button');toggle.id='mylib-toggle';toggle.textContent='mylib 助理';toggle.setAttribute('aria-expanded','false');
  document.querySelector('.titlebar .header-spacer')?.before(toggle);
  const panel=document.createElement('aside');panel.id='mylib-panel';panel.hidden=true;panel.setAttribute('aria-label','mylib 助理');
  panel.innerHTML='<h2>mylib 助理</h2><p id="mylib-target"></p><div class="mylib-actions"><button id="mylib-directory">目录设置</button><button id="mylib-pull">拉取</button><button id="mylib-commit">提交</button><button id="mylib-evolve">进化评审</button><button id="mylib-refresh">重新分析</button><button id="mylib-pause">暂停感知</button></div><p id="mylib-library-source">使用本地 mylib。</p><p id="mylib-sync-status" class="mylib-status" role="status"></p><details><summary>本次上下文</summary><pre id="mylib-context"></pre></details><div id="mylib-results"></div><details><summary>metaRSI 进化</summary><p>当前窗口信号只用于本地评审。候选必须显式采纳，提交必须再次确认，不自动修改或批准规则。</p></details>';
  const evolution=document.createElement('section');evolution.id='mylib-evolution';evolution.setAttribute('aria-label','metaRSI 进化建议');panel.append(evolution);
  const project=document.createElement('details'),projectHeading=document.createElement('summary'),projectNote=document.createElement('p'),ledger=document.createElement('pre');project.id='mylib-project';projectHeading.textContent='目标项目与证据账本';ledger.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px';project.append(projectHeading,projectNote,ledger);panel.append(project);
  document.body.append(panel);
  const preview=document.createElement('dialog');preview.id='mylib-skill-preview';preview.setAttribute('aria-label','本地技能或候选正文');
  preview.style.cssText='width:min(760px,90vw);max-height:85dvh;overflow:auto';
  const previewTitle=document.createElement('h2'),previewSource=document.createElement('p'),previewText=document.createElement('pre'),previewApply=document.createElement('button'),previewClose=document.createElement('button');
  previewText.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px';previewApply.textContent='采纳候选';previewApply.hidden=true;previewClose.textContent='关闭';previewClose.onclick=()=>preview.close();preview.append(previewTitle,previewSource,previewText,previewApply,previewClose);document.body.append(preview);
  let previewRevision=0;
  preview.addEventListener('close',()=>{previewRevision++;previewApply.hidden=true;});
  const directoryDialog=document.createElement('dialog');directoryDialog.id='mylib-directory-dialog';
  directoryDialog.innerHTML='<form id="mylib-directory-form"><h2>mylib 目录设置</h2><p>默认 D:/aicoding/mylib。目录仅在本机读取，可修改为其他磁盘位置。</p><label>本地目录<input id="mylib-directory-root" type="text" maxlength="4096" required autocomplete="off" spellcheck="false"></label><p id="mylib-directory-status" role="status"></p><div class="dialog-actions"><button id="mylib-directory-cancel" type="button">取消</button><button type="submit">保存并应用</button></div></form>';
  document.body.append(directoryDialog);
  const commitDialog=document.createElement('dialog');commitDialog.id='mylib-commit-dialog';
  commitDialog.innerHTML='<form id="mylib-commit-form"><h2>提交并推送到 GitHub</h2><p>先检查变更。确认后才会暂存、提交并推送，敏感文件和本地状态不会加入。</p><div id="mylib-commit-files" class="mylib-change-list"></div><pre id="mylib-commit-stat"></pre><label>提交说明<input id="mylib-commit-message" type="text" maxlength="200" value="Update local skills" required></label><p id="mylib-commit-status" role="status"></p><div class="dialog-actions"><button id="mylib-commit-cancel" type="button">取消</button><button id="mylib-commit-confirm" type="submit">确认提交并推送</button></div></form>';
  document.body.append(commitDialog);
  let syncBusy=false,currentCommit=null,currentCandidate=null;
  const syncStatus=panel.querySelector('#mylib-sync-status');
  const syncError=error=>{const code=String(error?.message||error||'unknown'),labels={dirty_worktree:'工作区有未提交修改，请先提交或清理后再拉取。',non_fast_forward:'上游历史已分叉，不能执行 fast-forward。',changes_changed:'变更清单已变化，请重新预览后再提交。',source_drift:'技能文件已变化，请重新进行进化评审。',unknown_suggestion:'候选不存在或已失效，请重新评审。',no_changes:'没有可提交的变更。',source_unavailable:'目录或 Git 工作副本不可用。',directory_unavailable:'目录不存在或不可访问，请检查路径和权限。',sync_busy:'另一个 mylib 操作正在执行，请稍后重试。',cancelled:'操作已取消。',git_failed:'Git 操作失败，请检查网络、认证和仓库配置。',invalid_config:'目录或配置无效。'};return labels[code]||'操作未完成：'+code;};
  function renderLibrarySource({root='',accessible=false,detail=''}){
    const source=panel.querySelector('#mylib-library-source');source.dataset.root=root;source.dataset.accessible=String(accessible===true);source.title=accessible?'目录存在且可读取':'目录未验证或不可访问';source.textContent='本机 mylib · '+(root||'目录未配置')+(detail?' · '+detail:'');
  }
  async function refreshLibraryStatus(){
    if(!window.pywebview.api.library_status)return;
    try{const status=await pywebview.api.library_status(),detail=status.accessible?(status.git?(status.revision||'').slice(0,12)+(status.changes.length?' · '+status.changes.length+' 项待提交':' · 工作区干净'):'非 Git 目录'):'目录不可访问';renderLibrarySource({root:status.root,accessible:status.accessible,detail});return status;}catch(error){const source=panel.querySelector('#mylib-library-source');renderLibrarySource({root:source.dataset.root,accessible:false,detail:'目录状态读取失败'});syncStatus.textContent=syncError(error);return null;}
  }
  if(window.pywebview.api.get_assistant_preferences&&window.pywebview.api.save_assistant_preferences){
    const settings=document.createElement('dialog');settings.id='mylib-settings';
    settings.innerHTML='<form id="mylib-settings-form"><h2>助手模型配置</h2><p>保存配置不会发起模型调用。发送问题时才调用所选入口。</p><label>模型入口<select id="mylib-provider"><option value="unconfigured">稍后配置</option><option value="codex">本机 Codex 登录</option><option value="api">已有模型 API</option></select></label><label>模型名称<input id="mylib-model" type="text" maxlength="128" autocomplete="off"></label><label id="mylib-endpoint-label">API 地址<input id="mylib-endpoint" type="url" maxlength="2048" autocomplete="off" placeholder="https://…/v1"></label><label id="mylib-key-label">API 密钥（仅本次运行保留）<input id="mylib-api-key" type="password" maxlength="8192" autocomplete="off" placeholder="本机无鉴权服务可留空"></label><label class="check"><input id="mylib-auto-context" type="checkbox">对话时自动附带当前窗口上下文</label><label>上下文字符上限<input id="mylib-context-limit" type="number" min="512" max="32768" step="1"></label><p id="mylib-settings-status" role="status"></p><div class="dialog-actions"><button id="mylib-settings-cancel" type="button">取消</button><button id="mylib-settings-save" type="submit">保存配置</button></div></form>';
    const extra=document.createElement('style');extra.textContent='#mylib-settings{max-height:85dvh;overflow:auto}#mylib-settings input:not([type=checkbox]),#mylib-settings select{width:100%;max-width:100%}#mylib-settings label{overflow-wrap:anywhere}';document.head.append(extra);document.body.append(settings);
    const $=id=>settings.querySelector('#'+id),button=document.createElement('button');button.id='mylib-configure';button.textContent='模型配置';panel.querySelector('#mylib-pause').after(button);
    let loading=false;
    const refreshFields=()=>{const api=$('mylib-provider').value==='api',key=api&&!!window.pywebview.api.set_assistant_api_key;$('mylib-endpoint-label').hidden=!api;$('mylib-endpoint').disabled=!api;$('mylib-key-label').hidden=!key;$('mylib-api-key').disabled=!key;$('mylib-model').placeholder=$('mylib-provider').value==='codex'?'留空使用登录配置':'填写模型标识';};
    $('mylib-provider').onchange=refreshFields;
    button.onclick=async()=>{if(loading)return;loading=true;button.disabled=true;try{const result=await pywebview.api.get_assistant_preferences(),p=result.preferences;$('mylib-provider').value=p.provider;$('mylib-model').value=p.model;$('mylib-endpoint').value=p.endpoint;$('mylib-api-key').value='';$('mylib-api-key').placeholder=result.api_key_present?'已设置；留空保持，本次运行有效':'本机无鉴权服务可留空';$('mylib-auto-context').checked=p.auto_context;$('mylib-context-limit').value=p.max_context_chars;settings.dataset.libraryRoot=p.library_root;refreshFields();$('mylib-settings-status').textContent=result.status==='invalid'?'原配置暂不可读，已显示默认值；保存前请检查。':'';settings.showModal();}catch{panel.querySelector('#mylib-results').textContent='模型配置暂不可读。';}finally{loading=false;button.disabled=false;}};
    $('mylib-settings-cancel').onclick=()=>{ $('mylib-api-key').value='';settings.close();};settings.addEventListener('cancel',()=>{$('mylib-api-key').value='';});
    $('mylib-settings-form').onsubmit=async event=>{event.preventDefault();const save=$('mylib-settings-save');if(save.disabled)return;save.disabled=true;let saved=false;try{await pywebview.api.save_assistant_preferences({provider:$('mylib-provider').value,model:$('mylib-model').value,endpoint:$('mylib-provider').value==='api'?$('mylib-endpoint').value:'',auto_context:$('mylib-auto-context').checked,max_context_chars:Number($('mylib-context-limit').value),library_root:settings.dataset.libraryRoot});saved=true;dispatchEvent(new Event('mylib-preferences-changed'));if($('mylib-provider').value==='api'&&$('mylib-api-key').value&&pywebview.api.set_assistant_api_key)await pywebview.api.set_assistant_api_key($('mylib-api-key').value);$('mylib-settings-status').textContent='配置已保存；发送问题时才调用模型。';}catch{$('mylib-settings-status').textContent=saved?'入口已保存，但密钥未接受，请检查后重新输入。':'配置未保存，请检查模型名称、地址和上下文上限。';}finally{$('mylib-api-key').value='';save.disabled=false;}};
  }
  async function withSync(action,label){if(syncBusy)return;syncBusy=true;panel.dataset.syncBusy='true';syncStatus.textContent=label;try{return await action();}catch(error){syncStatus.textContent=syncError(error);return null;}finally{syncBusy=false;panel.dataset.syncBusy='false';}}
  panel.querySelector('#mylib-directory').onclick=async()=>{try{const result=await pywebview.api.get_assistant_preferences(),root=directoryDialog.querySelector('#mylib-directory-root');root.value=result.preferences.library_root;directoryDialog.querySelector('#mylib-directory-status').textContent='';directoryDialog.showModal();}catch(error){syncStatus.textContent=syncError(error);}};
  directoryDialog.querySelector('#mylib-directory-cancel').onclick=()=>directoryDialog.close();
  directoryDialog.querySelector('#mylib-directory-form').onsubmit=event=>{event.preventDefault();withSync(async()=>{
    const status=directoryDialog.querySelector('#mylib-directory-status');
    try{const result=await pywebview.api.get_assistant_preferences(),preferences={...result.preferences,library_root:directoryDialog.querySelector('#mylib-directory-root').value};await pywebview.api.save_assistant_preferences(preferences);}catch(error){status.textContent=syncError(error);return;}
    const library=await refreshLibraryStatus();if(!library?.accessible){status.textContent=syncError(Error('directory_unavailable'));return;}
    directoryDialog.close();await analyze(true);
  },'正在检查并切换目录…');};
  panel.querySelector('#mylib-pull').onclick=()=>withSync(async()=>{const result=await pywebview.api.pull_library();if(!result)return;syncStatus.textContent=result.changed?'已拉取新版本 '+(result.revision||'').slice(0,12):'已经是最新版本。';await refreshLibraryStatus();await analyze(true);},'正在从 GitHub 拉取…');
  panel.querySelector('#mylib-commit').onclick=()=>withSync(async()=>{currentCommit=await pywebview.api.commit_library_preview();if(!currentCommit?.can_commit){syncStatus.textContent='没有可提交的变更。';return;}const files=commitDialog.querySelector('#mylib-commit-files');files.replaceChildren();for(const item of currentCommit.items){const row=document.createElement('p');row.textContent=(item.excluded?'排除：':'包含：')+item.code+' '+item.path;files.append(row);}commitDialog.querySelector('#mylib-commit-stat').textContent=currentCommit.stat||'仅包含新增或删除文件。';commitDialog.querySelector('#mylib-commit-status').textContent=currentCommit.excluded_count?'已自动排除 '+currentCommit.excluded_count+' 项本地状态或敏感文件。':'';commitDialog.showModal();},'正在检查变更…');
  commitDialog.querySelector('#mylib-commit-cancel').onclick=()=>commitDialog.close();
  commitDialog.querySelector('#mylib-commit-form').onsubmit=event=>{event.preventDefault();withSync(async()=>{if(!currentCommit)return;const result=await pywebview.api.commit_library({fingerprint:currentCommit.fingerprint,message:commitDialog.querySelector('#mylib-commit-message').value});if(!result)return;commitDialog.close();currentCommit=null;syncStatus.textContent='已提交并推送 '+(result.revision||'').slice(0,12);await refreshLibraryStatus();await analyze(true);},'正在提交并推送…');};
  panel.querySelector('#mylib-evolve').onclick=()=>withSync(async()=>{const c=capture();if(!c){syncStatus.textContent='请先选择一个终端窗口。';return;}const result=await pywebview.api.run_library_evolution({text:c.text,target:c.target});if(!result)return;evolution.replaceChildren();syncStatus.textContent='评审完成：'+result.count+' 个候选；采纳后仍需手动提交。';if(!result.items.length){const empty=document.createElement('p');empty.textContent='当前没有新的结构化候选。';evolution.append(empty);}for(const item of result.items){const article=document.createElement('article');article.className='mylib-candidate';const title=document.createElement('strong'),problem=document.createElement('p'),hypothesis=document.createElement('p'),falsifier=document.createElement('p'),validation=document.createElement('p'),previewButton=document.createElement('button'),applyButton=document.createElement('button');title.textContent=item.title;problem.textContent=item.problem;hypothesis.textContent=item.hypothesis;falsifier.textContent='可证伪条件：'+item.falsifier;validation.textContent='独立校验：'+item.validation.scope+' · '+(item.validation.passed?'结构通过':'未通过')+'；语义效果未验证。';previewButton.textContent='预览候选';previewButton.onclick=()=>{currentCandidate=item;previewTitle.textContent=item.title;previewSource.textContent=item.source.path+' · '+item.source.sha256.slice(0,12);previewText.textContent=item.candidate_text;previewApply.hidden=false;preview.showModal();};applyButton.textContent='采纳候选';applyButton.onclick=()=>withSync(async()=>{const applied=await pywebview.api.apply_library_evolution({suggestion_id:item.suggestion_id});if(!applied)return;syncStatus.textContent='已采纳到本地工作副本；请点击“提交”预览并推送。';await refreshLibraryStatus();},'正在采纳候选…');article.append(title,problem,hypothesis,falsifier,validation,previewButton,applyButton);evolution.append(article);}},'正在进行本地进化评审…');
  previewApply.onclick=()=>{if(!currentCandidate)return;preview.close();withSync(async()=>{const applied=await pywebview.api.apply_library_evolution({suggestion_id:currentCandidate.suggestion_id});if(!applied)return;syncStatus.textContent='已采纳到本地工作副本；请点击“提交”预览并推送。';await refreshLibraryStatus();},'正在采纳候选…');};
  let paused=false,revision=0,last='',lastIdentity=null,lastReadiness='',analysisState=null,timer;
  const content=panel.querySelector('#mylib-results');
  function capture(){
    const w=window.smaWorkspace,p=w.activePane;if(!p)return null;
    const b=p.term.buffer.active,lines=[];
    const end=b.baseY+b.cursorY;
    for(let i=Math.max(0,end-199);i<=end;i++){const line=b.getLine(i),continues=i<end&&b.getLine(i+1)?.isWrapped,text=line?.translateToString(!continues)||'';if(line?.isWrapped&&lines.length)lines[lines.length-1]+=text;else lines.push(text);}
    return {pane:p,generation:p.generation,id:w.activeSession,identity:evidenceIdentity(p),readiness:[p.host.connected,p.host.ws?.readyState,p.ready,p.host.phase,p.host.capabilities.assistant_context===true].join('|'),text:lines.join('\n').slice(-32768),target:(p.host.name||p.host.id)+' / '+(p.title?.textContent||p.raw)};
  }
  let contextSequence=0;
  const evidenceCache=new WeakMap(),evidencePending=new Set(),evidencePages=['README.md','negatives.md','trials.md','nodes.md','ideas.md'];
  const bounded=(value,limit)=>{if(typeof value!=='string')return '';let text=value.slice(0,limit);const last=text.charCodeAt(text.length-1);if(last>=0xd800&&last<=0xdbff)text=text.slice(0,-1);return text;};
  const evidenceIdentity=pane=>({pane,host:pane.host,generation:pane.host.generation,paneGeneration:pane.generation,ws:pane.host.ws,token:typeof pane.host.config?.token==='string'?pane.host.config.token:'',session:pane.raw});
  const sameEvidenceIdentity=(a,b)=>!!a&&!!b&&a.pane===b.pane&&a.host===b.host&&a.generation===b.generation&&a.paneGeneration===b.paneGeneration&&a.ws===b.ws&&a.token===b.token&&a.session===b.session;
  function currentEvidence(identity){
    try{const w=window.smaWorkspace;return !!identity&&w.panes.get(identity.pane.sid)===identity.pane&&w.connections.get(identity.host.id)===identity.host&&identity.host.connected&&identity.ws?.readyState===WebSocket.OPEN&&typeof identity.session==='string'&&identity.session.length>0&&identity.session.length<=256&&sameEvidenceIdentity(identity,evidenceIdentity(identity.pane));}catch{return false;}
  }
  function evidenceFailure(note){return {ok:false,available:false,captured_at:Date.now(),project:null,project_truncated:false,project_source:'',project_status:'unavailable',note,inventory:{available:false,status:'unavailable',indexed:0,skill_names:[],truncated:false},ledger:{enabled:false,status:'unavailable',pages:{}}};}
  const copyEvidence=value=>JSON.parse(JSON.stringify(value));
  function normalizeEvidence(value){
    if(!value||typeof value!=='object'||Array.isArray(value)||value.project_source!=='session-startup-directory'||!value.ledger||typeof value.ledger!=='object'||Array.isArray(value.ledger)||typeof value.ledger.enabled!=='boolean')throw Error('Invalid evidence');
    const pages={};
    for(const name of evidencePages){
      const page=value.ledger.pages?.[name];if(page===undefined)continue;
      if(typeof page==='string'){const text=bounded(page,8192);pages[name]={status:'ready',text,truncated:text.length<page.length};continue;}
      if(!page||typeof page!=='object'||Array.isArray(page))continue;
      const text=bounded(page.text,8192),status=['ready','missing','unavailable'].includes(page.status)?page.status:'unavailable';
      const included=status==='ready'?text:'';
      pages[name]={status,text:included,truncated:page.truncated===true||typeof page.text==='string'&&included.length<page.text.length};
      if(typeof page.mtime==='number'&&Number.isFinite(page.mtime)&&page.mtime>=0&&page.mtime<=253402300799)pages[name].mtime=page.mtime;
    }
    const inventory=value.inventory&&typeof value.inventory==='object'&&!Array.isArray(value.inventory)?value.inventory:{},names=Array.isArray(inventory.skill_names)?inventory.skill_names.filter(name=>typeof name==='string').slice(0,256).map(name=>bounded(name,100)):[];
    const path=typeof value.project==='string'?bounded(value.project,4096):null;
    return {ok:true,available:true,captured_at:Date.now(),project:path,project_truncated:value.project_truncated===true||typeof value.project==='string'&&path.length<value.project.length,project_source:'session-startup-directory',project_status:['ready','missing','unavailable'].includes(value.project_status)?value.project_status:'unavailable',note:bounded(value.note,512),inventory:{available:inventory.available===true,status:['ready','empty','missing','unavailable'].includes(inventory.status)?inventory.status:'unavailable',indexed:Number.isSafeInteger(inventory.indexed)&&inventory.indexed>=0&&inventory.indexed<=100000?inventory.indexed:names.length,skill_names:names,truncated:inventory.truncated===true||Array.isArray(inventory.skill_names)&&(inventory.skill_names.length>256||inventory.skill_names.some(name=>typeof name==='string'&&bounded(name,100).length<name.length))},ledger:{enabled:value.ledger.enabled,status:['ready','partial','unavailable','not_enabled'].includes(value.ledger.status)?value.ledger.status:'unavailable',pages}};
  }
  function readEvidence(pane,{force=false}={}){
    let identity;try{identity=evidenceIdentity(pane);}catch{return Promise.resolve(evidenceFailure('未获得有效终端窗口。'));}
    const deliver=value=>currentEvidence(identity)?copyEvidence(value):evidenceFailure('窗口连接身份已改变，请重新读取账本。');
    let entry=evidenceCache.get(pane);
    if(entry&&!sameEvidenceIdentity(entry.identity,identity)){entry.pending?.cancel('窗口连接身份已改变，请重新读取账本。');evidenceCache.delete(pane);entry=null;}
    if(!currentEvidence(identity))return Promise.resolve(evidenceFailure('目标窗口未连接或已经关闭。'));
    if(!identity.host.capabilities.assistant_context)return Promise.resolve(evidenceFailure('目标后台尚不支持项目账本读取。'));
    if(entry?.pending)return entry.pending.promise.then(deliver);
    if(!force&&entry?.value&&performance.now()<entry.expires)return Promise.resolve().then(()=>deliver(entry.value));
    entry={identity,value:null,expires:0,pending:null};evidenceCache.set(pane,entry);
    const request='assistant-'+(++contextSequence)+'-'+Date.now().toString(36),ws=identity.ws,deadline=performance.now()+8000,control={promise:null,cancel:null};
    control.promise=new Promise(resolve=>{
      let settled=false,timeout;
      const finish=value=>{if(settled)return;settled=true;clearTimeout(timeout);ws.removeEventListener('message',receive);ws.removeEventListener('close',closed);ws.removeEventListener('error',closed);evidencePending.delete(control);entry.pending=null;if(performance.now()>=deadline)value=evidenceFailure('项目账本读取超时。');if(!currentEvidence(identity))value=evidenceFailure('窗口连接身份已改变，请重新读取账本。');else if(value.available&&evidenceCache.get(pane)===entry){entry.value=value;entry.expires=performance.now()+15000;}resolve(value);};
      control.cancel=note=>finish(evidenceFailure(note));
      const closed=()=>finish(evidenceFailure('目标连接已断开。'));
      const receive=event=>{
        if(!(event.data instanceof ArrayBuffer))return;
        const bytes=new Uint8Array(event.data);if(bytes.length<5||bytes[4]!==22)return;
        if(bytes.length-5>256*1024){finish(evidenceFailure('项目账本响应超过读取上限。'));return;}
        try{const frame=TerminalClient.unpack(bytes);if(frame.op!==22)return;const response=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(frame.payload));if(!response||typeof response!=='object'||Array.isArray(response))throw Error('Invalid evidence');if(response.request!==request)return;if(response.ok!==true){finish(evidenceFailure('项目账本暂不可用。'));return;}finish(normalizeEvidence(response));}catch{finish(evidenceFailure('项目账本响应无效，请稍后重试。'));}
      };
      ws.addEventListener('message',receive);ws.addEventListener('close',closed);ws.addEventListener('error',closed);timeout=setTimeout(()=>finish(evidenceFailure('项目账本读取超时。')),8000);evidencePending.add(control);
      try{const frame=TerminalClient.pack(22,new TextEncoder().encode(JSON.stringify({request,session:identity.session})));ws.send(frame);window.smaWorkspace.metrics.transmittedBytes+=identity.host.meter.sent(frame);}catch{closed();}
    });
    if(evidencePending.has(control))entry.pending=control;
    return control.promise.then(deliver);
  }
  window.SuperMonoAssistantEvidence={read:readEvidence};
  function recordMatches(idea,context){
    const faultLines=Array.isArray(idea.evidence)?idea.evidence.filter(line=>typeof line==='string').slice(0,3).map(line=>line.slice(0,240)):[],terms=new Set(),stop=new Set(['error','exception','traceback','failed','failure','running','task','test','tests','file','line','失败','异常','故障','记录','建议','验证']);
    for(const line of faultLines){for(const word of line.toLowerCase().match(/[a-z][a-z0-9_-]{2,}/g)||[])if(!stop.has(word))terms.add(word);for(const phrase of line.match(/[\u4e00-\u9fff]+/g)||[])for(let i=0;i<phrase.length-1;i++){const word=phrase.slice(i,i+2);if(!stop.has(word))terms.add(word);}}
    const words=[...terms].slice(0,64),matches=[];
    for(const name of ['negatives.md','trials.md','nodes.md','ideas.md','README.md']){
      const page=context.ledger?.pages?.[name];if(page?.status!=='ready'||!page.text)continue;
      const lines=page.text.split('\n');let best=null,heading='';
      for(let i=0;i<lines.length;i++){if(/^#{1,6}\s/.test(lines[i]))heading=lines[i];const lower=lines[i].toLowerCase(),hit=words.filter(word=>lower.includes(word));if(!hit.length||hit.length<2&&!hit.some(word=>word.length>=6))continue;if(!best||hit.length>best.score)best={score:hit.length,text:[heading,...lines.slice(Math.max(0,i-1),i+2)].filter((line,index,all)=>line&&all.indexOf(line)===index).join('\n').slice(0,600)};}
      if(best){const category=name==='negatives.md'?'否决记录':name==='trials.md'?'试验记录':name==='ideas.md'?'想法记录':name==='nodes.md'&&/shadow|影子/i.test(best.text)?'影子规则节点':name==='nodes.md'?'证据节点':'账本入口';matches.push({source:'.metarsi/wiki/'+name,category,text:best.text});}
    }
    return {faultLines,matches:matches.slice(0,3)};
  }
  async function analyze(force=false){
    if(panel.hidden||paused)return;
    const c=capture();if(!c){content.textContent='请选择一个终端窗口。';evolution.replaceChildren();projectNote.textContent='未选择终端窗口。';ledger.textContent='';last='';lastIdentity=null;lastReadiness='';analysisState=null;return;}
    const signature=c.id+'|'+c.generation+'|'+c.text,sameContext=signature===last&&sameEvidenceIdentity(lastIdentity,c.identity),sameState=sameContext&&c.readiness===lastReadiness;
    if(sameContext&&analysisState?.pending&&analysisState.revision===revision)return;
    if(!force&&sameState&&(!analysisState?.failed||performance.now()<analysisState.retryAt))return;
    const run={pending:true,failed:false,failures:sameState?analysisState?.failures||0:0,retryAt:0};analysisState=run;
    last=signature;lastIdentity=c.identity;lastReadiness=c.readiness;const request=++revision;run.revision=request;
    const retry=()=>{run.failed=true;run.failures++;run.retryAt=performance.now()+Math.min(30000,4000*2**Math.min(run.failures-1,3));};
    panel.querySelector('#mylib-target').textContent=c.target;
    panel.querySelector('#mylib-context').textContent=c.text;
    content.textContent='正在读取技能目录并匹配…';
    evolution.textContent='';
    projectNote.textContent='正在查询目标电脑的启动目录…';ledger.textContent='';
    try{
      const api=window.pywebview?.api;if(!api?.recommend_skills)throw Error('本机助理接口尚未就绪，请稍后重新分析。');
      const [result,context]=await Promise.all([api.recommend_skills(c.text),readEvidence(c.pane,{force})]),w=window.smaWorkspace;
      if(request!==revision||panel.hidden||w.activePane!==c.pane||w.panes.get(c.pane.sid)!==c.pane||!sameEvidenceIdentity(c.identity,evidenceIdentity(c.pane))){run.failed=true;run.retryAt=0;return;}
      if(!context.available&&currentEvidence(c.identity)&&c.identity.host.capabilities.assistant_context)retry();else run.failures=0;
      content.replaceChildren();
      const library=result.library||{},source=panel.querySelector('#mylib-library-source'),root=library.root||'';
      renderLibrarySource({root,accessible:source.dataset.root===root&&source.dataset.accessible==='true',detail:'匹配 '+result.indexed+' 项'});
      projectNote.textContent=context.project?'终端启动目录：'+context.project+'（不跟踪 shell 内的 cd）'+(context.ledger?.enabled?' · 已关联证据账本。':context.ledger?.status==='not_enabled'?' · 此目录未启用 metaRSI。':' · 项目证据暂不可读。'):context.note||'未获得可信项目目录。';
      ledger.textContent=Object.entries(context.ledger?.pages||{}).map(([name,page])=>name+' ['+({ready:'已读取',missing:'无记录',unavailable:'无法读取'}[page.status]||'未知')+']\n'+(typeof page==='string'?page:page.text||'')+(page.truncated?'\n[内容已截断]':'')).join('\n\n');
      for(const idea of result.evolution||[]){const article=document.createElement('article'),heading=document.createElement('strong'),evidence=document.createElement('p'),next=document.createElement('p'),falsifier=document.createElement('p'),boundary=document.createElement('p'),related=recordMatches(idea,context);heading.textContent=bounded(idea.name,240)+' · 未验证（待验证建议）';evidence.textContent='具体故障输出行：'+related.faultLines.join('；');next.textContent=bounded(idea.next_step,1024);falsifier.textContent='可证伪条件：'+bounded(idea.falsifier,1024);boundary.textContent='账本静态快照；输出行数不是独立故障计数。未执行 tick、独立验证或自动准入。';article.append(heading,evidence,next,falsifier,boundary);for(const record of related.matches){const source=document.createElement('code'),snippet=document.createElement('p');source.textContent=record.category+'片段 · '+record.source;snippet.textContent=record.text;article.append(source,snippet);}if(!related.matches.length){const missing=document.createElement('p');missing.textContent=context.ledger?.enabled?'可读账本快照中没有可靠匹配的记录，暂不推断已有否决、试验或影子规则。':'未获得可读账本，不能判断是否已有同类否决、试验或影子规则。';article.append(missing);}evolution.append(article);}
      if(!result.available){content.textContent='未找到本机 mylib，请通过“目录设置”选择有效目录。';return;}
      if(!result.skills.length){content.textContent='没有匹配到技能；已索引 '+result.indexed+' 项。';return;}
      for(const card of result.skills){
        const article=document.createElement('article'),title=document.createElement('strong'),description=document.createElement('p'),reason=document.createElement('p'),source=document.createElement('code'),copy=document.createElement('button');
        title.textContent=card.name;description.textContent=card.description;reason.textContent=card.reason;source.textContent=card.source;
        copy.textContent='复制调用指令';copy.onclick=async()=>{try{await navigator.clipboard.writeText('请使用 '+card.name+' 技能；先读取 '+card.source+'，再按技能要求处理当前任务，并确认本机适用条件。');copy.textContent='已复制';}catch{copy.textContent='复制失败';}};
        article.append(title,description,reason,source,document.createElement('br'),copy);content.append(article);
        if(context.inventory?.available){const availability=document.createElement('p');availability.textContent=context.inventory.skill_names.includes(card.name)?'目标电脑技能库中可找到此技能。':'目标电脑技能库中未找到此技能；使用前需配置。';article.append(availability);}
      }
    }catch(error){run.failed=true;run.retryAt=0;if(request===revision&&!panel.hidden&&window.smaWorkspace.activePane===c.pane&&sameEvidenceIdentity(c.identity,evidenceIdentity(c.pane))){content.textContent=String(error.message||error);if(currentEvidence(c.identity))retry();}}
    finally{run.pending=false;}
  }
  toggle.onclick=()=>{panel.hidden=!panel.hidden;revision++;if(panel.hidden&&preview.open)preview.close();document.body.classList.toggle('mylib-open',!panel.hidden);toggle.setAttribute('aria-expanded',String(!panel.hidden));if(!panel.hidden){refreshLibraryStatus();analyze(true);}};
  panel.querySelector('#mylib-refresh').onclick=()=>analyze(true);
  panel.querySelector('#mylib-pause').onclick=event=>{paused=!paused;revision++;event.target.textContent=paused?'继续感知':'暂停感知';if(!paused)analyze(true);};
  timer=setInterval(()=>analyze(),4000);
  addEventListener('beforeunload',()=>{clearInterval(timer);revision++;for(const pending of [...evidencePending])pending.cancel('页面已关闭，账本读取已停止。');},{once:true});
})();

;
/* Assistant conversation sidecar: no terminal input, resize, or direct network. */
(function installAssistantChat(){
  'use strict';
  if(document.getElementById('assistant-chat-section'))return;
  const panel=document.getElementById('mylib-panel'),api=window.pywebview?.api,W=window.smaWorkspace;
  if(!panel||!api?.assistant_chat||!W){addEventListener('pywebviewready',installAssistantChat,{once:true});return;}
  const create=(tag,text)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;return element;};
  const section=create('section');section.id='assistant-chat-section';section.setAttribute('aria-label','助手对话');
  const heading=create('h3','助手对话'),history=create('div');history.id='assistant-chat-history';history.setAttribute('role','log');history.setAttribute('aria-live','polite');
  const form=create('form'),label=create('label','给当前窗口助手提问'),question=create('textarea');form.id='assistant-chat-form';question.id='assistant-chat-question';question.maxLength=4000;question.rows=4;question.placeholder='输入问题，或分析当前窗口';label.htmlFor=question.id;
  const attachLabel=create('label'),attach=create('input');attach.type='checkbox';attach.id='assistant-chat-context';attachLabel.append(attach,document.createTextNode('附带当前窗口最近输出'));
  const ledgerLabel=create('label'),attachLedger=create('input');attachLedger.type='checkbox';attachLedger.id='assistant-chat-ledger';ledgerLabel.append(attachLedger,document.createTextNode('附带项目账本片段，发送到所选模型'));
  const actions=create('div'),send=create('button','发送'),analyze=create('button','分析当前窗口'),cancel=create('button','取消');send.id='assistant-chat-send';send.type='submit';analyze.id='assistant-chat-analyze';analyze.type='button';cancel.id='assistant-chat-cancel';cancel.type='button';actions.append(send,analyze,cancel);
  const status=create('p');status.id='assistant-chat-status';status.setAttribute('role','status');
  form.append(label,question,attachLabel,ledgerLabel,actions);section.append(heading,history,form,status);panel.append(section);
  const style=create('style');style.textContent='#assistant-chat-section{min-width:0;border-top:1px solid #444;margin-top:14px;padding-top:10px}#assistant-chat-section h3{font-size:14px}#assistant-chat-form>label{display:block;font-size:12px;margin:9px 0}#assistant-chat-question{box-sizing:border-box;width:100%;min-width:0;max-width:100%;resize:vertical;min-height:80px;max-height:220px;background:#111;color:#eee;border:1px solid #555;border-radius:5px;padding:8px;font-family:inherit;font-size:12px;line-height:1.5}#assistant-chat-form input[type=checkbox]{min-height:0;margin-right:6px}#assistant-chat-form>div{display:flex;flex-wrap:wrap;gap:3px}#assistant-chat-history{max-height:360px;overflow:auto;overflow-wrap:anywhere}#assistant-chat-history article{margin:8px 0;padding:8px}#assistant-chat-history p{white-space:pre-wrap;margin:5px 0;font-size:12px}#assistant-chat-status{white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px}';document.head.append(style);
  const threads=new Map();let current=null,inFlight=null,nonce=0,preferencesEpoch=0,preferencesRead=0,autoContext=false,contextLimit=8192;
  const identity=pane=>({pane,host:pane.host,ws:pane.host.ws,session:pane.raw,generation:pane.host.generation,paneGeneration:pane.generation,credential:typeof pane.host.config?.token==='string'?pane.host.config.token:''});
  const sameIdentity=(a,b)=>!!a&&!!b&&a.pane===b.pane&&a.host===b.host&&a.ws===b.ws&&a.session===b.session&&a.generation===b.generation&&a.paneGeneration===b.paneGeneration&&a.credential===b.credential;
  const redact=(text,credential)=>credential?text.split(credential).join('[凭据已隐藏]'):text;
  const selected=()=>{const pane=W.activePane,key=W.activeSession;return pane&&key?{key,...identity(pane)}:null;};
  function threadFor(key,pane=W.panes.get(key)){
    let thread=threads.get(key);
    const binding=pane?identity(pane):null;
    if(thread){
      if(!sameIdentity(thread.binding,binding)){
        thread.draft=redact(thread.draft,thread.binding?.credential||'');thread.messages=[];thread.ledger=false;thread.binding=binding;
        if(inFlight?.thread===thread)cancelRequest('连接身份已变化，正在取消原请求。');
        thread.status='连接身份已变化，已开始新对话。';
      }
      threads.delete(key);threads.set(key,thread);return thread;
    }
    thread={draft:'',messages:[],status:'',attach:autoContext,attachTouched:false,ledger:false,binding};threads.set(key,thread);
    while(threads.size>64){const old=[...threads.keys()].find(id=>id!==key&&id!==inFlight?.key);if(old===undefined)break;threads.delete(old);}
    return thread;
  }
  function live(request){return W.panes.get(request.key)===request.pane&&request.host.connected&&sameIdentity(request,identity(request.pane));}
  function push(thread,role,content){thread.messages.push({role,content});thread.messages=thread.messages.slice(-8);}
  function render(){
    const thread=current?threads.get(current.key):null;
    const follow=history.scrollHeight-history.clientHeight-history.scrollTop<=8,position=history.scrollTop;
    history.replaceChildren();
    if(thread?.messages.length){for(const message of thread.messages){const item=create('article'),title=create('strong',message.role==='user'?'你':'助手'),body=create('p',message.content);item.dataset.role=message.role;item.append(title,body);history.append(item);}}
    else history.append(create('p','可提问或分析当前窗口。默认不附带终端内容。'));
    history.scrollTop=follow?history.scrollHeight:position;
    question.disabled=!current;send.disabled=!current||!!inFlight;analyze.disabled=!current||!!inFlight;cancel.disabled=!inFlight||inFlight.cancelled;
    analyze.textContent=attachLedger.checked?'分析窗口与账本':'分析当前窗口';
    status.textContent=!current?'请先选择一个终端窗口。':inFlight&&inFlight.key!==current.key?'另一窗口的助手请求尚未结束，可以取消。':thread?.status||'';
  }
  function sync(){
    const next=selected();
    if(!current&&!next||current?.key===next?.key&&sameIdentity(current,next))return false;
    if(current&&threads.has(current.key))threads.get(current.key).draft=question.value;
    current=next;
    const thread=current?threadFor(current.key):null;question.value=thread?.draft||'';attach.checked=thread?.attach??autoContext;attachLedger.checked=thread?.ledger===true;render();history.scrollTop=history.scrollHeight;return true;
  }
  function context(pane){
    const buffer=pane.term.buffer.active,end=buffer.baseY+buffer.cursorY,start=Math.max(0,end-199),lines=[];
    for(let i=start;i<=end;i++){
      const line=buffer.getLine(i),text=line?.translateToString(true)||'';
      if(line?.isWrapped&&lines.length)lines[lines.length-1]+=text;else lines.push(text);
    }
    const text=lines.join('\n'),complete=buffer.getLine(start)?.isWrapped?text.replace(/^\S+\s*/u,''):text;
    return clip(complete,32768,true);
  }
  function clip(text,limit,tail=false){
    text=String(text||'');let value=tail?text.slice(-limit):text.slice(0,limit);
    if(text.length>limit){
      const boundary=tail?text.length-limit:limit;
      if(boundary>0&&!/\s/.test(text[boundary-1])&&!/\s/.test(text[boundary])){
        value=tail?value.replace(/^\S+\s*/u,''):value.replace(/\S+$/u,'');
      }
    }
    if(value&&/[\uDC00-\uDFFF]/.test(value[0]))value=value.slice(1);
    if(value&&/[\uD800-\uDBFF]/.test(value[value.length-1]))value=value.slice(0,-1);
    return value;
  }
  function evidenceContext(terminal,evidence){
    const limit=Math.min(contextLimit,8192),pages=[];
    const allowed=['negatives.md','trials.md','nodes.md','ideas.md','README.md'];
    const clean=text=>String(text||'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,' ');
    const source=evidence?.project_source==='session-startup-directory';
    let path=source?clip(clean(evidence.project).replace(/[\r\n\t]/g,' '),96):'';
    for(const name of allowed){
      const page=source&&evidence?.ledger?.pages?.[name];
      if(page?.status==='ready'&&typeof page.text==='string'&&page.text){
        const raw=clean(page.text),complete=page.truncated?raw.replace(/\S+$/u,''):raw;
        pages.push({name,text:clip(complete,limit<2048?128:1024),mtime:Number.isFinite(page.mtime)?String(page.mtime):'未知'});
      }
      if(limit<2048&&pages.length===2)break;
    }
    let output=clip(clean(terminal),Math.floor(limit/2),true);
    const renderContext=()=>('[项目账本：只读片段，未重新核验模式或证据]\n'+(path?'终端启动目录：'+path+'\n':'')+(pages.length?'':'没有可读取的账本页面；不能据此判断已有试验。\n')+pages.map(page=>'[来源 .metarsi/wiki/'+page.name+'；修改时间 '+page.mtime+'；片段]\n'+page.text).join('\n\n')+(output?'\n\n[终端最近输出片段]\n'+output:''));
    let result=renderContext();
    while(result.length>limit){
      const longest=pages.reduce((best,page)=>page.text.length>(best?.text.length||0)?page:best,null);
      if(output.length>32&&output.length>=(longest?.text.length||0))output=clip(output,Math.floor(output.length/2),true);
      else if(longest&&longest.text.length>32)longest.text=clip(longest.text,Math.floor(longest.text.length/2));
      else if(pages.length)pages.pop();
      else if(path)path='';
      else output='';
      result=renderContext();
    }
    // Keep quoted material as plain text: native credential redaction must run
    // before any JSON encoding can escape quotes or backslashes in a secret.
    return result;
  }
  async function refreshPreferences(){
    if(!api.get_assistant_preferences)return;
    const read=++preferencesRead;
    try{const result=await api.get_assistant_preferences();if(read!==preferencesRead)return;autoContext=result?.preferences?.auto_context===true;const maximum=result?.preferences?.max_context_chars;contextLimit=Number.isInteger(maximum)&&maximum>=512&&maximum<=32768?maximum:8192;for(const thread of threads.values())if(!thread.attachTouched)thread.attach=autoContext;const thread=current&&threads.get(current.key);if(thread&&!thread.attachTouched)attach.checked=thread.attach;}catch{}
  }
  function cancelRequest(message='已取消当前请求。'){
    if(!inFlight||inFlight.cancelled)return;
    const request=inFlight;request.cancelled=true;nonce++;
    if(request.epoch===preferencesEpoch)request.thread.status=message+' 等待原请求结束。';
    try{Promise.resolve(api.cancel_assistant_chat?.(request.id)).catch(()=>{});}catch{}
    render();
  }
  async function submit(analysis=false){
    if(sync()){if(current)threads.get(current.key).status='窗口已切换或连接身份已变化，请检查当前草稿后重新发送。';render();return;}
    if(!current||inFlight)return;
    const ledgerRequested=attachLedger.checked;
    const text=analysis?'请分析当前窗口的内容，推荐适用的 mylib 技能，并说明是否值得登记 metaRSI 改进假设；区分已知证据与待验证建议。'+(ledgerRequested?' 结合附带的只读账本，引用相关试验或否决记录，避免重复失败方案；给出具体问题、可检验假设、独立验收方法及可证伪条件。账本缺失或片段不足时明确说明，不声称重新运行过 tick 或验证。':''):question.value.trim();
    const thread=threadFor(current.key);
    if(!text||text.length>4000){thread.status='请输入不超过 4000 字符的问题。';render();return;}
    const pane=current.pane,request={key:current.key,...identity(pane),thread,nonce:++nonce,epoch:preferencesEpoch,cancelled:false};
    request.id=globalThis.crypto?.randomUUID?.()||('chat-'+Date.now().toString(36)+'-'+request.nonce+'-'+Math.random().toString(36).slice(2));
    if(!live(request)){thread.status='当前窗口尚未连接，请连接后再发送。';render();return;}
    const attachContext=analysis||attach.checked;
    let output='';
    try{if(attachContext)output=context(pane);}catch{thread.status='当前窗口上下文暂不可读。';render();return;}
    const token=request.credential,safeText=redact(text,token);
    const previous=thread.messages.slice(-6).map(message=>({role:message.role,content:redact(message.content,token).slice(0,4000)}));
    if(!analysis){thread.draft='';question.value='';}
    thread.status=ledgerRequested?'正在读取当前项目账本…':attachContext?'正在分析当前窗口…':'正在请求助手（未附带终端输出）…';push(thread,'user',safeText);inFlight=request;render();
    try{
      if(ledgerRequested){
        let evidence=null;
        try{evidence=await window.SuperMonoAssistantEvidence?.read(pane,{force:true});}catch{}
        if(request.cancelled||request.nonce!==nonce||request.epoch!==preferencesEpoch||!sameIdentity(thread.binding,request)||!live(request))return;
        request.ledgerAvailable=evidence?.project_source==='session-startup-directory'&&evidence?.ledger?.enabled===true&&['README.md','negatives.md','trials.md','nodes.md','ideas.md'].some(name=>evidence.ledger.pages?.[name]?.status==='ready'&&evidence.ledger.pages[name].text);
        output=evidenceContext(output,evidence);
        thread.status=request.ledgerAvailable?'正在分析项目账本片段…':'项目账本不可读，正在结合可用资料分析…';render();
      }
      const payload={request_id:request.id,question:safeText,context:output,history:previous,attach_context:attachContext||ledgerRequested,redactions:token?[token]:[]};
      const result=await api.assistant_chat(payload);
      if(request.cancelled||request.nonce!==nonce||request.epoch!==preferencesEpoch||threads.get(request.key)!==thread||!sameIdentity(thread.binding,request)||!live(request))return;
      if(!result||typeof result.text!=='string'||result.text.length>16384)throw Error('Invalid assistant response');
      push(thread,'assistant',redact(result.text,token));
      const provider=typeof result.provider==='string'?result.provider.slice(0,64):'',model=typeof result.model==='string'?result.model.slice(0,128):'';
      thread.status='已回复'+(provider?' · '+provider:'')+(model?' / '+model:'')+(Number.isInteger(result.context_used_chars)?' · 上下文 '+result.context_used_chars+' 字符':'')+(result.context_truncated?'（已截断）':'')+(ledgerRequested?(request.ledgerAvailable?' · 项目账本为未核验片段':' · 项目账本不可读'):'');
    }catch{
      if(!request.cancelled&&request.nonce===nonce&&request.epoch===preferencesEpoch&&live(request))thread.status='助手暂时无法响应，请检查模型配置或稍后重试。';
    }finally{
      if(inFlight===request)inFlight=null;
      if(request.epoch===preferencesEpoch&&sameIdentity(thread.binding,request)){if(request.cancelled)thread.status='请求已取消，未采用返回内容。';else if(!live(request))thread.status='窗口连接已变化，已丢弃旧请求结果。';}
      sync();render();
    }
  }
  question.addEventListener('input',()=>{sync();if(current)threadFor(current.key).draft=question.value;});
  attach.addEventListener('change',()=>{if(sync())return;if(current){const thread=threadFor(current.key);thread.attach=attach.checked;thread.attachTouched=true;}});
  attachLedger.addEventListener('change',()=>{if(sync())return;if(current){threadFor(current.key).ledger=attachLedger.checked;render();}});
  form.addEventListener('submit',event=>{event.preventDefault();submit();});analyze.onclick=()=>submit(true);cancel.onclick=()=>cancelRequest();
  function preferencesChanged(){
    preferencesEpoch++;cancelRequest('设置已更新，正在取消原请求。');
    for(const thread of threads.values()){thread.messages=[];thread.status='模型设置已更新，已开始新对话。';thread.attachTouched=false;thread.attach=false;thread.ledger=false;}
    attach.checked=false;attachLedger.checked=false;render();refreshPreferences();
  }
  addEventListener('mylib-preferences-changed',preferencesChanged);
  const timer=setInterval(()=>{if(panel.hidden)return;sync();if(inFlight&&!live(inFlight)){const request=inFlight,pane=W.panes.get(request.key);if(pane)threadFor(request.key,pane);else{request.thread.draft=redact(request.thread.draft,request.thread.binding?.credential||'');request.thread.messages=[];request.thread.binding=null;}cancelRequest('窗口连接已变化，正在取消原请求。');}},300);
  addEventListener('beforeunload',()=>{clearInterval(timer);cancelRequest();nonce++;removeEventListener('mylib-preferences-changed',preferencesChanged);},{once:true});
  sync();render();refreshPreferences();
})();
