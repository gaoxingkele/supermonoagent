const {test}=require('node:test');
const assert=require('node:assert/strict');
const M=require('../android/assets/mobile/mobile-core.js');

test('session dots follow live output, idle timeout and disconnection',()=>{
  assert.equal(M.sessionState(true,undefined,100),'waiting');
  assert.equal(M.sessionState(true,0,0),'refreshing');
  assert.equal(M.sessionState(true,100,1899),'refreshing');
  assert.equal(M.sessionState(true,100,1900),'waiting');
  assert.equal(M.sessionState(false,1900,1900),'disconnected');
  assert.equal(M.agentType({title:'Work Codex',shell:'powershell'}),'Codex');
  assert.equal(M.agentType({title:'Task',shell:'claude'}),'Claude');
  assert.equal(M.agentType({title:'Build',shell:'cmd'}),'cmd');
});
test('recovery uses a close code accepted by the actual WebSocket API',()=>{
  const ws=new WebSocket('ws://127.0.0.1:9');ws.addEventListener('error',()=>{});
  assert.doesNotThrow(()=>M.closeForRecovery(ws,'output backlog'));
  const source=require('node:fs').readFileSync(require('node:path').join(__dirname,'../android/assets/mobile/app.js'),'utf8');
  assert.ok(!source.includes('.close(1013'));
});
test('small echo is immediate; busy writes coalesce and stay bounded',()=>{
  const writes=[],frames=[];let done;
  const q=M.createWriter({write:(bytes,reset,cb)=>{writes.push([...bytes]);done=cb;},schedule:cb=>{frames.push(cb);return frames.length;},cancel:()=>{},limit:8,chunk:8,onOverflow:()=>writes.push('overflow')});
  assert.equal(q.push(Uint8Array.of(1)),true);assert.deepEqual(writes,[[1]]);
  q.push(Uint8Array.of(2));q.push(Uint8Array.of(3));done();frames.shift()();
  assert.deepEqual(writes,[[1],[2,3]]);assert.equal(q.push(new Uint8Array(9)),false);assert.equal(writes.at(-1),'overflow');q.dispose();
});
test('1000 queued fragments retain every byte using bounded parse batches',()=>{
  const frames=[],callbacks=[],output=[];let calls=0;
  const q=M.createWriter({write:(bytes,reset,done)=>{calls++;assert.ok(bytes.length<=32768);output.push(...bytes);callbacks.push(done);},schedule:cb=>{frames.push(cb);return frames.length;},cancel:()=>{}});
  for(let i=0;i<1000;i++)assert.equal(q.push(new Uint8Array(512).fill(i%251)),true);
  while(callbacks.length||frames.length){while(callbacks.length)callbacks.shift()();if(frames.length)frames.shift()();}
  assert.equal(output.length,512000);assert.ok(calls<20);
  for(let i=0;i<1000;i++)assert.equal(output[i*512],i%251);
  assert.equal(q.pending,0);
});
test('reset is an ordered boundary and dead callbacks cannot revive queues',()=>{
  let done;const writes=[],frames=[];
  const q=M.createWriter({write:(b,r,cb)=>{writes.push({bytes:[...b],reset:r});done=cb;},schedule:cb=>{frames.push(cb);return 1;},cancel:()=>{}});
  q.push(Uint8Array.of(1));q.push(Uint8Array.of(2),true);q.push(Uint8Array.of(3));done();frames.shift()();
  assert.deepEqual(writes[1],{bytes:[2,3],reset:true});q.dispose();done();assert.equal(frames.length,0);
});
test('touch threshold and fractional row accumulation separate tap from drag',()=>{
  const g=M.createGesture(10);g.start(5,30);assert.deepEqual(g.move(5,25,10),{rows:0,drag:false});
  assert.deepEqual(g.move(5,8,10),{rows:2,drag:true});assert.equal(g.end(),false);
  g.start(5,30);g.move(5,28,10);assert.equal(g.end(),true);
});
test('composer and control keys preserve Unicode; never send preedit',()=>{
  assert.equal(M.controlKey('c'),'\x03');assert.equal(M.controlKey('中'),'中');
  assert.equal(M.composerAction({key:'Enter',shiftKey:false,isComposing:true}),'none');
  assert.equal(M.composerAction({key:'Enter',shiftKey:true,isComposing:false}),'newline');
  assert.equal(M.composerAction({key:'Enter',shiftKey:false,isComposing:false}),'send');
  assert.equal(M.alternateScroll(1,false),'\x1b[B');assert.equal(M.alternateScroll(-1,true),'\x1bOA');
});
test('grid changes remain ordered boundaries during a busy output stream',()=>{
  const writes=[],frames=[],callbacks=[];
  const q=M.createWriter({write:(b,r,done,grid)=>{writes.push({bytes:[...b],grid});callbacks.push(done);},schedule:cb=>{frames.push(cb);return frames.length;},cancel:()=>{}});
  q.push(Uint8Array.of(1),false,()=>{},{cols:120,rows:30});
  q.push(Uint8Array.of(2),false,()=>{},{cols:120,rows:30});
  q.push(Uint8Array.of(3),false,()=>{},{cols:40,rows:20});
  q.push(Uint8Array.of(4),false,()=>{},{cols:40,rows:20});
  while(callbacks.length||frames.length){while(callbacks.length)callbacks.shift()();if(frames.length)frames.shift()();}
  assert.deepEqual(writes,[{bytes:[1],grid:{cols:120,rows:30}},{bytes:[2],grid:{cols:120,rows:30}},{bytes:[3,4],grid:{cols:40,rows:20}}]);
  assert.equal(q.idle,true);
});
