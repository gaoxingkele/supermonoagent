(function(root){
  'use strict';
  function createWriter({write,schedule,cancel,onOverflow=()=>{},limit=524288,chunk=32768}){
    let queue=[],pending=0,busy=false,frame=null,dead=false;
    function drain(){
      frame=null;if(dead||busy||!queue.length)return;
      const reset=queue[0].reset,grid=queue[0].grid,parts=[],callbacks=[];let size=0;
      while(queue.length&&size<chunk){
        const item=queue[0];if(parts.length&&(item.reset||item.grid?.cols!==grid?.cols||item.grid?.rows!==grid?.rows))break;
        const n=Math.min(item.bytes.length-item.offset,chunk-size);
        parts.push(item.bytes.subarray(item.offset,item.offset+n));size+=n;item.offset+=n;item.reset=false;
        if(item.offset===item.bytes.length){queue.shift();callbacks.push(item.done);}else break;
      }
      const bytes=new Uint8Array(size);let at=0;for(const part of parts){bytes.set(part,at);at+=part.length;}
      busy=true;
      write(bytes,reset,()=>{if(dead)return;pending-=size;busy=false;for(const done of callbacks)done();if(queue.length&&frame===null)frame=schedule(drain);},grid);
    }
    return {push(bytes,reset=false,done=()=>{},grid=null){
      if(dead)return false;
      if(pending+bytes.length>limit){onOverflow();return false;}
      pending+=bytes.length;queue.push({bytes,reset,done,grid,offset:0});if(!busy&&frame===null)drain();return true;
    },dispose(){dead=true;if(frame!==null)cancel(frame);queue=[];pending=0;},get pending(){return pending;},get idle(){return !busy&&!queue.length;}};
  }
  function createGesture(threshold=10){
    let x=0,y=0,lastY=0,remainder=0,drag=false;
    return {start(px,py){x=px;y=lastY=py;remainder=0;drag=false;},move(px,py,line){
      if(!drag&&Math.hypot(px-x,py-y)<threshold)return {rows:0,drag:false};
      drag=true;remainder+=lastY-py;lastY=py;const rows=Math.trunc(remainder/Math.max(1,line));remainder-=rows*line;
      return {rows,drag:true};},end(){return !drag;}};
  }
  function controlKey(text){return /^[a-z@\[\]\\^_]$/i.test(text)?String.fromCharCode(text.toUpperCase().charCodeAt(0)&31):text;}
  function composerAction(e){return e.key!=='Enter'||e.isComposing||e.keyCode===229?'none':e.shiftKey?'newline':'send';}
  function alternateScroll(rows,application){return '\x1b'+(application?'O':'[')+(rows<0?'A':'B');}
  function closeForRecovery(socket,reason){if(socket)socket.close(4001,reason);}
  function sessionState(connected,lastOutput,now){
    return !connected?'disconnected':lastOutput!==undefined&&now-lastOutput<1800?'refreshing':'waiting';
  }
  function agentType(session){
    const text=[session.agent,session.title,session.shell].filter(Boolean).join(' ');
    for(const [pattern,label] of [[/codex/i,'Codex'],[/claude/i,'Claude'],[/kimi/i,'Kimi'],[/gemini/i,'Gemini'],[/opencode/i,'OpenCode'],[/copilot/i,'Copilot'],[/aider/i,'Aider']])if(pattern.test(text))return label;
    return session.shell||'终端';
  }
  const api={createWriter,createGesture,controlKey,composerAction,alternateScroll,closeForRecovery,sessionState,agentType};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.MobileCore=api;
})(typeof window==='undefined'?globalThis:window);
