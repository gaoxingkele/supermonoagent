"""Pair an outbound host with outbound phones and copy frames. Do not decode them."""

from __future__ import annotations

import argparse
import asyncio
import importlib
import json
import struct
import hashlib
import hmac
import secrets
import time
from pathlib import Path
from .security import request_allowed, tls_context, transport_options, loopback
from dataclasses import dataclass, field

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

from . import web

QUEUE_FRAMES = 32
FIRST_FRAME_S = 2.0


@dataclass
class Room:
    host: object | None = None
    phones: dict = field(default_factory=dict)
    queues: dict = field(default_factory=dict)
    reliable: set[int] = field(default_factory=set)
    tokens: set = field(default_factory=set)
    pending: dict = field(default_factory=dict)
    phone_tokens: dict = field(default_factory=dict)
    senders: dict = field(default_factory=dict)
    next_id: int = 1
    machine: str = ""
    project: str = "默认"


def group_hosts(hosts: list[dict]) -> list[dict]:
    """Fold host announcements into 项目 → 房间. One project can hold several computers."""
    order: list[str] = []
    buckets: dict[str, list] = {}
    for item in hosts:
        name = str(item.get("project") or "默认")[:40] or "默认"
        if name not in buckets:
            buckets[name] = []
            order.append(name)
        buckets[name].append({
            "code": str(item.get("code") or ""),
            "machine": str(item.get("machine") or item.get("code") or "")[:40],
        })
    return [{"project": name, "rooms": buckets[name]} for name in order]


class Relay:
    def __init__(self, enrollment_file=None, *, development=False, allowed_origins=()) -> None:
        self.rooms: dict[str, Room] = {}
        self.development = development
        self.allowed_origins = tuple(allowed_origins)
        self.enrollment_file = Path(enrollment_file) if enrollment_file else None
        self.enrolled = json.loads(self.enrollment_file.read_text()) if self.enrollment_file and self.enrollment_file.exists() else {}
        self.watchers = {}
        self.revision = 0

    def enroll(self, code, secret=None):
        if not isinstance(code, str) or not 1 <= len(code) <= 128:
            raise ValueError('Room code must contain 1 to 128 characters')
        if not self.enrollment_file:
            raise ValueError('Enrollment requires a persisted verifier file')
        if code in self.enrolled:
            raise ValueError('Room is already enrolled')
        secret = secret or secrets.token_urlsafe(32)
        self.enrolled[code] = hashlib.sha256(secret.encode()).hexdigest()
        self.enrollment_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.enrollment_file.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.enrolled), encoding='utf-8')
        temporary.replace(self.enrollment_file)
        return secret

    def _owner_allowed(self, ws, code, secret):
        verifier = self.enrolled.get(code)
        if verifier:
            return bool(secret) and hmac.compare_digest(verifier, hashlib.sha256(secret.encode()).hexdigest())
        return self.development and loopback(ws.remote_address[0])

    def _snapshot(self, rooms):
        hosts = []
        for code, token in rooms:
            room = self.rooms.get(code)
            item = {'code': code, 'online': False}
            if room and room.host is not None and token and token in room.tokens:
                item.update(online=True, machine=room.machine, project=room.project)
            hosts.append(item)
        return json.dumps({'op': 'directory', 'revision': self.revision,
                           'capabilities': {'known_rooms': True, 'directory_push': True, 'host_enrollment': True, 'protocol_version': 2}, 'hosts': hosts})

    def _publish(self):
        self.revision += 1
        for rooms, queue in self.watchers.values():
            # Replace pending snapshots, especially identities invalidated by rotation.
            while not queue.empty():
                queue.get_nowait()
            queue.put_nowait(self._snapshot(rooms))

    @staticmethod
    def _watch_rooms(hello):
        rooms = hello.get('rooms')
        if not isinstance(rooms, list) or len(rooms) > 64:
            raise ValueError('Too many rooms')
        result = []
        for item in rooms:
            if not isinstance(item, dict):
                raise ValueError('Invalid room')
            code, token = item.get('code'), item.get('token')
            if not isinstance(code, str) or not 1 <= len(code) <= 128 or not isinstance(token, str) or len(token) > 4096:
                raise ValueError('Invalid room credentials')
            result.append((code, token))
        return result

    async def _watch(self, ws, hello):
        queue = asyncio.Queue(QUEUE_FRAMES)
        sender = asyncio.create_task(self._drain(ws, queue))
        updates = []
        try:
            while True:
                now = time.monotonic()
                updates = [stamp for stamp in updates if now - stamp < 1]
                if len(updates) >= 10 or hello.get('op') != 'watch':
                    raise ValueError('Watch rate exceeded')
                updates.append(now)
                self.watchers[ws] = (self._watch_rooms(hello), queue)
                self._publish()
                raw = await ws.recv()
                if len(raw) > 1024 * 1024:
                    raise ValueError('Oversized message')
                hello = json.loads(raw)
                if not isinstance(hello, dict):
                    raise ValueError('Invalid watch')
        except ConnectionClosed:
            pass
        except (ValueError, TypeError):
            await ws.close(code=4000)
        finally:
            self.watchers.pop(ws, None)
            sender.cancel()
            await asyncio.gather(sender, return_exceptions=True)

    async def _replace_tokens(self, room, tokens):
        if not isinstance(tokens, list):
            return
        room.tokens = {item for item in tokens if isinstance(item, str) and item}
        self._publish()
        closing = []
        for phone_id, phone in list(room.phones.items()):
            if room.phone_tokens.get(phone_id) not in room.tokens:
                queue = room.queues.pop(phone_id, None)
                if queue is not None:
                    while not queue.empty():
                        queue.get_nowait()
                sender = room.senders.pop(phone_id, None)
                if sender is not None:
                    sender.cancel()
                closing.append(phone.close(code=4001, reason='Credentials revoked'))
        # Every revoked route and pending sender is removed before any network await.
        if closing:
            await asyncio.gather(*closing, return_exceptions=True)

    def room(self, code: str) -> Room:
        return self.rooms.setdefault(code, Room())

    async def serve_page(self, connection, request):
        page = importlib.reload(web)
        if not request_allowed(connection, request, self.allowed_origins):
            return page.text_response(connection, 403, 'Forbidden', 'text/plain')
        path = request.path.split("?", 1)[0]
        content = page.page_content(path)
        if content is not None:
            text, content_type = content
            return page.text_response(connection, 200, text, content_type)
        if path == "/health":
            body = json.dumps({'ok': True, 'role': 'relay'})
            return page.text_response(connection, 200, body, "application/json")
        return None

    def host_listing(self) -> list[dict]:
        hosts = []
        for code, room in self.rooms.items():
            if room.host is None:
                continue
            hosts.append({
                "code": code,
                "machine": room.machine,
                "project": room.project or "默认",
            })
        return hosts

    async def handler(self, ws) -> None:
        if '?' in ws.request.path:
            await ws.close(code=4001, reason='Credentials must be in the first frame')
            return
        try:
            raw = await asyncio.wait_for(ws.recv(), FIRST_FRAME_S)
            if len(raw) > 1024 * 1024:
                raise ValueError('Oversized hello')
            hello = json.loads(raw)
            if not isinstance(hello, dict):
                raise ValueError('Invalid hello')
        except (asyncio.TimeoutError, ValueError, TypeError, ConnectionClosed):
            await ws.close(code=4000)
            return
        if hello.get('op') == 'watch':
            await self._watch(ws, hello)
            return
        code = hello.get("code")
        role = hello.get("op")
        if not isinstance(code, str) or not code or len(code) > 128 or role not in {"host", "phone", "register", "login", "rotate"}:
            await ws.close(code=4000)
            return
        room = self.rooms.get(code)
        if role == "host":
            owner_secret = str(hello.get('owner_secret') or '')
            tokens = hello.get('tokens') or []
            if not isinstance(tokens, list) or owner_secret and owner_secret in tokens or not self._owner_allowed(ws, code, owner_secret):
                await ws.close(code=4001)
                return
            if room is not None and room.host is not None:
                await ws.close(code=4003)
                return
            room = self.room(code)
            if room.host is None:
                room.tokens = {item for item in tokens if isinstance(item, str) and item}
                room.machine = str(hello.get("machine") or "")[:40]
                room.project = str(hello.get("project") or "默认")[:40] or "默认"
            await self._host(ws, code, room)
        elif role in {"register", "login", "rotate"}:
            await self._account(ws, code, hello)
        else:
            token = str(hello.get("token") or "")
            if room is None or token not in room.tokens:
                await ws.close(code=4001)
                return
            await self._phone(ws, code, room, token, hello.get("reliable") is True)

    async def _host(self, ws, code: str, room: Room) -> None:
        if room.host is not None:
            await ws.close(code=4003)
            return
        room.host = ws
        self._publish()
        try:
            await ws.send(json.dumps({"op": "ready"}))
            async for message in ws:
                if isinstance(message, str):
                    try:
                        ctrl = json.loads(message)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(ctrl, dict):
                        continue
                    if ctrl.get("op") == "tokens":
                        await self._replace_tokens(room, ctrl.get("tokens") or [])
                    elif ctrl.get("op") == "identity":
                        room.machine = str(ctrl.get("machine") or room.machine)[:40]
                        room.project = str(ctrl.get("project") or room.project or "默认")[:40] or "默认"
                        self._publish()
                    elif ctrl.get("op") == "disconnect":
                        phone = room.phones.get(int(ctrl.get("id") or 0))
                        if phone is not None:
                            await phone.close(code=1013, reason=str(ctrl.get("reason") or "Output overflow")[:120])
                    elif ctrl.get("op") == "auth" and ctrl.get("id") is not None:
                        fut = room.pending.get(int(ctrl["id"]))
                        if fut is not None and not fut.done():
                            fut.set_result(ctrl)
                    continue
                if len(message) > 1024 * 1024:
                    await ws.close(code=1009)
                    break
                if len(message) < 4:
                    continue
                phone_id = struct.unpack_from("<I", message)[0]
                self._enqueue(room, phone_id, message[4:])
        finally:
            if room.host is ws:
                room.host = None
                await self._replace_tokens(room, [])
            if room.host is None and not room.phones:
                self.rooms.pop(code, None)

    async def _account(self, ws, code: str, hello: dict) -> None:
        room = self.rooms.get(code)
        if room is None or room.host is None:
            await ws.send(json.dumps({"op": "auth", "error": "办公室主机还没连上"}, ensure_ascii=False))
            await ws.close(code=4004)
            return
        auth_id = room.next_id
        room.next_id += 1
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        room.pending[auth_id] = fut
        try:
            await room.host.send(json.dumps({
                "op": hello.get("op"),
                "id": auth_id,
                "email": hello.get("email") or hello.get("name") or "",
                "password": hello.get("password") or "",
            }))
            reply = await asyncio.wait_for(fut, 8)
            await ws.send(json.dumps(reply, ensure_ascii=False))
        except Exception:
            await ws.send(json.dumps({"op": "auth", "error": "注册没有完成"}, ensure_ascii=False))
        finally:
            room.pending.pop(auth_id, None)
            await ws.close()

    async def _phone(self, ws, code: str, room: Room, token: str, reliable: bool = False) -> None:
        if room.host is None:
            await ws.close(code=4004)
            return
        phone_id = room.next_id
        room.next_id += 1
        queue: asyncio.Queue = asyncio.Queue(QUEUE_FRAMES)
        room.phones[phone_id] = ws
        room.phone_tokens[phone_id] = token
        room.queues[phone_id] = queue
        if reliable:
            room.reliable.add(phone_id)
        sender = asyncio.create_task(self._drain(ws, queue))
        room.senders[phone_id] = sender
        try:
            await room.host.send(json.dumps({"op": "join", "id": phone_id, "token": token, "reliable": reliable}))
            await ws.send(json.dumps({"op": "ready"}))
            async for message in ws:
                host = room.host
                if host is None or token not in room.tokens:
                    break
                body = message if isinstance(message, bytes) else message.encode()
                await host.send(struct.pack("<I", phone_id) + body)
        finally:
            room.phones.pop(phone_id, None)
            room.phone_tokens.pop(phone_id, None)
            room.senders.pop(phone_id, None)
            room.queues.pop(phone_id, None)
            room.reliable.discard(phone_id)
            sender.cancel()
            host = room.host
            if host is not None:
                try:
                    await host.send(json.dumps({"op": "leave", "id": phone_id}))
                except Exception:
                    pass
            if room.host is None and not room.phones:
                self.rooms.pop(code, None)

    def _enqueue(self, room: Room, phone_id: int, message: bytes) -> None:
        queue = room.queues.get(phone_id)
        if queue is None:
            return
        if queue.full():
            if phone_id in room.reliable:
                phone = room.phones.get(phone_id)
                if phone is not None:
                    asyncio.create_task(phone.close(code=1013, reason="Slow relay subscriber; reconnect for bounded history replay"))
                return
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            queue.put_nowait(message)
        except asyncio.QueueFull:
            room.phones.pop(phone_id, None)

    async def _drain(self, ws, queue: asyncio.Queue) -> None:
        try:
            while True:
                await ws.send(await queue.get())
        except (asyncio.CancelledError, ConnectionClosed):
            return


def main() -> None:
    parser = argparse.ArgumentParser(description="SuperMonoAgent relay")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=6770)
    transport_options(parser)
    parser.add_argument('--enrollment-file', default=str(Path.home() / '.supermonoagent' / 'relay-owners.json'))
    parser.add_argument('--enroll', metavar='ROOM', help='Enroll a room, print its new owner secret, and exit')
    parser.add_argument('--development', action='store_true', help='Explicit loopback-only fixture host claims')
    args = parser.parse_args()
    if args.development and not loopback(args.host):
        parser.error('--development requires a loopback bind address')
    relay = Relay(args.enrollment_file, development=args.development, allowed_origins=args.allowed_origin)
    if args.enroll:
        print(relay.enroll(args.enroll))
        return
    context = tls_context(args.tls_cert, args.tls_key)
    if not loopback(args.host) and not context and not (args.reverse_proxy_tls and args.allowed_origin and all(origin.startswith('https://') for origin in args.allowed_origin)):
        parser.error('Public serving requires TLS or --reverse-proxy-tls with --allowed-origin')

    async def run() -> None:
        async with serve(
            relay.handler,
            args.host,
            args.port,
            process_request=relay.serve_page,
            ssl=context,
            max_size=1024 * 1024,
            ping_interval=25,
            ping_timeout=25,
        ):
            print(f"relay ws://{args.host}:{args.port}")
            await asyncio.Future()

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        return


if __name__ == "__main__":
    main()
